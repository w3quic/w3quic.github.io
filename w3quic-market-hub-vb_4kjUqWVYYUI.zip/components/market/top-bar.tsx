"use client"

import { ArrowLeft, Bell, Heart, Search, Sparkles } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { cn } from "@/lib/utils"
import { CURRENT_USER_ID } from "@/lib/market/seed"

export function TopBar({ onOpenAssistant }: { onOpenAssistant: () => void }) {
  const { view, go, back, tab } = useNav()
  const { notifications, wishlist } = useMarket()
  const unread = notifications.filter((n) => n.userId === CURRENT_USER_ID && !n.read).length
  const isRoot = tab !== "" || view.name === "home"

  const titleMap: Record<string, string> = {
    cart: "Shopping Cart", wishlist: "Wishlist", checkout: "Checkout", orders: "My Orders",
    order: "Order Details", messages: "Messages", notifications: "Notifications", profile: "Profile",
    settings: "Settings", store: "Store", seller: "Seller Center", "create-listing": "Create Listing",
    loyalty: "Rewards", admin: "Admin Dashboard", auctions: "Live Auctions", flash: "Flash Deals",
    product: "", browse: "Browse", "real-estate": "Real Estate Hub", "vehicle-marketplace": "Vehicle Marketplace", services: "Services Marketplace",
  }

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-2 border-b border-border bg-card/98 px-3 backdrop-blur-lg shadow-sm">
      {!isRoot ? (
        <button onClick={back} aria-label="Go back" className="flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted active:bg-muted/80">
          <ArrowLeft className="h-5 w-5" />
        </button>
      ) : (
        <button onClick={() => go({ name: "home" })} className="flex items-center gap-2 pl-1 transition-transform hover:scale-105" aria-label="Pi Market Hub home">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-primary/80 text-sm font-bold text-primary-foreground shadow-md">π</span>
          <span className="text-xs font-bold leading-tight text-foreground">Pi Market<br />Hub</span>
        </button>
      )}

      {view.name === "home" || view.name === "browse" ? (
        <button
          onClick={() => go({ name: "browse" })}
          className="flex h-9 flex-1 items-center gap-2 rounded-full border border-input bg-background px-3 text-sm text-muted-foreground transition-colors hover:border-primary/50 hover:bg-muted/50"
        >
          <Search className="h-4 w-4" /> Search products...
        </button>
      ) : (
        <h1 className="flex-1 truncate text-sm font-bold text-foreground">{titleMap[view.name] ?? ""}</h1>
      )}

      <button onClick={onOpenAssistant} aria-label="AI assistant" className="hidden h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted hover:text-primary active:bg-muted/80 sm:flex">
        <Sparkles className="h-5 w-5" />
      </button>
      <button onClick={() => go({ name: "wishlist" })} aria-label="Wishlist" className="relative flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted active:bg-muted/80">
        <Heart className="h-5 w-5" />
        {wishlist.length > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-rose-500 animate-pulse" />}
      </button>
      <button onClick={() => go({ name: "notifications" })} aria-label="Notifications" className="relative flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-muted active:bg-muted/80">
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className={cn("absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground shadow-md animate-glow-pulse")}>
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
    </header>
  )
}
