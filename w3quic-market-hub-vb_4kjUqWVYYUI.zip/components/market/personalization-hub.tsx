'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useMarket } from '@/lib/market/store'
import { ProductCard } from './product-card'
import type { Product } from '@/lib/market/types'
import { Heart, Save, Trash2, Search, RotateCw } from 'lucide-react'

export function PersonalizationHub({
  onProductSelect,
}: {
  onProductSelect?: (product: Product) => void
}) {
  const market = useMarket()
  const [newSearch, setNewSearch] = useState('')
  const [savedSearchToRemove, setSavedSearchToRemove] = useState<string | null>(null)

  const wishlistProducts = market.products.filter((p) => market.wishlist.includes(p.id))
  const wishlistRecommendations = wishlistProducts.length > 0
    ? market.getSimilarProducts(wishlistProducts[0].id).filter(
        (p) => !market.wishlist.includes(p.id),
      )
    : []

  const handleSaveSearch = () => {
    if (newSearch.trim()) {
      market.saveSearch(newSearch)
      setNewSearch('')
    }
  }

  const handleRemoveSearch = (query: string) => {
    market.removeSearch(query)
    setSavedSearchToRemove(null)
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="wishlist" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="wishlist" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            <span className="hidden sm:inline">Wishlist</span>
          </TabsTrigger>
          <TabsTrigger value="searches" className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline">Saved Searches</span>
          </TabsTrigger>
        </TabsList>

        {/* Wishlist Tab */}
        <TabsContent value="wishlist" className="space-y-6 mt-6">
          {wishlistProducts.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="pt-6 text-center">
                <Heart className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-50" />
                <p className="text-muted-foreground mb-4">No items in your wishlist yet</p>
                <Button variant="outline" onClick={() => onProductSelect?.(market.products[0])}>
                  Explore Products
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              <div className="space-y-4">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <Heart className="w-5 h-5 text-red-600" />
                  Your Wishlist ({wishlistProducts.length})
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {wishlistProducts.map((product) => (
                    <div
                      key={product.id}
                      onClick={() => onProductSelect?.(product)}
                      className="cursor-pointer transition-transform hover:scale-105"
                    >
                      <ProductCard product={product} hideActions={true} compact={true} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Wishlist Recommendations */}
              {wishlistRecommendations.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <RotateCcw className="w-5 h-5" />
                      Wishlist Recommendations
                    </CardTitle>
                    <CardDescription>
                      Based on items in your wishlist
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                      {wishlistRecommendations.slice(0, 8).map((product) => (
                        <div
                          key={product.id}
                          onClick={() => onProductSelect?.(product)}
                          className="cursor-pointer transition-transform hover:scale-105"
                        >
                          <ProductCard
                            product={product}
                            hideActions={true}
                            compact={true}
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>

        {/* Saved Searches Tab */}
        <TabsContent value="searches" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Save className="w-5 h-5" />
                Save a Search
              </CardTitle>
              <CardDescription>
                Save your favorite searches for quick access
              </CardDescription>
            </CardHeader>
            <CardContent className="flex gap-2">
              <Input
                placeholder="E.g., 'laptop under 600'"
                value={newSearch}
                onChange={(e) => setNewSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSaveSearch()}
              />
              <Button onClick={handleSaveSearch} disabled={!newSearch.trim()}>
                Save
              </Button>
            </CardContent>
          </Card>

          {market.savedSearches.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="pt-6 text-center">
                <Search className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-50" />
                <p className="text-muted-foreground">No saved searches yet</p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Saved Searches ({market.savedSearches.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {market.savedSearches.map((search) => (
                    <div
                      key={search}
                      className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                    >
                      <button
                        onClick={() => {
                          market.addSearch(search)
                          const results = market.performSmartSearch({
                            query: search,
                            sortBy: 'relevance',
                          })
                          onProductSelect?.(results[0])
                        }}
                        className="flex items-center gap-2 flex-1 text-left"
                      >
                        <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm font-medium truncate">{search}</span>
                      </button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSavedSearchToRemove(search)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Searches */}
          {market.recentSearches.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Searches</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {market.recentSearches.slice(0, 8).map((search) => (
                    <button
                      key={search}
                      onClick={() => {
                        market.addSearch(search)
                        const results = market.performSmartSearch({
                          query: search,
                          sortBy: 'relevance',
                        })
                        if (results.length > 0) onProductSelect?.(results[0])
                      }}
                      className="px-3 py-1 text-sm rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
                    >
                      {search}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Delete Confirmation Dialog */}
      {savedSearchToRemove && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-sm">
            <CardHeader>
              <CardTitle>Delete Search</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Remove &quot;{savedSearchToRemove}&quot; from your saved searches?
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setSavedSearchToRemove(null)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => {
                    handleRemoveSearch(savedSearchToRemove)
                  }}
                  className="flex-1"
                >
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
