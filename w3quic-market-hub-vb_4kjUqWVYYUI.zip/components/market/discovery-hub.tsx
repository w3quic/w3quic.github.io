'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useMarket } from '@/lib/market/store'
import { ProductCard } from './product-card'
import { RecommendationsSection } from './recommendations-section'
import type { Product } from '@/lib/market/types'
import {
  TrendingUp,
  Sparkles,
  Tag,
  RefreshCw,
  Award,
  Calendar,
  MapPin,
  Store,
  Heart,
} from 'lucide-react'

export function DiscoveryHub({ onProductSelect }: { onProductSelect?: (product: Product) => void }) {
  const market = useMarket()
  const [activeTab, setActiveTab] = useState('trending')

  const trendingProducts = market.getTrendingProducts()
  const recentlyDropped = market.getRecentlyPriceDropped()
  const recentlyRestocked = market.getRecentlyRestocked()
  const verifiedBusinesses = market.getVerifiedBusinesses()

  const seasonalCollections = [
    { name: 'Holiday & New Year', tag: 'holiday', theme: 'Festive gifts and decorations' },
    { name: 'Summer Collection', tag: 'summer', theme: 'Outdoor essentials' },
    { name: 'Electronics Deals', tag: 'electronics', theme: 'Latest tech gadgets' },
    { name: 'Fashion Trends', tag: 'fashion', theme: 'Seasonal styles' },
  ]

  const editorsPicks = trendingProducts.slice(0, 4)

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
          <TabsTrigger value="trending" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            <span className="hidden sm:inline">Trending</span>
          </TabsTrigger>
          <TabsTrigger value="discovery" className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">Discovery</span>
          </TabsTrigger>
          <TabsTrigger value="deals" className="flex items-center gap-2">
            <Tag className="w-4 h-4" />
            <span className="hidden sm:inline">Deals</span>
          </TabsTrigger>
          <TabsTrigger value="collections" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span className="hidden sm:inline">Collections</span>
          </TabsTrigger>
        </TabsList>

        {/* Trending Tab */}
        <TabsContent value="trending" className="space-y-6 mt-6">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-600" />
              <h3 className="font-semibold text-lg">Trending Now</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {trendingProducts.map((product) => (
                <div
                  key={product.id}
                  onClick={() => onProductSelect?.(product)}
                  className="cursor-pointer transition-transform hover:scale-105"
                >
                  <ProductCard product={product} hideActions={true} compact={true} />
                </div>
              ))}
            </div>
          </div>

          {/* Trending Categories */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Trending Categories
              </CardTitle>
              <CardDescription>Top performing product categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {market.getTrendingCategories().map((cat: any) => (
                  <div
                    key={cat.categoryId}
                    className="p-3 rounded-lg border border-border hover:border-primary hover:bg-secondary/50 cursor-pointer transition-all"
                  >
                    <div className="font-medium text-sm capitalize">{cat.categoryId}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Score: {Math.round(cat.trendScore)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Discovery Tab */}
        <TabsContent value="discovery" className="space-y-6 mt-6">
          <RecommendationsSection
            title="Recommended For You"
            type="recommendations"
            onProductSelect={onProductSelect}
          />

          {/* Verified Businesses */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5" />
                Verified Businesses
              </CardTitle>
              <CardDescription>Trusted sellers on Pi Market Hub</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {verifiedBusinesses.slice(0, 6).map((seller) => (
                  <div key={seller.id} className="p-3 rounded-lg border border-border hover:bg-secondary/50 cursor-pointer transition-all">
                    <div className="flex items-start justify-between mb-2">
                      <div className="font-medium">{seller.displayName}</div>
                      <Award className="w-4 h-4 text-yellow-500" />
                    </div>
                    <div className="text-sm text-muted-foreground line-clamp-2 mb-2">{seller.bio}</div>
                    <div className="flex justify-between text-xs">
                      <span>{seller.ratingCount} reviews</span>
                      <span>{seller.rating}⭐</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Editor's Picks */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-600" />
              <h3 className="font-semibold text-lg">Editor's Picks</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {editorsPicks.map((product) => (
                <div
                  key={product.id}
                  onClick={() => onProductSelect?.(product)}
                  className="cursor-pointer transition-transform hover:scale-105 relative"
                >
                  <div className="absolute top-2 right-2 z-10 bg-purple-600 text-white text-xs px-2 py-1 rounded-full">
                    Editor
                  </div>
                  <ProductCard product={product} hideActions={true} compact={true} />
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Deals Tab */}
        <TabsContent value="deals" className="space-y-6 mt-6">
          <RecommendationsSection
            title="Recently Price Dropped"
            type="price-dropped"
            onProductSelect={onProductSelect}
          />

          <RecommendationsSection
            title="Recently Restocked"
            type="restocked"
            onProductSelect={onProductSelect}
          />
        </TabsContent>

        {/* Collections Tab */}
        <TabsContent value="collections" className="space-y-6 mt-6">
          <div>
            <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Seasonal Collections
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {seasonalCollections.map((collection) => (
                <Card key={collection.tag} className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden">
                  <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                    <Calendar className="w-12 h-12 text-primary/50" />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-base">{collection.name}</CardTitle>
                    <CardDescription>{collection.theme}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>

          {/* Local Marketplace */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Shop by Location
              </CardTitle>
              <CardDescription>Find products available in your area</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {['Singapore', 'Milan', 'Amsterdam', 'Denver', 'New York', 'London'].map((location) => (
                  <button
                    key={location}
                    className="p-3 rounded-lg border border-border hover:border-primary hover:bg-secondary/50 text-sm transition-all"
                  >
                    {location}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
