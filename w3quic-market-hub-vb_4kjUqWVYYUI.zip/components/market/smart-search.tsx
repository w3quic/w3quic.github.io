'use client'

import { useState, useEffect } from 'react'
import { Search, Mic, X } from 'lucide-react'
import { useMarket } from '@/lib/market/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface SmartSearchProps {
  onSearch?: (results: any[]) => void
  onQueryChange?: (query: string) => void
  compact?: boolean
}

export function SmartSearch({ onSearch, onQueryChange, compact }: SmartSearchProps) {
  const market = useMarket()
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState<any[]>([])
  const [isListening, setIsListening] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [isSearching, setIsSearching] = useState(false)

  useEffect(() => {
    if (query.length > 1) {
      const suggestions = market.getSearchSuggestions(query)
      setSuggestions(suggestions)
      setShowSuggestions(true)
    } else {
      setSuggestions([])
      setShowSuggestions(false)
    }
  }, [query, market])

  const handleSearch = (searchQuery: string) => {
    if (!searchQuery.trim()) return

    setIsSearching(true)
    market.addSearch(searchQuery)

    const context = {
      query: searchQuery,
      sortBy: 'relevance' as const,
    }
    const results = market.performSmartSearch(context)

    if (onSearch) onSearch(results)
    if (onQueryChange) onQueryChange(searchQuery)

    setQuery('')
    setShowSuggestions(false)
    setSuggestions([])
    setIsSearching(false)
  }

  const handleVoiceSearch = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Voice search not supported in your browser')
      return
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
    const recognition = new SpeechRecognition()

    recognition.onstart = () => setIsListening(true)
    recognition.onend = () => setIsListening(false)

    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0].transcript)
        .join('')

      setQuery(transcript)

      // Auto-search with voice
      if (event.isFinal) {
        handleSearch(transcript)
      }
    }

    recognition.onerror = () => {
      setIsListening(false)
      alert('Voice search failed')
    }

    recognition.start()
  }

  const selectSuggestion = (suggestion: any) => {
    const searchText = suggestion.text || suggestion.query || ''
    handleSearch(searchText)
  }

  const getSuggestionLabel = (sugg: any) => {
    if (sugg.type === 'category') return `Browse: ${sugg.text}`
    if (sugg.type === 'product') return `View: ${sugg.text}`
    return sugg.text
  }

  if (compact) {
    return (
      <div className="flex gap-2 w-full">
        <div className="flex-1 relative">
          <Input
            placeholder="Search products..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
            className="pr-10"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <Button
          onClick={() => handleSearch(query)}
          disabled={!query.trim() || isSearching}
          size="sm"
        >
          <Search className="w-4 h-4" />
        </Button>
      </div>
    )
  }

  return (
    <div className="w-full space-y-3">
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="What are you looking for? (e.g., 'laptop under 500')"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
              onFocus={() => query.length > 1 && setShowSuggestions(true)}
              className="pl-10 pr-10"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-10 top-2.5 text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={handleVoiceSearch}
              disabled={isListening}
              className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
              title="Voice search"
            >
              <Mic className={`w-4 h-4 ${isListening ? 'animate-pulse' : ''}`} />
            </button>
          </div>

          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-background border border-border rounded-lg shadow-lg z-50 max-h-64 overflow-y-auto">
              {suggestions.map((sugg) => (
                <button
                  key={`${sugg.text}-${sugg.type}`}
                  onClick={() => selectSuggestion(sugg)}
                  className="w-full text-left px-4 py-2 hover:bg-secondary flex items-center gap-2 border-b border-border last:border-b-0"
                >
                  <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm truncate">{getSuggestionLabel(sugg)}</div>
                    {sugg.category && (
                      <div className="text-xs text-muted-foreground">{sugg.category}</div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
        <Button
          onClick={() => handleSearch(query)}
          disabled={!query.trim() || isSearching}
          size="lg"
        >
          Search
        </Button>
      </div>

      <div className="flex flex-wrap gap-2 text-xs">
        {market.recentSearches?.slice(0, 3).map((search) => (
          <button
            key={search}
            onClick={() => handleSearch(search)}
            className="px-2 py-1 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
          >
            {search}
          </button>
        ))}
      </div>
    </div>
  )
}
