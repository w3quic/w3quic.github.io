"use client"

import { useMemo, useState } from "react"
import Image from "next/image"
import {
  ChevronLeft, ChevronRight, Heart, Share2, Shield, Truck, Gavel, Zap,
  MessageCircle, Flag, Store, Clock, AlertTriangle, Tag,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { CURRENT_USER_ID } from "@/lib/market/seed"
import { effectivePrice, formatPi, countdown, estimateDelivery, isReserved } from "@/lib/market/helpers"
import { getRecommendations } from "@/lib/market/adapters"
import { RatingStars, VerifiedBadge, Pill } from "./ui-bits"
import { ProductCard } from "./product-card"
import { ReportDialog } from "./report-dialog"
import { EscrowPaymentButton } from "./escrow-payment-button"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogClose } from "@/components/ui/dialog"
import { toast } from "@/hooks/use-toast"

export function ProductView({ id }: { id: string; onOpenAssistant?: () => void }) {
  const market = useMarket()
  const { getProduct, getSeller, getStore, reviews, wishlist, toggleWishlist, addToCart, products } = market
  const { go } = useNav()
  const product = getProduct(id)
  const [imgIdx, setImgIdx] = useState(0)
  const [variationId, setVariationId] = useState<string | undefined>(undefined)
  const [bid, setBid] = useState("")
  const [offer, setOffer] = useState("")

  const seller = product ? getSeller(product.sellerId) : undefined
  const store = product ? getStore(product.sellerId) : undefined
  const productReviews = useMemo(() => reviews.filter((r) => r.productId === id), [reviews, id])
  const related = useMemo(
    () => (product ? getRecommendations(products, { category: product.category, sellerId: product.sellerId, excludeId: product.id, count: 6 }) : []),
    [product, products],
  )

  if (!product || !seller) {
    return (
      <Empty className="py-20">
        <EmptyHeader><EmptyMedia variant="icon"><Tag /></EmptyMedia><EmptyTitle>Product not found</EmptyTitle></EmptyHeader>
        <Button variant="outline" onClick={() => go({ name: "home" })}>Back home</Button>
      </Empty>
    )
  }

  const variation = product.variations.find((v) => v.id === variationId)
  const onDeal = product.flashDeal && product.flashDeal.endsAt > Date.now()
  const isAuction = product.auction && product.auction.endsAt > Date.now()
  const price = variation ? variation.price : effectivePrice(product)
  const stock = variation ? variation.stock : product.stock
  const reserved = isReserved(product, CURRENT_USER_ID)
  const liked = wishlist.includes(product.id)
  const vacation = store?.vacation?.enabled

  const highestBid = product.auction
    ? product.auction.bids.reduce((m, b) => Math.max(m, b.amount), product.auction.startingBid)
    : 0
  const minBid = product.auction ? highestBid + product.auction.minIncrement : 0

  const needsVariation = product.variations.length > 0 && !variationId

  const handleAddToCart = () => {
    if (needsVariation) { toast({ title: "Select an option first" }); return }
    addToCart(product.id, variationId, 1)
    toast({ title: "Added to cart", description: product.title })
  }

  const handleBuyNow = () => {
    if (needsVariation) { toast({ title: "Select an option first" }); return }
    addToCart(product.id, variationId, 1)
    market.reserveProduct(product.id)
    go({ name: "checkout" })
  }

  const placeBid = () => {
    const amt = Number.parseFloat(bid)
    if (!amt || amt < minBid) { toast({ title: `Bid must be at least ${formatPi(minBid)}` }); return }
    market.updateProduct(product.id, {
      auction: { ...product.auction!, bids: [...product.auction!.bids, { userId: CURRENT_USER_ID, amount: amt, at: Date.now() }] },
    })
    setBid("")
    toast({ title: "Bid placed!", description: `You are the highest bidder at ${formatPi(amt)}` })
  }

  const sendOffer = () => {
    const amt = Number.parseFloat(offer)
    if (!amt || amt <= 0) return
    const cid = market.getOrCreateConversation(product.sellerId, product.id)
    market.sendMessage(cid, `I'd like to offer ${formatPi(amt)} for "${product.title}"`, { amount: amt, status: "pending", round: 1 })
    toast({ title: "Offer sent", description: "Check Messages for the seller's response." })
    go({ name: "messages", conversationId: cid })
  }

  const contactSeller = () => {
    const cid = market.getOrCreateConversation(product.sellerId, product.id)
    go({ name: "messages", conversationId: cid })
  }

  const share = async () => {
    const data = { title: product.title, text: `${product.title} - ${formatPi(price)} on Pi Market Hub`, url: typeof window !== "undefined" ? window.location.href : "" }
    try {
      if (navigator.share) await navigator.share(data)
      else { await navigator.clipboard.writeText(data.url); toast({ title: "Link copied" }) }
    } catch {}
  }

  return (
    <div className="animate-fade-in pb-24 lg:pb-6">
      <div className="lg:grid lg:grid-cols-2 lg:gap-6 lg:px-4 lg:py-4">
        {/* Gallery */}
        <div className="relative aspect-square w-full overflow-hidden bg-muted lg:rounded-xl">
          <Image src={product.images[imgIdx] || "/placeholder.svg"} alt={`${product.title} image ${imgIdx + 1}`} fill sizes="(max-width:1024px) 100vw, 50vw" className="object-cover" priority />
          {product.images.length > 1 && (
            <>
              <button onClick={() => setImgIdx((i) => (i - 1 + product.images.length) % product.images.length)} className="absolute left-2 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/80 backdrop-blur" aria-label="Previous image"><ChevronLeft className="h-5 w-5" /></button>
              <button onClick={() => setImgIdx((i) => (i + 1) % product.images.length)} className="absolute right-2 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/80 backdrop-blur" aria-label="Next image"><ChevronRight className="h-5 w-5" /></button>
              <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1.5">
                {product.images.map((_, i) => <span key={i} className={cn("h-1.5 rounded-full transition-all", i === imgIdx ? "w-4 bg-primary" : "w-1.5 bg-background/70")} />)}
              </div>
            </>
          )}
          <div className="absolute right-2 top-2 flex gap-2">
            <button onClick={share} className="flex h-9 w-9 items-center justify-center rounded-full bg-background/80 backdrop-blur" aria-label="Share"><Share2 className="h-4 w-4" /></button>
            <button onClick={() => toggleWishlist(product.id)} className="flex h-9 w-9 items-center justify-center rounded-full bg-background/80 backdrop-blur" aria-label="Wishlist"><Heart className={cn("h-4 w-4", liked && "fill-rose-500 text-rose-500")} /></button>
          </div>
          <span className="absolute left-2 top-2 flex flex-wrap gap-1">
            {onDeal && <Pill className="bg-rose-500 text-white"><Zap className="h-3 w-3" />-{product.flashDeal!.discountPercent}%</Pill>}
            {isAuction && <Pill className="bg-amber-500 text-white"><Gavel className="h-3 w-3" />Auction</Pill>}
            {product.featured && <Pill className="bg-primary text-primary-foreground">Featured</Pill>}
          </span>
        </div>

        <div className="px-4 py-4 lg:p-0">
          {product.scamScore >= 60 && (
            <div className="mb-3 flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>This listing was flagged by our AI scam detection. Proceed with caution and use buyer protection.</span>
            </div>
          )}

          <h1 className="text-pretty text-xl font-bold leading-snug">{product.title}</h1>

          <div className="mt-2 flex items-baseline gap-2">
            {isAuction ? (
              <><span className="text-2xl font-bold text-primary">{formatPi(highestBid)}</span><span className="text-xs text-muted-foreground">current bid</span></>
            ) : (
              <><span className="text-2xl font-bold text-primary">{formatPi(price)}</span>{onDeal && <span className="text-sm text-muted-foreground line-through">{formatPi(product.price)}</span>}</>
            )}
          </div>

          {onDeal && <p className="mt-1 flex items-center gap-1 text-sm font-medium text-rose-500"><Clock className="h-4 w-4" />Flash deal ends in {countdown(product.flashDeal!.endsAt)}</p>}

          {/* Seller row */}
          <button onClick={() => go({ name: "store", sellerId: seller.id })} className="mt-3 flex w-full items-center gap-2 rounded-lg border border-border p-2.5 text-left">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary"><Store className="h-4 w-4" /></span>
            <span className="flex-1">
              <span className="flex items-center gap-1.5 text-sm font-semibold">{seller.displayName}<VerifiedBadge level={seller.verification} /></span>
              <RatingStars value={seller.rating} size={11} showValue count={seller.ratingCount} />
            </span>
            <span className="text-right text-xs text-muted-foreground">Rep<br /><span className="text-sm font-bold text-foreground">{seller.reputationScore}</span></span>
          </button>

          {/* Variations */}
          {product.variations.length > 0 && (
            <div className="mt-4">
              <Label className="text-sm">Options</Label>
              <div className="mt-1.5 flex flex-wrap gap-2">
                {product.variations.map((v) => (
                  <button key={v.id} onClick={() => setVariationId(v.id)} disabled={v.stock === 0}
                    className={cn("rounded-lg border px-3 py-1.5 text-sm transition-colors disabled:opacity-40",
                      variationId === v.id ? "border-primary bg-primary/10 text-primary" : "border-border")}>
                    {v.name} · {formatPi(v.price)}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Stock / delivery */}
          <div className="mt-4 grid gap-2 text-sm">
            <p className="flex items-center gap-2 text-muted-foreground"><Truck className="h-4 w-4 text-primary" />Estimated delivery: <span className="font-medium text-foreground">{estimateDelivery(product.handlingTimeDays)}</span></p>
            <p className="flex items-center gap-2 text-muted-foreground"><Shield className="h-4 w-4 text-primary" />Buyer protection with escrow payment</p>
            {!isAuction && stock <= 5 && stock > 0 && <p className="font-medium text-orange-500">Hurry — only {stock} left in stock</p>}
            {reserved && <p className="flex items-center gap-2 font-medium text-amber-600"><Clock className="h-4 w-4" />Reserved by another buyer</p>}
            {vacation && <p className="rounded bg-amber-500/10 p-2 text-amber-700 dark:text-amber-400">Store on vacation — orders fulfilled after {store?.vacation?.returnDate || "return"}.</p>}
          </div>

          {/* Description */}
          <div className="mt-4">
            <h2 className="mb-1 text-sm font-semibold">Description</h2>
            <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{product.description}</p>
          </div>

          {/* Auction bidding */}
          {isAuction && (
            <div className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/5 p-3">
              <p className="flex items-center gap-2 text-sm font-semibold text-amber-700 dark:text-amber-400"><Gavel className="h-4 w-4" />Live auction · {countdown(product.auction!.endsAt)} left</p>
              <p className="mt-1 text-xs text-muted-foreground">{product.auction!.bids.length} bids · Min next bid {formatPi(minBid)}{product.auction!.reserve ? ` · Reserve ${formatPi(product.auction!.reserve)}` : ""}</p>
              <div className="mt-2 flex gap-2">
                <Input type="number" value={bid} onChange={(e) => setBid(e.target.value)} placeholder={`${minBid}`} aria-label="Bid amount" />
                <Button onClick={placeBid}>Place bid</Button>
              </div>
            </div>
          )}

          {/* Action buttons */}
          {!isAuction && (
            <div className="mt-4 hidden gap-2 lg:flex">
              <Button variant="outline" className="flex-1" onClick={handleAddToCart} disabled={stock === 0 || reserved}>Add to cart</Button>
              <Button className="flex-1" onClick={handleBuyNow} disabled={stock === 0 || reserved}>Buy now</Button>
            </div>
          )}

          {/* Secondary actions */}
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={contactSeller}><MessageCircle className="mr-1 h-4 w-4" />Contact seller</Button>
            {!isAuction && (
              <Dialog>
                <DialogTrigger asChild><Button variant="outline" size="sm"><Tag className="mr-1 h-4 w-4" />Make an offer</Button></DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Make an offer</DialogTitle></DialogHeader>
                  <div className="grid gap-2">
                    <Label>Your offer (listing price {formatPi(price)})</Label>
                    <Input type="number" value={offer} onChange={(e) => setOffer(e.target.value)} placeholder="Enter amount in π" />
                  </div>
                  <DialogFooter><DialogClose asChild><Button onClick={sendOffer}>Send offer</Button></DialogClose></DialogFooter>
                </DialogContent>
              </Dialog>
            )}
            <ReportDialog targetType="product" targetId={product.id} trigger={<Button variant="ghost" size="sm" className="text-muted-foreground"><Flag className="mr-1 h-4 w-4" />Report</Button>} />
          </div>

          {/* Escrow Protection */}
          <div className="mt-4">
            <EscrowPaymentButton fullWidth variant="default" />
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-6 px-4">
        <h2 className="mb-2 text-base font-bold">Reviews ({productReviews.length})</h2>
        {productReviews.length === 0 ? (
          <p className="text-sm text-muted-foreground">No reviews yet for this product.</p>
        ) : (
          <div className="space-y-3">
            {productReviews.map((r) => (
              <div key={r.id} className="rounded-lg border border-border p-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{r.buyerName}</span>
                  <RatingStars value={r.rating} size={12} />
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{r.text}</p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="mt-6 px-4">
          <h2 className="mb-2 text-base font-bold">Related products</h2>
          <div className="no-scrollbar flex gap-3 overflow-x-auto pb-2">
            {related.map((p) => <ProductCard key={p.id} product={p} compact />)}
          </div>
        </section>
      )}

      {/* Sticky mobile buy bar */}
      {!isAuction && (
        <div className="fixed inset-x-0 bottom-16 z-30 mx-auto flex max-w-2xl gap-2 border-t border-border bg-background/95 p-3 backdrop-blur lg:hidden">
          <Button variant="outline" className="flex-1" onClick={handleAddToCart} disabled={stock === 0 || reserved}>Add to cart</Button>
          <Button className="flex-1" onClick={handleBuyNow} disabled={stock === 0 || reserved}>Buy now</Button>
        </div>
      )}
    </div>
  )
}
