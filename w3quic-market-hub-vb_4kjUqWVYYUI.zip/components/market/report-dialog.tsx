"use client"

import { useState } from "react"
import { useMarket } from "@/lib/market/store"
import type { Report } from "@/lib/market/types"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogClose,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"

const REASONS = ["Counterfeit / fake", "Scam or fraud", "Prohibited item", "Offensive content", "Wrong category", "Spam", "Other"]

export function ReportDialog({ targetType, targetId, trigger }: { targetType: Report["targetType"]; targetId: string; trigger: React.ReactNode }) {
  const { addReport } = useMarket()
  const [reason, setReason] = useState(REASONS[0])
  const [desc, setDesc] = useState("")

  return (
    <Dialog>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Report {targetType}</DialogTitle></DialogHeader>
        <div className="grid gap-3">
          <div className="grid gap-1.5">
            <Label>Reason</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{REASONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label>Details (optional)</Label>
            <Textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Add more context..." rows={3} />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button onClick={() => { addReport({ reporterId: "me", targetType, targetId, reason, description: desc }); toast({ title: "Report submitted", description: "Our team will review it shortly." }) }}>
              Submit report
            </Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
