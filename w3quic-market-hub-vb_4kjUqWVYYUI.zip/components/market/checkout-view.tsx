"use client"

import { useMemo, useState, useEffect } from "react"
import { Shield, Tag, Truck, Check, Sparkles, Clock } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { CURRENT_USER_ID } from "@/lib/market/seed"
import { effectivePrice, formatPi, estimateDelivery, countdown } from "@/lib/market/helpers"
import { getShippingRate, calculateTax } from "@/lib/market/adapters"
import type { OrderItem } from "@/lib/market/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { EscrowPaymentButton } from "./escrow-payment-button"
import { toast } from "@/hooks/use-toast"

export function CheckoutView() {
  const market = useMarket()
  const { cart, getProduct, coupons, me, placeOrder, clearCart } = market
  const { go } = useNav()
  const [coupon, setCoupon] = useState("")
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discountPercent: number } | null>(null)
  const [region, setRegion] = useState("")
  const [useLoyalty, setUseLoyalty] = useState(false)
  const [, tick] = useState(0)

  useEffect(() => { const t = setInterval(() => tick((n) => n + 1), 1000); return () => clearInterval(t) }, [])

  const lines = useMemo(() => cart.map((c) => {
    const p = getProduct(c.productId)
    if (!p) return null
    const v = p.variations.find((x) => x.id === c.variationId)
    const price = v ? v.price : effectivePrice(p)
    return { p, v, c, price }
  }).filter(Boolean) as { p: NonNullable<ReturnType<typeof getProduct>>; v: any; c: typeof cart[number]; price: number }[], [cart, getProduct])

  const subtotal = lines.reduce((s, l) => s + l.price * l.c.quantity, 0)
  const couponDiscount = appliedCoupon ? Math.round(subtotal * appliedCoupon.discountPercent) / 100 : 0
  const shipping = region ? getShippingRate(region) : 0
  const tax = calculateTax(subtotal, region, "")
  const maxLoyaltyDiscount = Math.min(Math.floor(me.loyaltyPoints / 10), Math.floor((subtotal - couponDiscount)))
  const loyaltyDiscount = useLoyalty ? maxLoyaltyDiscount : 0
  const loyaltyUsed = loyaltyDiscount * 10
  const total = Math.max(0, subtotal - couponDiscount - loyaltyDiscount + shipping + tax)

  const sellerId = lines[0]?.p.sellerId || ""
  const reservedUntil = lines[0]?.p.reservedUntil

  if (lines.length === 0) {
    return (
      <div className="px-4 py-6">
        <Empty>
          <EmptyHeader><EmptyMedia variant="icon"><Tag /></EmptyMedia><EmptyTitle>Nothing to check out</EmptyTitle></EmptyHeader>
          <Button onClick={() => go({ name: "browse" })}>Browse products</Button>
        </Empty>
      </div>
    )
  }

  const applyCoupon = () => {
    const found = coupons.find((c) => c.code.toLowerCase() === coupon.trim().toLowerCase())
    if (found) { setAppliedCoupon(found); toast({ title: `Coupon applied: ${found.discountPercent}% off` }) }
    else toast({ title: "Invalid coupon code", variant: "destructive" })
  }

  const confirm = () => {
    const handling = Math.max(...lines.map((l) => l.p.handlingTimeDays))
    const items: OrderItem[] = lines.map((l) => ({
      productId: l.p.id, title: l.p.title, image: l.p.images[0], variationId: l.v?.id, variationName: l.v?.name,
      price: l.price, quantity: l.c.quantity,
    }))
    const order = placeOrder({
      buyerId: CURRENT_USER_ID, sellerId, items, subtotal,
      discount: couponDiscount + loyaltyDiscount, shipping, tax, total, loyaltyUsed,
      shippingRegion: region || "Standard", estimatedDelivery: estimateDelivery(handling),
    })
    if (loyaltyUsed > 0) market.spendLoyalty(loyaltyUsed)
    market.addLoyalty(Math.floor(total))
    clearCart()
    toast({ title: "Order placed!", description: `Payment held in escrow. You earned ${Math.floor(total)} loyalty points.` })
    go({ name: "order", id: order.id })
  }

  return (
    <div className="animate-fade-in px-4 py-4 pb-28">
      <h1 className="mb-1 text-xl font-bold">Checkout</h1>
      {reservedUntil && reservedUntil > Date.now() && (
        <p className="mb-3 flex items-center gap-1.5 text-sm font-medium text-amber-600"><Clock className="h-4 w-4" />Reserved for you · {countdown(reservedUntil)}</p>
      )}

      {/* Items */}
      <section className="rounded-xl border border-border bg-card p-3">
        <h2 className="mb-2 text-sm font-semibold">Order summary</h2>
        <div className="space-y-2">
          {lines.map((l) => (
            <div key={`${l.p.id}-${l.v?.id}`} className="flex justify-between text-sm">
              <span className="text-muted-foreground">{l.p.title}{l.v ? ` (${l.v.name})` : ""} × {l.c.quantity}</span>
              <span className="font-medium">{formatPi(l.price * l.c.quantity)}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Coupon */}
      <section className="mt-3 rounded-xl border border-border bg-card p-3">
        <Label className="text-sm">Coupon code</Label>
        <div className="mt-1.5 flex gap-2">
          <Input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="e.g. PI10" />
          <Button variant="outline" onClick={applyCoupon}>Apply</Button>
        </div>
        {appliedCoupon && <p className="mt-1 flex items-center gap-1 text-xs text-green-600"><Check className="h-3 w-3" />{appliedCoupon.code} applied</p>}
        <p className="mt-1 text-xs text-muted-foreground">Try: PI10, WELCOME, FLASH20</p>
      </section>

      {/* Shipping */}
      <section className="mt-3 rounded-xl border border-border bg-card p-3">
        <Label className="flex items-center gap-1.5 text-sm"><Truck className="h-4 w-4 text-primary" />Delivery region</Label>
        <Input className="mt-1.5" value={region} onChange={(e) => setRegion(e.target.value)} placeholder="Enter your city / region" />
        {region && <p className="mt-1 text-xs text-muted-foreground">Estimated shipping: {formatPi(shipping)} · Delivery {estimateDelivery(Math.max(...lines.map((l) => l.p.handlingTimeDays)))}</p>}
      </section>

      {/* Loyalty */}
      {maxLoyaltyDiscount > 0 && (
        <section className="mt-3 flex items-center justify-between rounded-xl border border-border bg-card p-3">
          <div>
            <Label className="flex items-center gap-1.5 text-sm"><Sparkles className="h-4 w-4 text-primary" />Use loyalty points</Label>
            <p className="text-xs text-muted-foreground">{me.loyaltyPoints} pts available · save up to {formatPi(maxLoyaltyDiscount)}</p>
          </div>
          <Switch checked={useLoyalty} onCheckedChange={setUseLoyalty} />
        </section>
      )}

      {/* Totals */}
      <section className="mt-3 rounded-xl border border-border bg-card p-3 text-sm">
        <Row label="Subtotal" value={formatPi(subtotal)} />
        {couponDiscount > 0 && <Row label="Coupon discount" value={`-${formatPi(couponDiscount)}`} green />}
        {loyaltyDiscount > 0 && <Row label="Loyalty discount" value={`-${formatPi(loyaltyDiscount)}`} green />}
        <Row label="Shipping" value={shipping ? formatPi(shipping) : "—"} />
        <Row label="Tax" value={formatPi(tax)} />
        <div className="my-2 border-t border-border" />
        <div className="flex justify-between text-base font-bold"><span>Total</span><span className="text-primary">{formatPi(total)}</span></div>
      </section>

      <div className="mt-3 flex items-start gap-2 rounded-lg bg-primary/5 p-3 text-xs text-muted-foreground">
        <Shield className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        Your payment is held securely in escrow and released to the seller only after you confirm delivery.
      </div>

      <div className="mt-3 flex gap-2">
        <EscrowPaymentButton className="flex-1" variant="outline" />
      </div>

      <div className="fixed inset-x-0 bottom-16 z-30 mx-auto max-w-2xl border-t border-border bg-background/95 p-4 backdrop-blur lg:bottom-0">
        <Button className="w-full" size="lg" onClick={confirm}>Pay {formatPi(total)} with Pi (Escrow)</Button>
      </div>
    </div>
  )
}

function Row({ label, value, green }: { label: string; value: string; green?: boolean }) {
  return <div className="flex justify-between py-0.5"><span className="text-muted-foreground">{label}</span><span className={green ? "font-medium text-green-600" : "font-medium"}>{value}</span></div>
}
