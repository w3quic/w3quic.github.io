"use client"

import { ReactNode } from "react"
import { cn } from "@/lib/utils"

/**
 * Modern Card Component
 * Used for displaying content in a structured, elevated container
 */
export function Card({
  children,
  className,
  hover = true,
  animated = true,
}: {
  children: ReactNode
  className?: string
  hover?: boolean
  animated?: boolean
}) {
  return (
    <div
      className={cn(
        "rounded-lg border border-border bg-card p-4",
        "transition-all duration-300",
        hover && "hover:shadow-md hover:border-primary/50",
        animated && "animate-fade-up",
        className,
      )}
    >
      {children}
    </div>
  )
}

/**
 * Premium Card Component
 * Used for premium features, highlighted sections
 */
export function PremiumCard({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-accent p-4",
        "shadow-sm hover:shadow-md hover:border-primary/50",
        "transition-all duration-300 animate-fade-up",
        className,
      )}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/0 to-primary/5 pointer-events-none" />
      <div className="relative z-10">{children}</div>
    </div>
  )
}

/**
 * Alert Component
 * Used for displaying important messages
 */
export function Alert({
  type = "info",
  title,
  message,
  children,
  className,
}: {
  type?: "success" | "error" | "warning" | "info"
  title?: string
  message?: string
  children?: ReactNode
  className?: string
}) {
  const typeStyles = {
    success: "bg-green-50 dark:bg-green-500/10 border-green-200 dark:border-green-500/30 text-green-900 dark:text-green-200",
    error: "bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/30 text-red-900 dark:text-red-200",
    warning: "bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/30 text-amber-900 dark:text-amber-200",
    info: "bg-blue-50 dark:bg-blue-500/10 border-blue-200 dark:border-blue-500/30 text-blue-900 dark:text-blue-200",
  }

  return (
    <div
      className={cn(
        "rounded-lg border p-4 animate-slide-in-right",
        typeStyles[type],
        className,
      )}
    >
      {title && <h3 className="font-semibold mb-1">{title}</h3>}
      {message && <p className="text-sm">{message}</p>}
      {children}
    </div>
  )
}

/**
 * Button Component
 * Unified button styling for consistency
 */
export function Button({
  children,
  variant = "default",
  size = "md",
  disabled = false,
  loading = false,
  className,
  ...props
}: {
  children: ReactNode
  variant?: "default" | "secondary" | "ghost" | "destructive"
  size?: "sm" | "md" | "lg"
  disabled?: boolean
  loading?: boolean
  className?: string
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const variantStyles = {
    default: "bg-primary text-primary-foreground hover:bg-primary/90",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    ghost: "hover:bg-muted",
    destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
  }

  const sizeStyles = {
    sm: "px-2.5 py-1.5 text-xs font-medium rounded-md",
    md: "px-4 py-2 text-sm font-semibold rounded-lg",
    lg: "px-6 py-3 text-base font-semibold rounded-lg",
  }

  return (
    <button
      disabled={disabled || loading}
      className={cn(
        "transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed",
        variantStyles[variant],
        sizeStyles[size],
        loading && "opacity-75 cursor-wait",
        className,
      )}
      {...props}
    >
      {loading ? <span className="inline-block animate-spin-slow">⟳</span> : children}
    </button>
  )
}

/**
 * Badge Component
 * Used for status indicators, tags
 */
export function Badge({
  children,
  variant = "default",
  className,
}: {
  children: ReactNode
  variant?: "default" | "success" | "warning" | "error" | "info"
  className?: string
}) {
  const variantStyles = {
    default: "bg-secondary text-secondary-foreground",
    success: "bg-green-100 dark:bg-green-500/20 text-green-700 dark:text-green-400",
    warning: "bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-400",
    error: "bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-400",
    info: "bg-blue-100 dark:bg-blue-500/20 text-blue-700 dark:text-blue-400",
  }

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold whitespace-nowrap",
        variantStyles[variant],
        className,
      )}
    >
      {children}
    </span>
  )
}

/**
 * Section Component
 * Used for organizing content sections
 */
export function Section({
  title,
  subtitle,
  children,
  className,
}: {
  title?: string
  subtitle?: string
  children: ReactNode
  className?: string
}) {
  return (
    <section className={cn("space-y-4", className)}>
      {title && (
        <div className="space-y-1">
          <h2 className="text-lg font-bold text-foreground">{title}</h2>
          {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      )}
      {children}
    </section>
  )
}

/**
 * Grid Component
 * Used for layout grids (products, items, etc.)
 */
export function Grid({
  children,
  cols = 2,
  gap = "md",
}: {
  children: ReactNode
  cols?: 1 | 2 | 3 | 4
  gap?: "sm" | "md" | "lg"
}) {
  const colsMap = { 1: "grid-cols-1", 2: "grid-cols-2", 3: "grid-cols-3", 4: "grid-cols-4" }
  const gapMap = { sm: "gap-2", md: "gap-4", lg: "gap-6" }

  return (
    <div className={cn("grid", colsMap[cols], gapMap[gap])}>
      {children}
    </div>
  )
}

/**
 * Stack Component
 * Used for vertical/horizontal stacking
 */
export function Stack({
  direction = "vertical",
  gap = "md",
  align = "start",
  justify = "start",
  children,
  className,
}: {
  direction?: "vertical" | "horizontal"
  gap?: "xs" | "sm" | "md" | "lg" | "xl"
  align?: "start" | "center" | "end" | "stretch"
  justify?: "start" | "center" | "end" | "between"
  children: ReactNode
  className?: string
}) {
  const gapMap = { xs: "gap-1", sm: "gap-2", md: "gap-4", lg: "gap-6", xl: "gap-8" }
  const alignMap = { start: "items-start", center: "items-center", end: "items-end", stretch: "items-stretch" }
  const justifyMap = { start: "justify-start", center: "justify-center", end: "justify-end", between: "justify-between" }

  return (
    <div
      className={cn(
        "flex",
        direction === "vertical" ? "flex-col" : "flex-row",
        gapMap[gap],
        alignMap[align],
        justifyMap[justify],
        className,
      )}
    >
      {children}
    </div>
  )
}

/**
 * Text Component
 * Used for consistent typography
 */
export function Text({
  variant = "body",
  children,
  className,
}: {
  variant?: "h1" | "h2" | "h3" | "h4" | "body" | "caption" | "label"
  children: ReactNode
  className?: string
}) {
  const variantStyles = {
    h1: "text-3xl font-bold",
    h2: "text-2xl font-bold",
    h3: "text-lg font-bold",
    h4: "text-base font-semibold",
    body: "text-sm font-normal",
    caption: "text-xs text-muted-foreground",
    label: "text-xs font-semibold uppercase tracking-wider",
  }

  return <span className={cn(variantStyles[variant], className)}>{children}</span>
}

/**
 * Divider Component
 * Used for visual separation
 */
export function Divider({ className }: { className?: string }) {
  return <div className={cn("border-t border-border", className)} />
}

export default {
  Card,
  PremiumCard,
  Alert,
  Button,
  Badge,
  Section,
  Grid,
  Stack,
  Text,
  Divider,
}
