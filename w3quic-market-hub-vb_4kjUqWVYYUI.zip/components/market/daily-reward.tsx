"use client"

import { useEffect, useState } from "react"
import { Gift, X, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useMarket } from "@/lib/market/store"
import { cn } from "@/lib/utils"

export function DailyReward() {
  const { me, claimDailyReward } = useMarket()
  const [open, setOpen] = useState(false)
  const [claimed, setClaimed] = useState(false)
  const [reward, setReward] = useState(0)

  useEffect(() => {
    const today = new Date().toDateString()
    const last = me.lastLogin ? new Date(me.lastLogin).toDateString() : null
    if (last !== today) {
      const t = setTimeout(() => setOpen(true), 800)
      return () => clearTimeout(t)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (!open) return null

  const nextStreak = (() => {
    const yesterday = new Date(Date.now() - 86400000).toDateString()
    const last = me.lastLogin ? new Date(me.lastLogin).toDateString() : null
    return last === yesterday ? Math.min(7, me.loginStreak + 1) : 1
  })()

  const handleClaim = () => {
    const r = claimDailyReward()
    setReward(r)
    setClaimed(true)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4 backdrop-blur-sm">
      <div className="w-full max-w-sm overflow-hidden rounded-2xl border border-border bg-card shadow-xl animate-fade-up">
        <div className="relative bg-primary px-6 py-5 text-center text-primary-foreground">
          <button onClick={() => setOpen(false)} aria-label="Close" className="absolute right-3 top-3 rounded-full p-1 hover:bg-primary-foreground/20">
            <X className="h-5 w-5" />
          </button>
          <Gift className="mx-auto h-10 w-10" />
          <h2 className="mt-2 text-lg font-bold">Daily Login Reward</h2>
          <p className="text-sm opacity-90">{claimed ? `You earned ${reward} loyalty points!` : "Claim your loyalty points!"}</p>
        </div>
        <div className="p-5">
          <div className="grid grid-cols-7 gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7].map((d) => (
              <div
                key={d}
                className={cn(
                  "flex aspect-square flex-col items-center justify-center rounded-lg border text-center",
                  d === nextStreak && !claimed ? "border-primary bg-accent animate-pulse-ring" : "border-border bg-muted",
                  claimed && d <= nextStreak ? "border-primary bg-accent" : "",
                )}
              >
                <span className="text-[9px] text-muted-foreground">Day {d}</span>
                <span className="text-sm font-bold text-foreground">{d}</span>
              </div>
            ))}
          </div>
          <Button onClick={claimed ? () => setOpen(false) : handleClaim} className="mt-4 w-full">
            {claimed ? <><Check className="mr-1 h-4 w-4" />Done</> : `Claim Day ${nextStreak} Reward`}
          </Button>
        </div>
      </div>
    </div>
  )
}
