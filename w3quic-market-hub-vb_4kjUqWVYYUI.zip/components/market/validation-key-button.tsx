'use client';

import { useState } from 'react';
import { Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';

interface ValidationKeyButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline' | 'secondary';
  fullWidth?: boolean;
  showLabel?: boolean;
}

export function ValidationKeyButton({ 
  onSuccess, 
  variant = 'default',
  fullWidth = false,
  showLabel = true 
}: ValidationKeyButtonProps) {
  const { products, sdk, restoredPurchases } = usePiAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Find the product
  const product = products?.find(p => p.id === PRODUCT_CONFIG.PRODUCT_6a3a12e0ee4ee283a712b3dc);

  // Check if already purchased
  const isPurchased = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Validation key product not available');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result.ok) {
        setSuccess(true);
        onSuccess?.();
      } else {
        setError('Purchase failed');
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Validation key product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      setError(errorMessages[errorCode] || 'Purchase failed');
    } finally {
      setIsLoading(false);
    }
  };

  if (!product) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <Key className="mr-2 h-4 w-4" />
        Validation Key Unavailable
      </Button>
    );
  }

  if (isPurchased) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <Key className="mr-2 h-4 w-4" />
        Validation Key Purchased
      </Button>
    );
  }

  const buttonClass = fullWidth ? 'w-full' : '';
  const buttonLabel = showLabel 
    ? `Unlock Premium (${product.price_in_pi} π)` 
    : `${product.price_in_pi} π`;

  return (
    <div className="space-y-2">
      <Button
        onClick={handlePurchase}
        disabled={isLoading}
        variant={variant}
        className={`${buttonClass} ${
          variant === 'default' 
            ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800' 
            : ''
        }`}
      >
        <Key className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing...' : `Validation Key (${product.price_in_pi} π)`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          Validation key activated! Your premium features are now unlocked.
        </div>
      )}
    </div>
  );
}
