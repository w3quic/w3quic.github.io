'use client'

import { useState } from 'react'
import { Search, Mic, ImageIcon, Filter, X, ChevronDown } from 'lucide-react'
import { useMarket } from '@/lib/market/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { CATEGORIES } from '@/lib/market/types'
import type { Category, Condition } from '@/lib/market/types'
import { ProductCard } from './product-card'

interface AdvancedSearchProps {
  onClose?: () => void
}

export function AdvancedSearch({ onClose }: AdvancedSearchProps) {
  const market = useMarket()
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<Category | ''>('')
  const [minPrice, setMinPrice] = useState<number | ''>('')
  const [maxPrice, setMaxPrice] = useState<number | ''>('')
  const [condition, setCondition] = useState<Condition | ''>('')
  const [location, setLocation] = useState('')
  const [sortBy, setSortBy] = useState<'relevance' | 'price-asc' | 'price-desc' | 'newest' | 'popular'>('relevance')
  const [isListening, setIsListening] = useState(false)
  const [showImageSearch, setShowImageSearch] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [hasSearched, setHasSearched] = useState(false)

  const handleSearch = (e?: React.FormEvent) => {
    e?.preventDefault()

    const searchContext = {
      query,
      category: category || undefined,
      minPrice: minPrice ? Number(minPrice) : undefined,
      maxPrice: maxPrice ? Number(maxPrice) : undefined,
      condition: condition || undefined,
      location: location || undefined,
      sortBy,
    }

    const results = market.performSmartSearch(searchContext)
    setSearchResults(results)
    setHasSearched(true)
  }

  const handleVoiceSearch = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Voice search not supported in your browser')
      return
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
    const recognition = new SpeechRecognition()

    recognition.onstart = () => setIsListening(true)
    recognition.onend = () => setIsListening(false)

    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0].transcript)
        .join('')

      setQuery(transcript)
      if (event.isFinal) {
        setQuery(transcript)
      }
    }

    recognition.start()
  }

  const handleImageSearch = () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'image/*'
    input.onchange = (e: any) => {
      const file = e.target.files?.[0]
      if (file) {
        // Future: Process image to extract features
        alert(
          'Image search is a future feature. Image processing would be handled by a vision API.',
        )
        setShowImageSearch(false)
      }
    }
    input.click()
  }

  const clearFilters = () => {
    setQuery('')
    setCategory('')
    setMinPrice('')
    setMaxPrice('')
    setCondition('')
    setLocation('')
    setSortBy('relevance')
    setSearchResults([])
    setHasSearched(false)
  }

  const conditions: Condition[] = ['new', 'like-new', 'good', 'fair']
  const locations = ['Singapore', 'Milan', 'Amsterdam', 'Denver', 'Geneva', 'New York']

  return (
    <div className="space-y-6">
      {/* Search Form */}
      <form onSubmit={handleSearch} className="space-y-4 bg-card border border-border rounded-lg p-6">
        <div className="space-y-4">
          {/* Main Search Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium">What are you looking for?</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="E.g., 'laptop under 500', 'vintage watch'"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleVoiceSearch}
                disabled={isListening}
                title="Voice Search"
              >
                <Mic
                  className={`w-4 h-4 ${isListening ? 'animate-pulse text-red-500' : ''}`}
                />
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleImageSearch}
                title="Image Search (Future)"
              >
                <ImageIcon className="w-4 h-4" />
              </Button>
            </div>
            {isListening && (
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <span className="animate-pulse">●</span> Listening...
              </div>
            )}
          </div>

          {/* Filters Row 1 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category | '')}
                className="w-full px-3 py-2 border border-border rounded-md bg-background text-sm"
              >
                <option value="">All Categories</option>
                {CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Condition</label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as Condition | '')}
                className="w-full px-3 py-2 border border-border rounded-md bg-background text-sm"
              >
                <option value="">Any Condition</option>
                {conditions.map((cond) => (
                  <option key={cond} value={cond}>
                    {cond.charAt(0).toUpperCase() + cond.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Filters Row 2 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Min Price (π)</label>
              <Input
                type="number"
                placeholder="0"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value ? Number(e.target.value) : '')}
                min="0"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Max Price (π)</label>
              <Input
                type="number"
                placeholder="10000"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : '')}
                min="0"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Location</label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-md bg-background text-sm"
              >
                <option value="">Any Location</option>
                {locations.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Sort By */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Sort By</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="w-full px-3 py-2 border border-border rounded-md bg-background text-sm"
            >
              <option value="relevance">Most Relevant</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="newest">Newest First</option>
              <option value="popular">Most Popular</option>
            </select>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-4">
          <Button type="submit" className="flex-1">
            <Search className="w-4 h-4 mr-2" />
            Search
          </Button>
          <Button type="button" variant="outline" onClick={clearFilters}>
            Clear
          </Button>
          {onClose && (
            <Button type="button" variant="outline" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      </form>

      {/* Results */}
      {hasSearched && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">
              Results {searchResults.length > 0 && `(${searchResults.length})`}
            </h3>
            {searchResults.length > 0 && (
              <Button variant="outline" size="sm" onClick={clearFilters}>
                New Search
              </Button>
            )}
          </div>

          {searchResults.length === 0 ? (
            <div className="text-center py-12">
              <Search className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-50" />
              <p className="text-muted-foreground">No products found matching your criteria</p>
              <p className="text-sm text-muted-foreground mt-1">
                Try adjusting your filters or search terms
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {searchResults.map((product) => (
                <ProductCard key={product.id} product={product} hideActions={true} compact={true} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Voice Search Note */}
      {isListening && (
        <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 text-sm text-blue-900 dark:text-blue-100">
          Listening... Speak your search query naturally. Examples: &quot;Find a laptop under
          500&quot;, &quot;Show me vintage watches&quot;
        </div>
      )}

      {/* Image Search Note */}
      {showImageSearch && (
        <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800 text-sm text-purple-900 dark:text-purple-100">
          Image Search is a future feature. Click the image icon to select an image. The system will
          extract visual features and find similar products using computer vision APIs.
        </div>
      )}
    </div>
  )
}
