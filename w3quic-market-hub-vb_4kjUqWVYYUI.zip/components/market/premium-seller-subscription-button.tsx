'use client';

import { useState } from 'react';
import { Crown, AlertCircle, Zap, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';
import { useMarket } from '@/lib/market/store';
import { toast } from '@/hooks/use-toast';

interface PremiumSellerSubscriptionButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline';
  showPriceInLabel?: boolean;
  showFeatures?: boolean;
  fullWidth?: boolean;
  className?: string;
}

export function PremiumSellerSubscriptionButton({
  onSuccess,
  variant = 'default',
  showPriceInLabel = true,
  showFeatures = false,
  fullWidth = false,
  className = '',
}: PremiumSellerSubscriptionButtonProps) {
  const piAuth = usePiAuth();
  const { me, updateMe } = useMarket();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { products, sdk, restoredPurchases } = piAuth || {};

  // Find the premium seller subscription product (6a35208e048922ba3e3ca4b3 - 0.5 Pi)
  const product = products?.find(p => p.id === PRODUCT_CONFIG.PRODUCT_6a35208e048922ba3e3ca4b3);

  // Check if already purchased
  const isSubscriptionPurchased = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  // Don't show button if already purchased or premium
  if (me?.isPremium || isSubscriptionPurchased) {
    return (
      <div className={`flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 px-3 py-2 ${fullWidth ? 'w-full' : ''} ${className}`}>
        <CheckCircle2 className="h-4 w-4 text-green-600" />
        <span className="text-sm font-medium text-green-700">Premium Subscription Active</span>
      </div>
    );
  }

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Premium subscription product not available');
      toast({
        title: 'Error',
        description: 'Premium subscription product not available',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result?.ok) {
        setSuccess(true);

        // Update seller status to premium with timestamp
        updateMe({
          isPremium: true,
          premiumSubscriptionActivatedAt: Date.now(),
          badges: [...(me?.badges || []), 'premium_subscription'],
        });

        toast({
          title: 'Success!',
          description: 'Premium Seller Subscription activated successfully!',
        });

        onSuccess?.();

        // Clear success message after 3 seconds
        setTimeout(() => {
          setSuccess(false);
        }, 3000);
      } else {
        setError('Purchase failed. Please try again.');
        toast({
          title: 'Purchase Failed',
          description: 'Please try again.',
          variant: 'destructive',
        });
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Premium subscription product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      const errorMsg = errorMessages[errorCode] || 'Purchase failed';
      setError(errorMsg);
      toast({
        title: 'Purchase Error',
        description: errorMsg,
        variant: 'destructive',
      });
      console.error('[Premium Seller Subscription] Purchase error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Product not available
  if (!product) {
    return (
      <Button disabled variant="outline" className={`${fullWidth ? 'w-full' : ''} ${className}`}>
        <AlertCircle className="mr-2 h-4 w-4" />
        Premium Subscription Unavailable
      </Button>
    );
  }

  // SDK not ready
  if (!sdk || !piAuth?.isAuthenticated) {
    return (
      <Button disabled variant="outline" className={`${fullWidth ? 'w-full' : ''} ${className}`}>
        <Crown className="mr-2 h-4 w-4" />
        Loading...
      </Button>
    );
  }

  const priceLabel = showPriceInLabel && product ? ` (${product.price_in_pi} π)` : '';
  const buttonVariant = variant === 'outline' ? 'outline' : 'default';
  const isDefaultVariant = variant === 'default';

  const features = [
    'Verified Seller Badge',
    'Featured Product Listings',
    'Priority Search Visibility',
    'Advanced Analytics Dashboard',
    'Promotional Tools',
    'Exclusive Seller Features',
    'Increased Buyer Trust',
    'Premium Support',
  ];

  return (
    <div className="space-y-3">
      {showFeatures && (
        <div className="rounded-lg bg-purple-50 border border-purple-200 p-3 space-y-2">
          <h3 className="text-sm font-semibold text-purple-900">Premium Subscription Benefits:</h3>
          <ul className="text-xs text-purple-800 space-y-1">
            {features.map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Zap className="h-3 w-3 mt-0.5 text-purple-600 flex-shrink-0" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Button
        onClick={handlePurchase}
        disabled={isLoading || !product || !sdk}
        variant={buttonVariant}
        className={`
          ${fullWidth ? 'w-full' : ''} 
          ${isDefaultVariant ? 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white' : ''}
          ${className}
        `}
      >
        <Crown className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing Payment...' : `Premium Subscription${priceLabel}`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700 flex items-start gap-2">
          <CheckCircle2 className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>✓ Premium subscription activated successfully!</span>
        </div>
      )}
    </div>
  );
}
