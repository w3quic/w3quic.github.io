"use client"

import { useMemo } from "react"
import { Zap, Gavel } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { ProductCard } from "./product-card"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty"

export function ListView({ mode }: { mode: "auctions" | "flash" }) {
  const { products } = useMarket()
  const list = useMemo(() => {
    if (mode === "flash") return products.filter((p) => p.flashDeal && p.flashDeal.endsAt > Date.now())
    return products.filter((p) => p.auction && p.auction.endsAt > Date.now())
  }, [products, mode])

  const title = mode === "flash" ? "Flash Deals" : "Live Auctions"
  const Icon = mode === "flash" ? Zap : Gavel

  return (
    <div className="animate-fade-in px-4 py-4">
      <h1 className="mb-1 flex items-center gap-2 text-xl font-bold">
        <Icon className={mode === "flash" ? "h-5 w-5 text-rose-500" : "h-5 w-5 text-amber-500"} />
        {title}
      </h1>
      <p className="mb-4 text-sm text-muted-foreground">
        {mode === "flash" ? "Limited-time discounts — grab them before they expire." : "Bid in real time and win unique items."}
      </p>
      {list.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Icon /></EmptyMedia>
            <EmptyTitle>Nothing live right now</EmptyTitle>
            <EmptyDescription>Check back soon for new {title.toLowerCase()}.</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {list.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  )
}
