'use client';
import { useMemo, useState } from 'react';
import { AlertTriangle, Package, Users, TrendingUp, CheckCircle, XCircle } from 'lucide-react';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { CURRENT_USER_ID } from '@/lib/market/seed';
import { formatPi } from '@/lib/market/helpers';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty';
import { toast } from '@/hooks/use-toast';
import { UnlockAllModulesButton } from './unlock-all-modules-button';

export function AdminView() {
  const market = useMarket();
  const { me, users, products, orders, reports, updateProduct, updateReport } = market;
  const [searchUser, setSearchUser] = useState('');
  const [selectedRole, setSelectedRole] = useState('');

  const isAdmin = me.adminRole && ['super-admin', 'moderator'].includes(me.adminRole);

  if (!isAdmin) {
    return (
      <div className="px-4 py-6">
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <AlertTriangle />
            </EmptyMedia>
            <EmptyTitle>Access denied</EmptyTitle>
          </EmptyHeader>
        </Empty>
      </div>
    );
  }

  const disputes = orders.filter((o) => o.status === 'disputed');
  const stats = {
    totalUsers: users.length,
    totalProducts: products.length,
    totalOrders: orders.length,
    totalVolume: orders.reduce((s, o) => s + o.total, 0),
    flaggedProducts: products.filter((p) => p.scamScore >= 60).length,
    openDisputes: disputes.length,
    totalSellers: users.filter((u) => u.isSeller).length,
    totalBuyers: users.length,
  };

  const filteredReports = reports.filter((r) => !searchUser || r.targetId.includes(searchUser));

  return (
    <div className="animate-fade-in px-4 py-4">
      <h1 className="mb-4 text-xl font-bold">Admin Dashboard</h1>

      <Tabs defaultValue="overview">
        <TabsList className="w-full">
          <TabsTrigger value="overview" className="flex-1">
            Overview
          </TabsTrigger>
          <TabsTrigger value="products" className="flex-1">
            Products
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex-1">
            Reports
          </TabsTrigger>
          <TabsTrigger value="disputes" className="flex-1">
            Disputes
          </TabsTrigger>
          <TabsTrigger value="modules" className="flex-1">
            Modules
          </TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
            <StatBox label="Users" value={stats.totalUsers} icon="👥" />
            <StatBox label="Products" value={stats.totalProducts} icon="📦" />
            <StatBox label="Orders" value={stats.totalOrders} icon="🛒" />
            <StatBox label="Volume" value={formatPi(stats.totalVolume)} icon="💰" />
            <StatBox label="Sellers" value={stats.totalSellers} icon="🏪" />
            <StatBox label="Flagged" value={stats.flaggedProducts} icon="⚠️" />
            <StatBox label="Disputes" value={stats.openDisputes} icon="⚔️" />
            <StatBox label="Reports" value={reports.length} icon="🚩" />
          </div>

          {/* Users */}
          <div className="rounded-xl border border-border bg-card p-4">
            <h2 className="mb-3 flex items-center gap-2 font-semibold">
              <Users className="h-4 w-4" /> User Management
            </h2>
            <div className="space-y-2">
              {users.slice(0, 5).map((u) => (
                <div
                  key={u.id}
                  className="flex items-center justify-between rounded-lg border border-border p-2 text-sm"
                >
                  <div>
                    <p className="font-medium">{u.displayName}</p>
                    <p className="text-xs text-muted-foreground">
                      {u.isSeller ? '👤 Seller' : '👤 Buyer'} · Rep {u.reputationScore}
                    </p>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline">
                        Actions
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Manage user: {u.displayName}</DialogTitle>
                      </DialogHeader>
                      <div className="grid gap-2">
                        <Button
                          variant="outline"
                          onClick={() => {
                            market.updateUser(u.id, { verification: 'verified' });
                            toast({ title: 'User verified' });
                          }}
                        >
                          Mark verified
                        </Button>
                        <Button
                          variant="destructive"
                          onClick={() => {
                            market.updateUser(u.id, { banned: true });
                            toast({ title: 'User banned' });
                          }}
                        >
                          Ban user
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Products */}
        <TabsContent value="products" className="mt-4">
          <h2 className="mb-3 flex items-center gap-2 font-semibold">
            <Package className="h-4 w-4" /> Flagged Products
          </h2>
          {products
            .filter((p) => p.scamScore >= 60)
            .slice(0, 10)
            .map((p) => (
              <Dialog key={p.id}>
                <DialogTrigger asChild>
                  <button className="mb-2 w-full rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-left">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{p.title}</p>
                        <p className="text-xs text-muted-foreground">
                          Score: {p.scamScore}% · {formatPi(p.price)} · Views: {p.views}
                        </p>
                      </div>
                      <AlertTriangle className="h-5 w-5 text-destructive" />
                    </div>
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Review flagged product</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-2 text-sm">
                    <p>
                      <span className="font-semibold">Title:</span> {p.title}
                    </p>
                    <p>
                      <span className="font-semibold">Scam Score:</span> {p.scamScore}%
                    </p>
                    <p>
                      <span className="font-semibold">Reports:</span> {reports.filter((r) => r.targetId === p.id).length}
                    </p>
                    <p>
                      <span className="font-semibold">Price:</span> {formatPi(p.price)}
                    </p>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => {
                        updateProduct(p.id, { hidden: false, scamScore: 0 });
                        toast({ title: 'Product cleared' });
                      }}
                    >
                      Clear flag
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={() => {
                        updateProduct(p.id, { hidden: true });
                        toast({ title: 'Product hidden' });
                      }}
                    >
                      Remove listing
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            ))}
          {products.filter((p) => p.scamScore >= 60).length === 0 && (
            <p className="text-sm text-muted-foreground">No flagged products.</p>
          )}
        </TabsContent>

        {/* Reports */}
        <TabsContent value="reports" className="mt-4 space-y-3">
          <Input
            placeholder="Search reports..."
            value={searchUser}
            onChange={(e) => setSearchUser(e.target.value)}
          />
          {filteredReports.slice(0, 10).map((r) => (
            <div key={r.id} className="rounded-lg border border-border bg-card p-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-semibold">
                    {r.reason} · {r.targetType}
                  </p>
                  <p className="text-xs text-muted-foreground">{r.description}</p>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="outline">
                      Review
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Review report</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-2 text-sm">
                      <p>
                        <span className="font-semibold">Type:</span> {r.targetType}
                      </p>
                      <p>
                        <span className="font-semibold">Reason:</span> {r.reason}
                      </p>
                      <p>
                        <span className="font-semibold">Description:</span> {r.description}
                      </p>
                      <p>
                        <span className="font-semibold">Status:</span> {r.status}
                      </p>
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => {
                          updateReport(r.id, { status: 'dismissed' });
                          toast({ title: 'Report dismissed' });
                        }}
                      >
                        Dismiss
                      </Button>
                      <Button
                        onClick={() => {
                          updateReport(r.id, { status: 'resolved' });
                          toast({ title: 'Report resolved' });
                        }}
                      >
                        Resolve
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          ))}
        </TabsContent>

        {/* Disputes */}
        <TabsContent value="disputes" className="mt-4 space-y-3">
          {disputes
            .filter((d) => d.status === 'open')
            .slice(0, 10)
            .map((d) => (
              <div key={d.id} className="rounded-lg border border-destructive/30 bg-destructive/5 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <p className="font-semibold text-destructive">{d.reason}</p>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm">Resolve</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Resolve dispute</DialogTitle>
                      </DialogHeader>
                      <div className="grid gap-2 text-sm">
                        <p>
                          <span className="font-semibold">Buyer:</span> {d.buyerMsg}
                        </p>
                        {d.sellerMsg && (
                          <p>
                            <span className="font-semibold">Seller:</span> {d.sellerMsg}
                          </p>
                        )}
                      </div>
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => {
                            resolveDispute(d.id, 'Refund to buyer');
                            toast({ title: 'Dispute resolved: refund' });
                          }}
                        >
                          <XCircle className="mr-1 h-4 w-4" /> Refund buyer
                        </Button>
                        <Button
                          onClick={() => {
                            resolveDispute(d.id, 'Payment to seller');
                            toast({ title: 'Dispute resolved: payment' });
                          }}
                        >
                          <CheckCircle className="mr-1 h-4 w-4" /> Pay seller
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            ))}
        </TabsContent>

        {/* Modules */}
        <TabsContent value="modules" className="mt-4 space-y-4">
          <div className="rounded-xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50 p-6">
            <h2 className="mb-3 text-lg font-bold text-emerald-900 flex items-center gap-2">
              🚀 Unlock All Marketplace Modules
            </h2>
            <p className="text-sm text-emerald-800 mb-4">
              Admin can help users unlock all advanced Pi Market Hub modules including real estate, vehicle marketplace, services platform, jobs board, business center suite, AI tools, community features, advanced analytics, premium business tools, and all future updates.
            </p>
            <UnlockAllModulesButton 
              showFeatures={true}
              fullWidth={false}
              showPrice={true}
            />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function StatBox({ label, value, icon }: { label: string; value: string | number; icon: string }) {
  return (
    <div className="flex flex-col items-center gap-1 rounded-lg border border-border bg-card p-3 text-center">
      <p className="text-lg">{icon}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-bold">{value}</p>
    </div>
  );
}
