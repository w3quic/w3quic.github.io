'use client'

import { useState } from 'react'
import { X, ChevronDown } from 'lucide-react'
import { useMarket } from '@/lib/market/store'
import { Button } from '@/components/ui/button'
import { ProductCard } from './product-card'
import type { Product } from '@/lib/market/types'
import { formatPi } from '@/lib/market/helpers'

export function ComparisonView({ onClose }: { onClose: () => void }) {
  const market = useMarket()
  const [selectedProducts, setSelectedProducts] = useState<string[]>([])
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set())

  const comparisonTable = market.buildComparisonTable(selectedProducts)
  const products = selectedProducts.map((id) => market.getProduct(id)).filter(Boolean) as Product[]

  const toggleExpanded = (attr: string) => {
    const next = new Set(expandedRows)
    if (next.has(attr)) next.delete(attr)
    else next.add(attr)
    setExpandedRows(next)
  }

  const removeProduct = (id: string) => {
    setSelectedProducts(selectedProducts.filter((p) => p !== id))
  }

  const addProduct = (id: string) => {
    if (selectedProducts.length < 4 && !selectedProducts.includes(id)) {
      setSelectedProducts([...selectedProducts, id])
    }
  }

  const formatValue = (value: any): string => {
    if (typeof value === 'number') return value.toString()
    if (typeof value === 'boolean') return value ? 'Yes' : 'No'
    if (Array.isArray(value)) return value.join(', ')
    return String(value || '—')
  }

  if (selectedProducts.length === 0) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-background rounded-lg max-w-2xl w-full max-h-96 overflow-y-auto p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Product Comparison</h2>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-sm text-muted-foreground mb-4">Select up to 4 products to compare.</p>

          <div className="space-y-2">
            {market.products.slice(0, 8).map((p) => (
              <button
                key={p.id}
                onClick={() => addProduct(p.id)}
                className="w-full text-left p-2 rounded hover:bg-secondary transition-colors border border-border"
              >
                <div className="font-medium text-sm">{p.title}</div>
                <div className="text-xs text-muted-foreground">{formatPi(p.price)}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-background rounded-lg max-w-6xl w-full max-h-[90vh] overflow-auto p-6">
        <div className="flex justify-between items-center mb-4 pb-4 border-b border-border">
          <h2 className="text-lg font-semibold">Compare Products ({selectedProducts.length}/4)</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Products */}
        <div className="grid gap-4 mb-6" style={{ gridTemplateColumns: `repeat(${selectedProducts.length}, 1fr)` }}>
          {products.map((p) => (
            <div key={p.id} className="relative border border-border rounded-lg overflow-hidden">
              <button
                onClick={() => removeProduct(p.id)}
                className="absolute top-2 right-2 bg-destructive text-destructive-foreground rounded-full p-1 z-10 hover:bg-destructive/90"
              >
                <X className="w-3 h-3" />
              </button>
              <div className="aspect-square overflow-hidden bg-muted">
                <img
                  src={p.images[0] || '/placeholder.svg'}
                  alt={p.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-3">
                <div className="font-medium text-sm line-clamp-2 mb-1">{p.title}</div>
                <div className="text-lg font-bold text-primary">{formatPi(p.price)}</div>
                <div className="text-xs text-muted-foreground capitalize">{p.condition}</div>
              </div>
            </div>
          ))}

          {selectedProducts.length < 4 && (
            <button
              onClick={() => {}}
              className="border-2 border-dashed border-border rounded-lg hover:border-primary/50 hover:bg-secondary/30 transition-colors flex items-center justify-center min-h-40"
              title="Add more products to compare (max 4)"
            >
              <div className="text-center">
                <div className="text-2xl mb-1">+</div>
                <div className="text-xs text-muted-foreground">Add product</div>
              </div>
            </button>
          )}
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <tbody>
              {comparisonTable.map((row) => (
                <tr key={row.attribute} className="border-b border-border hover:bg-secondary/50">
                  <td
                    onClick={() => toggleExpanded(row.attribute)}
                    className="p-3 font-medium bg-secondary/50 sticky left-0 z-10 cursor-pointer flex items-center gap-2 capitalize min-w-32"
                  >
                    {row.attribute.replace(/_/g, ' ')}
                    <ChevronDown className={`w-4 h-4 transition-transform ${expandedRows.has(row.attribute) ? 'rotate-180' : ''}`} />
                  </td>
                  {row.products.map((value, idx) => (
                    <td key={idx} className="p-3 text-center min-w-32">
                      {row.attribute === 'price' ? formatPi(value as number) : formatValue(value)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex gap-2">
          <Button onClick={onClose} variant="outline" className="flex-1">
            Close
          </Button>
          {selectedProducts.length > 0 && (
            <Button
              onClick={() => {
                // Could add products to cart or wishlist here
                onClose()
              }}
              className="flex-1"
            >
              Save Comparison
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
