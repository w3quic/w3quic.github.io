'use client';

import { useState } from 'react';
import { Zap, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';

interface PiHubAdvancedButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline';
  showFeatures?: boolean;
  fullWidth?: boolean;
}

const INCLUDED_FEATURES = [
  'Advanced seller analytics',
  'AI-powered recommendations',
  'Featured product listings',
  'Priority search visibility',
  'Business growth tools',
  'Enhanced security features',
  'Exclusive professional tools',
];

export function PiHubAdvancedButton({ 
  onSuccess, 
  variant = 'default', 
  showFeatures = true,
  fullWidth = true
}: PiHubAdvancedButtonProps) {
  const piAuth = usePiAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { products, sdk, restoredPurchases, isAuthenticated } = piAuth || {};

  // Find the advanced features product using the new product ID
  const product = products?.find(
    p => p.id === PRODUCT_CONFIG.PRODUCT_6a344637bf9ecfcca1c7437b
  );

  // Check if already purchased
  const isAdvancedActive = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  // Show active status if already purchased
  if (isAdvancedActive) {
    return (
      <div className="flex items-start gap-3 rounded-lg border border-green-200 bg-green-50 p-3">
        <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
        <div>
          <p className="font-medium text-green-700 text-sm">Pi Market Hub Advanced Features Active</p>
          <p className="text-xs text-green-600 mt-1">You have access to all premium tools and features.</p>
        </div>
      </div>
    );
  }

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Product not available. Please try again later.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result?.ok) {
        setSuccess(true);
        onSuccess?.();
        
        // Clear success message after 4 seconds
        setTimeout(() => {
          setSuccess(false);
        }, 4000);
      } else {
        setError('Purchase failed. Please try again.');
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Pi Market Hub Advanced Features product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during the purchase',
        unknown_error: 'An unexpected error occurred',
      };
      setError(errorMessages[errorCode] || 'Purchase failed');
      console.error('[Pi Hub Advanced] Purchase error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Product not available
  if (!product) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <AlertCircle className="mr-2 h-4 w-4" />
        Unavailable
      </Button>
    );
  }

  // Not authenticated
  if (!isAuthenticated) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <Zap className="mr-2 h-4 w-4" />
        Loading...
      </Button>
    );
  }

  const buttonVariant = variant === 'outline' ? 'outline' : 'default';
  const isDefaultVariant = variant === 'default';
  const price = product.price_in_pi;

  return (
    <div className="space-y-3">
      {showFeatures && (
        <div className="rounded-lg border border-blue-100 bg-blue-50 p-3">
          <p className="text-xs font-semibold text-blue-900 mb-2">Unlocked Features:</p>
          <ul className="space-y-1.5">
            {INCLUDED_FEATURES.map((feature, idx) => (
              <li key={idx} className="flex items-start gap-2 text-xs text-blue-700">
                <CheckCircle className="h-3.5 w-3.5 mt-0.5 flex-shrink-0 text-blue-600" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Button
        onClick={handlePurchase}
        disabled={isLoading}
        variant={buttonVariant}
        className={isDefaultVariant ? `${fullWidth ? 'w-full' : ''} bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white` : fullWidth ? 'w-full' : ''}
      >
        <Zap className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing Payment...' : `Upgrade Now (${price} π)`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2.5 text-sm text-green-700 flex items-start gap-2">
          <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>Advanced features activated successfully! 🎉</span>
        </div>
      )}
    </div>
  );
}
