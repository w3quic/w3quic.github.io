"use client"

import { Home, Search, ShoppingCart, Store, User } from "lucide-react"
import { cn } from "@/lib/utils"
import { useMarket } from "@/lib/market/store"
import { useNav, type View } from "@/lib/market/nav"

export function BottomNav() {
  const { tab, go } = useNav()
  const { cart } = useMarket()
  const cartCount = cart.reduce((s, c) => s + c.quantity, 0)

  const items: { name: string; label: string; icon: any; view: View; badge?: number }[] = [
    { name: "home", label: "Home", icon: Home, view: { name: "home" } },
    { name: "browse", label: "Browse", icon: Search, view: { name: "browse" } },
    { name: "cart", label: "Cart", icon: ShoppingCart, view: { name: "cart" }, badge: cartCount },
    { name: "seller", label: "Sell", icon: Store, view: { name: "seller" } },
    { name: "profile", label: "Profile", icon: User, view: { name: "profile" } },
  ]

  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-2xl items-stretch border-t border-border bg-card/98 backdrop-blur-lg lg:hidden">
      {items.map((it) => {
        const active = tab === it.name
        const Icon = it.icon
        return (
          <button
            key={it.name}
            onClick={() => go(it.view)}
            className={cn(
              "relative flex flex-1 flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-semibold transition-colors duration-200",
              active 
                ? "text-primary bg-primary/5" 
                : "text-muted-foreground hover:text-foreground hover:bg-muted/50 active:bg-muted"
            )}
            aria-current={active ? "page" : undefined}
          >
            <span className="relative">
              <Icon className={cn("h-5 w-5 transition-transform", active && "scale-110")} />
              {it.badge ? (
                <span className="absolute -right-2.5 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground shadow-md">
                  {it.badge > 9 ? "9+" : it.badge}
                </span>
              ) : null}
            </span>
            <span className="truncate">{it.label}</span>
          </button>
        )
      })}
    </nav>
  )
}

export function SideNav() {
  const { tab, go } = useNav()
  const { cart } = useMarket()
  const cartCount = cart.reduce((s, c) => s + c.quantity, 0)
  const items = [
    { name: "home", label: "Home", icon: Home, view: { name: "home" } as View },
    { name: "browse", label: "Browse", icon: Search, view: { name: "browse" } as View },
    { name: "cart", label: "Cart", icon: ShoppingCart, view: { name: "cart" } as View, badge: cartCount },
    { name: "seller", label: "Seller Center", icon: Store, view: { name: "seller" } as View },
    { name: "profile", label: "Profile", icon: User, view: { name: "profile" } as View },
  ]
  return (
    <aside className="sticky top-14 hidden h-[calc(100vh-3.5rem)] w-56 shrink-0 border-r border-border bg-sidebar p-4 lg:block">
      <nav className="space-y-1">
        {items.map((it) => {
          const active = tab === it.name
          const Icon = it.icon
          return (
            <button
              key={it.name}
              onClick={() => go(it.view)}
              className={cn(
                "group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition-all duration-200",
                active 
                  ? "bg-primary/10 text-primary" 
                  : "text-sidebar-foreground hover:bg-sidebar-accent/60 active:bg-sidebar-accent"
              )}
            >
              <Icon className={cn("h-5 w-5 transition-transform", active && "scale-110")} /> 
              <span className="flex-1 text-left">{it.label}</span>
              {it.badge ? <span className="ml-auto rounded-full bg-primary/90 px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground shadow-md">{it.badge}</span> : null}
            </button>
          )
        })}
      </nav>
    </aside>
  )
}
