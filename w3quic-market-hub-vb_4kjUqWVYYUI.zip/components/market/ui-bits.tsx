"use client"

import { Star, ShieldCheck, BadgeCheck, Loader2, Check, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import type { VerificationLevel } from "@/lib/market/types"

export function RatingStars({ value, size = 14, showValue = false, count }: { value: number; size?: number; showValue?: boolean; count?: number }) {
  return (
    <span className="inline-flex items-center gap-1">
      <span className="inline-flex" aria-label={`Rated ${value} out of 5`}>
        {[1, 2, 3, 4, 5].map((i) => (
          <Star
            key={i}
            width={size}
            height={size}
            className={cn(i <= Math.round(value) ? "fill-amber-400 text-amber-400 transition-all" : "fill-muted text-muted-foreground/40")}
          />
        ))}
      </span>
      {showValue && <span className="text-xs font-semibold text-foreground">{value.toFixed(1)}{count != null ? ` (${count})` : ""}</span>}
    </span>
  )
}

export function VerifiedBadge({ level, className }: { level: VerificationLevel; className?: string }) {
  if (level === "none") return null
  const map: Record<string, { label: string; cls: string }> = {
    basic: { label: "Basic", cls: "bg-muted text-muted-foreground" },
    trusted: { label: "Trusted", cls: "bg-blue-500/15 text-blue-600 dark:text-blue-400" },
    verified: { label: "Verified", cls: "bg-primary/15 text-primary dark:bg-primary/20" },
  }
  const m = map[level]
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2 py-1 text-[11px] font-semibold whitespace-nowrap", m.cls, className)}>
      {level === "verified" ? <BadgeCheck className="h-3.5 w-3.5 flex-shrink-0" /> : <ShieldCheck className="h-3.5 w-3.5 flex-shrink-0" />}
      {m.label}
    </span>
  )
}

export function Pill({ children, className }: { children: React.ReactNode; className?: string }) {
  return <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap", className)}>{children}</span>
}

export function SkeletonLoader({ className }: { className?: string }) {
  return <div className={cn("skeleton rounded-lg bg-muted", className)} />
}

export function SkeletonText({ lines = 1, className }: { lines?: number; className?: string }) {
  return (
    <div className={cn("space-y-2", className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className={cn("skeleton h-4 rounded", i === lines - 1 && "w-3/4")} />
      ))}
    </div>
  )
}

export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div className={cn("space-y-3 rounded-xl border border-border bg-card p-4", className)}>
      <div className="skeleton h-32 w-full rounded-lg" />
      <SkeletonText lines={2} />
      <div className="flex gap-2">
        <div className="skeleton h-8 w-16 rounded" />
        <div className="skeleton h-8 flex-1 rounded" />
      </div>
    </div>
  )
}

export function LoadingSpinner({ size = "md", className }: { size?: "sm" | "md" | "lg"; className?: string }) {
  const sizeMap = { sm: "h-4 w-4", md: "h-6 w-6", lg: "h-8 w-8" }
  return (
    <Loader2 className={cn("animate-spin-slow text-primary", sizeMap[size], className)} />
  )
}

export function SuccessIcon({ className }: { className?: string }) {
  return (
    <div className={cn("flex h-12 w-12 items-center justify-center rounded-full bg-green-500/15", className)}>
      <Check className="h-6 w-6 animate-success-check text-green-600 dark:text-green-400" />
    </div>
  )
}

export function ErrorIcon({ className }: { className?: string }) {
  return (
    <div className={cn("flex h-12 w-12 items-center justify-center rounded-full bg-destructive/15 animate-error-shake", className)}>
      <AlertCircle className="h-6 w-6 text-destructive" />
    </div>
  )
}
