'use client';
import { useState, useMemo } from 'react';
import { ChevronLeft, Plus, X } from 'lucide-react';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { CURRENT_USER_ID } from '@/lib/market/seed';
import { formatPi } from '@/lib/market/helpers';
import { CATEGORIES, type Category } from '@/lib/market/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';

export function CreateListingView({ editId }: { editId?: string }) {
  const market = useMarket();
  const { go } = useNav();
  const { products, getProduct, createProduct, updateProduct, suggestPrice } = market;
  const product = editId ? getProduct(editId) : undefined;

  const [title, setTitle] = useState(product?.title || '');
  const [desc, setDesc] = useState(product?.description || '');
  const [category, setCategory] = useState<string>(product?.category || '');
  const [price, setPrice] = useState(product?.price.toString() || '');
  const [stock, setStock] = useState(product?.stock.toString() || '');
  const [condition, setCondition] = useState<string>(product?.condition || 'new');
  const [handling, setHandling] = useState(product?.handlingTimeDays.toString() || '3');
  const [location, setLocation] = useState(product?.location || '');
  const [images, setImages] = useState<string[]>(product?.images || ['/placeholder.svg']);
  const [variations, setVariations] = useState(product?.variations || []);
  const [newVarName, setNewVarName] = useState('');
  const [newVarPrice, setNewVarPrice] = useState('');
  const [newVarStock, setNewVarStock] = useState('');

  const suggested = useMemo(
    () => (category ? suggestPrice(category) : null),
    [category, suggestPrice]
  );

  const handleAddVariation = () => {
    if (!newVarName.trim() || !newVarPrice) return;
    setVariations([
      ...variations,
      {
        id: `var-${Date.now()}`,
        name: newVarName,
        price: Number(newVarPrice),
        stock: Number(newVarStock) || 10,
      },
    ]);
    setNewVarName('');
    setNewVarPrice('');
    setNewVarStock('');
  };

  const handleSave = () => {
    if (!title.trim() || !category || !price || !stock) {
      toast({ title: 'Missing fields', variant: 'destructive' });
      return;
    }

    const data = {
      title,
      description: desc,
      category: category as any,
      price: Number(price),
      stock: Number(stock),
      condition: condition as 'new' | 'like-new' | 'used' | 'refurbished',
      handlingTimeDays: Number(handling),
      location,
      images,
      variations: variations as any,
      sellerId: CURRENT_USER_ID,
    };

    if (editId && product) {
      updateProduct(editId, data);
      toast({ title: 'Product updated' });
    } else {
      createProduct(data as any);
      toast({ title: 'Listing created' });
    }
    go({ name: 'seller' });
  };

  return (
    <div className="animate-fade-in px-4 py-4 pb-24">
      <div className="mb-4 flex items-center gap-2">
        <button onClick={() => go({ name: 'seller' })} aria-label="Back">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h1 className="text-xl font-bold">{editId ? 'Edit listing' : 'Create listing'}</h1>
      </div>

      <div className="space-y-4">
        {/* Title */}
        <div>
          <Label>Title</Label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Laptop, Shoes, etc."
          />
        </div>

        {/* Description */}
        <div>
          <Label>Description</Label>
          <Textarea
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            placeholder="Describe your product in detail..."
            rows={4}
          />
        </div>

        {/* Category & Condition */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Condition</Label>
            <Select value={condition} onValueChange={setCondition}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="like-new">Like New</SelectItem>
                <SelectItem value="used">Used</SelectItem>
                <SelectItem value="refurbished">Refurbished</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Price & Stock */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Price (π)</Label>
            <Input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="0"
            />
            {suggested && (
              <p className="mt-1 text-xs text-muted-foreground">
                Suggested: {formatPi(suggested.min)} - {formatPi(suggested.max)}
              </p>
            )}
          </div>
          <div>
            <Label>Stock</Label>
            <Input
              type="number"
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              placeholder="10"
            />
          </div>
        </div>

        {/* Handling & Location */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Handling days</Label>
            <Input
              type="number"
              value={handling}
              onChange={(e) => setHandling(e.target.value)}
              placeholder="3"
            />
          </div>
          <div>
            <Label>Location</Label>
            <Input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="City/Region"
            />
          </div>
        </div>

        {/* Variations */}
        <div>
          <Label>Variations (optional)</Label>
          <p className="mb-2 text-xs text-muted-foreground">
            e.g. size, color — each with price & stock
          </p>
          {variations.length > 0 && (
            <div className="mb-2 space-y-2">
              {variations.map((v, idx) => (
                <div key={v.id} className="flex items-center justify-between rounded-lg border border-border bg-card p-2 text-sm">
                  <span>
                    {v.name} · {formatPi(v.price)} · {v.stock} stock
                  </span>
                  <button
                    onClick={() => setVariations(variations.filter((_, i) => i !== idx))}
                    aria-label="Remove"
                  >
                    <X className="h-4 w-4 text-muted-foreground" />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <Input
              value={newVarName}
              onChange={(e) => setNewVarName(e.target.value)}
              placeholder="e.g. Blue/M"
              className="flex-1"
            />
            <Input
              type="number"
              value={newVarPrice}
              onChange={(e) => setNewVarPrice(e.target.value)}
              placeholder="Price"
              className="w-20"
            />
            <Input
              type="number"
              value={newVarStock}
              onChange={(e) => setNewVarStock(e.target.value)}
              placeholder="Stock"
              className="w-20"
            />
            <Button size="icon" variant="outline" onClick={handleAddVariation}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-2xl gap-2 border-t border-border bg-background p-4 backdrop-blur">
        <Button variant="outline" className="flex-1" onClick={() => go({ name: 'seller' })}>
          Cancel
        </Button>
        <Button className="flex-1" onClick={handleSave}>
          {editId ? 'Update' : 'Create'} Listing
        </Button>
      </div>
    </div>
  );
}
