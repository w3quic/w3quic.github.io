"use client"

import React, { useState } from "react"
import {
  Package, Truck, MapPin, Clock, CheckCircle2, AlertCircle, Home,
  Phone, MessageSquare, Download, Copy,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Shipment, ShippingLabel } from "@/lib/market/types"
import { getLatestTrackingStatus } from "@/lib/market/shipping-logistics"

interface ShippingTrackerProps {
  shipments: Shipment[]
  onDeliveryConfirmed?: (shipmentId: string, notes: string) => void
  onRequestRefund?: (shipmentId: string) => void
}

const TRACKING_STEP_ICONS = {
  "label-created": Package,
  "picked-up": Truck,
  "in-transit": MapPin,
  "out-for-delivery": Truck,
  delivered: CheckCircle2,
  exception: AlertCircle,
  returned: Package,
}

const STEP_ORDER = [
  "label-created",
  "picked-up",
  "in-transit",
  "out-for-delivery",
  "delivered",
]

export function ShippingTracker({ shipments, onDeliveryConfirmed, onRequestRefund }: ShippingTrackerProps) {
  const [activeTab, setActiveTab] = useState("tracking")
  const [selectedShipment, setSelectedShipment] = useState<string | null>(shipments[0]?.id || null)
  const [deliveryNotes, setDeliveryNotes] = useState("")
  const [copiedTrackingNumber, setCopiedTrackingNumber] = useState(false)

  const currentShipment = shipments.find(s => s.id === selectedShipment)
  const latestStatus = currentShipment ? getLatestTrackingStatus(currentShipment) : null

  const handleCopyTrackingNumber = (number: string) => {
    navigator.clipboard.writeText(number)
    setCopiedTrackingNumber(true)
    setTimeout(() => setCopiedTrackingNumber(false), 2000)
  }

  const handleConfirmDelivery = () => {
    if (currentShipment && onDeliveryConfirmed) {
      onDeliveryConfirmed(currentShipment.id, deliveryNotes)
      setDeliveryNotes("")
    }
  }

  const getProgressPercentage = (shipment: Shipment): number => {
    const latestUpdate = getLatestTrackingStatus(shipment)
    if (!latestUpdate) return 0

    const stepIndex = STEP_ORDER.indexOf(latestUpdate.status as any)
    if (stepIndex === -1) return 100 // Exception or other status
    return ((stepIndex + 1) / STEP_ORDER.length) * 100
  }

  if (shipments.length === 0) {
    return (
      <Card className="p-8 text-center">
        <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
        <p className="text-lg font-semibold">No shipments found</p>
        <p className="text-sm text-muted-foreground">Your shipments will appear here</p>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Shipping & Tracking</h2>
        <p className="text-sm text-muted-foreground">Track your orders and manage deliveries</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Shipments List */}
        <div className="lg:col-span-1 space-y-2 max-h-96 overflow-y-auto">
          {shipments.map(shipment => {
            const status = getLatestTrackingStatus(shipment)
            const progress = getProgressPercentage(shipment)

            return (
              <Card
                key={shipment.id}
                onClick={() => setSelectedShipment(shipment.id)}
                className={`p-4 cursor-pointer transition-all ${
                  selectedShipment === shipment.id
                    ? "border-blue-500 bg-blue-50 ring-2 ring-blue-200"
                    : "hover:bg-gray-50"
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium text-sm">Order #{shipment.orderId.slice(0, 8)}</p>
                      <p className="text-xs text-muted-foreground">Tracking: {shipment.shippingLabel.trackingNumber.slice(-8)}</p>
                    </div>
                    {status?.status === "delivered" && <CheckCircle2 className="h-5 w-5 text-green-600" />}
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div
                      className="bg-blue-600 h-1.5 rounded-full transition-all"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-muted-foreground capitalize">{status?.status.replace("-", " ")}</p>
                </div>
              </Card>
            )
          })}
        </div>

        {/* Tracking Details */}
        <div className="lg:col-span-2 space-y-4">
          {currentShipment && (
            <>
              {/* Header */}
              <Card className="p-6 border-blue-200 bg-blue-50">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Tracking Number</p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="font-mono font-semibold text-lg">{currentShipment.shippingLabel.trackingNumber}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopyTrackingNumber(currentShipment.shippingLabel.trackingNumber)}
                      >
                        <Copy className="h-4 w-4" />
                        {copiedTrackingNumber && <span className="ml-1 text-xs">Copied</span>}
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground">Carrier</p>
                      <p className="font-semibold capitalize">{currentShipment.shippingLabel.carrier}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Shipping Cost</p>
                      <p className="font-semibold">{currentShipment.shippingLabel.shippingCost.toFixed(2)} Pi</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Est. Delivery</p>
                      <p className="font-semibold">{currentShipment.shippingLabel.estimatedDelivery}</p>
                    </div>
                  </div>
                </div>
              </Card>

              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="tracking">Tracking</TabsTrigger>
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="actions">Actions</TabsTrigger>
                </TabsList>

                {/* Tracking Timeline */}
                <TabsContent value="tracking" className="space-y-6 mt-6">
                  <div className="space-y-4">
                    {currentShipment.trackingUpdates.map((update, index) => {
                      const Icon = TRACKING_STEP_ICONS[update.status as keyof typeof TRACKING_STEP_ICONS] || AlertCircle

                      return (
                        <div key={index} className="relative pl-10">
                          {/* Timeline connector */}
                          {index < currentShipment.trackingUpdates.length - 1 && (
                            <div className="absolute left-4 top-8 w-0.5 h-8 bg-gray-200"></div>
                          )}

                          {/* Timeline dot */}
                          <div className="absolute left-0 top-0">
                            <div className={`h-9 w-9 rounded-full border-4 flex items-center justify-center ${
                              update.status === "delivered"
                                ? "border-green-200 bg-green-50"
                                : update.status === "exception"
                                  ? "border-red-200 bg-red-50"
                                  : "border-blue-200 bg-blue-50"
                            }`}>
                              <Icon className={`h-5 w-5 ${
                                update.status === "delivered"
                                  ? "text-green-600"
                                  : update.status === "exception"
                                    ? "text-red-600"
                                    : "text-blue-600"
                              }`} />
                            </div>
                          </div>

                          {/* Status info */}
                          <Card className="p-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <p className="font-semibold capitalize">{update.status.replace(/-/g, " ")}</p>
                                <p className="text-sm text-muted-foreground">{update.message}</p>
                                {update.location && (
                                  <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                                    <MapPin className="h-3 w-3" />
                                    {update.location}
                                  </div>
                                )}
                              </div>
                              <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">
                                {new Date(update.timestamp).toLocaleString()}
                              </span>
                            </div>
                          </Card>
                        </div>
                      )
                    })}
                  </div>
                </TabsContent>

                {/* Delivery Details */}
                <TabsContent value="details" className="space-y-4 mt-6">
                  <Card className="p-6">
                    <h3 className="font-semibold mb-4">Items</h3>
                    <div className="space-y-3">
                      {currentShipment.items.map((item, i) => (
                        <div key={i} className="flex justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium text-sm">{item.title}</p>
                            <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                          </div>
                          <p className="font-semibold">{(item.price * item.quantity).toFixed(2)} Pi</p>
                        </div>
                      ))}
                    </div>
                  </Card>

                  {currentShipment.handledBy && (
                    <Card className="p-6">
                      <h3 className="font-semibold mb-4">Delivery Information</h3>
                      <div className="space-y-2">
                        <p className="text-sm">
                          <span className="text-muted-foreground">Delivered by:</span> {currentShipment.handledBy}
                        </p>
                        {currentShipment.notes && (
                          <p className="text-sm">
                            <span className="text-muted-foreground">Notes:</span> {currentShipment.notes}
                          </p>
                        )}
                      </div>
                    </Card>
                  )}
                </TabsContent>

                {/* Actions */}
                <TabsContent value="actions" className="space-y-4 mt-6">
                  {latestStatus?.status === "delivered" && !currentShipment.deliveryConfirmedAt && (
                    <Card className="p-6 border-green-200 bg-green-50">
                      <h3 className="font-semibold mb-4">Confirm Delivery</h3>
                      <div className="space-y-4">
                        <textarea
                          value={deliveryNotes}
                          onChange={e => setDeliveryNotes(e.target.value)}
                          placeholder="Add any notes about the delivery (optional)..."
                          className="w-full px-3 py-2 border rounded-md text-sm"
                          rows={3}
                        />
                        <Button onClick={handleConfirmDelivery} className="w-full bg-green-600 hover:bg-green-700">
                          <CheckCircle2 className="h-4 w-4 mr-2" />
                          Confirm Delivery
                        </Button>
                      </div>
                    </Card>
                  )}

                  {currentShipment.deliveryConfirmedAt && (
                    <Card className="p-6 border-green-200 bg-green-50">
                      <p className="text-sm text-green-700">
                        ✓ Delivery confirmed on {new Date(currentShipment.deliveryConfirmedAt).toLocaleDateString()}
                      </p>
                    </Card>
                  )}

                  <Card className="p-6">
                    <h3 className="font-semibold mb-4">Support</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Contact Seller
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Phone className="h-4 w-4 mr-2" />
                        Customer Support
                      </Button>
                      {latestStatus?.status !== "delivered" && (
                        <Button
                          variant="outline"
                          className="w-full justify-start text-red-600 hover:text-red-700"
                          onClick={() => onRequestRefund?.(currentShipment.id)}
                        >
                          <AlertCircle className="h-4 w-4 mr-2" />
                          Request Refund
                        </Button>
                      )}
                    </div>
                  </Card>

                  <Card className="p-6">
                    <h3 className="font-semibold mb-4">More Options</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <Download className="h-4 w-4 mr-2" />
                        Download Label
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Home className="h-4 w-4 mr-2" />
                        Return to Sender
                      </Button>
                    </div>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
