'use client';

import { useState } from 'react';
import { Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';

interface PremiumJobListingsButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline' | 'secondary';
  size?: 'default' | 'sm' | 'lg';
  className?: string;
}

export function PremiumJobListingsButton({
  onSuccess,
  variant = 'default',
  size = 'default',
  className = 'w-full',
}: PremiumJobListingsButtonProps) {
  const { products, sdk, restoredPurchases } = usePiAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Find the product
  const product = products?.find(
    (p) => p.id === PRODUCT_CONFIG.PREMIUM_JOB_LISTINGS
  );

  // Check if already purchased
  const isPurchased = restoredPurchases?.some((p) => p.productId === product?.slug);

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Premium job listings product not available');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result.ok) {
        setSuccess(true);
        setTimeout(() => {
          onSuccess?.();
          setSuccess(false);
        }, 2000);
      } else {
        setError('Purchase failed');
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Premium job listings product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      setError(errorMessages[errorCode] || 'Purchase failed');
    } finally {
      setIsLoading(false);
    }
  };

  if (!product) {
    return (
      <Button disabled variant="outline" size={size} className={className}>
        <Briefcase className="mr-2 h-4 w-4" />
        Premium Jobs Unavailable
      </Button>
    );
  }

  if (isPurchased) {
    return (
      <Button disabled variant="outline" size={size} className={className}>
        <Briefcase className="mr-2 h-4 w-4" />
        Premium Jobs Unlocked
      </Button>
    );
  }

  return (
    <div className="space-y-2">
      <Button
        onClick={handlePurchase}
        disabled={isLoading}
        variant={variant}
        size={size}
        className={`${className} ${
          variant === 'default'
            ? 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800'
            : ''
        }`}
      >
        <Briefcase className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing...' : `Premium Job Listings (${product.price_in_pi} π)`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          Premium job listings activated successfully!
        </div>
      )}
    </div>
  );
}
