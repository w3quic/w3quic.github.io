"use client"

import React, { useState } from "react"
import {
  Zap, TrendingUp, BarChart3, DollarSign, Target, Eye, Click, ShoppingCart,
  Plus, Edit2, Pause, Play, Trash2, Settings,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { AdCampaign, AdType, PromotionalOffer } from "@/lib/market/types"
import { AD_TYPES, AD_CAMPAIGN_STATUS_COLORS } from "@/lib/market/advertising-platform"

interface AdvertisingManagerProps {
  campaigns: AdCampaign[]
  offers: PromotionalOffer[]
  onCreateCampaign?: (data: any) => void
  onUpdateCampaign?: (campaignId: string, data: any) => void
  onDeleteCampaign?: (campaignId: string) => void
  onPauseCampaign?: (campaignId: string) => void
  onResumeCampaign?: (campaignId: string) => void
  onCreateOffer?: (data: any) => void
}

export function AdvertisingManager({
  campaigns,
  offers,
  onCreateCampaign,
  onUpdateCampaign,
  onDeleteCampaign,
  onPauseCampaign,
  onResumeCampaign,
  onCreateOffer,
}: AdvertisingManagerProps) {
  const [activeTab, setActiveTab] = useState("campaigns")
  const [showCreateCampaign, setShowCreateCampaign] = useState(false)
  const [showCreateOffer, setShowCreateOffer] = useState(false)
  const [selectedCampaign, setSelectedCampaign] = useState<string | null>(null)

  const [campaignForm, setCampaignForm] = useState({
    type: "featured-product" as AdType,
    budget: 10,
    dailyBudget: 2,
    bidAmount: 0.5,
    startDate: new Date().toISOString().split("T")[0],
    endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
  })

  const [offerForm, setOfferForm] = useState({
    discountType: "percentage" as const,
    discountValue: 10,
    minPurchase: 0,
    maxDiscount: 0,
    maxUses: 100,
  })

  const activeCampaigns = campaigns.filter(c => c.status === "active")
  const pausedCampaigns = campaigns.filter(c => c.status === "paused")
  const completedCampaigns = campaigns.filter(c => c.status === "completed")

  const currentCampaign = campaigns.find(c => c.id === selectedCampaign)

  const handleCreateCampaign = () => {
    if (onCreateCampaign) {
      onCreateCampaign(campaignForm)
      setCampaignForm({
        type: "featured-product",
        budget: 10,
        dailyBudget: 2,
        bidAmount: 0.5,
        startDate: new Date().toISOString().split("T")[0],
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      })
      setShowCreateCampaign(false)
    }
  }

  const handleCreateOffer = () => {
    if (onCreateOffer) {
      onCreateOffer(offerForm)
      setOfferForm({
        discountType: "percentage",
        discountValue: 10,
        minPurchase: 0,
        maxDiscount: 0,
        maxUses: 100,
      })
      setShowCreateOffer(false)
    }
  }

  const getMetrics = (campaign: AdCampaign) => {
    const ctr = campaign.impressions > 0 ? ((campaign.clicks / campaign.impressions) * 100).toFixed(2) : "0.00"
    const conversionRate = campaign.clicks > 0 ? ((campaign.conversions / campaign.clicks) * 100).toFixed(2) : "0.00"
    return { ctr, conversionRate }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Advertising Manager</h2>
        <p className="text-sm text-muted-foreground">Boost visibility and drive sales</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="campaigns" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            Campaigns
          </TabsTrigger>
          <TabsTrigger value="offers" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Promotions
          </TabsTrigger>
        </TabsList>

        {/* CAMPAIGNS TAB */}
        <TabsContent value="campaigns" className="space-y-4">
          {/* Create Button */}
          {!showCreateCampaign && (
            <Button
              onClick={() => setShowCreateCampaign(true)}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create New Campaign
            </Button>
          )}

          {/* Create Campaign Form */}
          {showCreateCampaign && (
            <Card className="p-6 border-blue-200 bg-blue-50">
              <h3 className="font-semibold mb-4">Create Advertising Campaign</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Campaign Type</label>
                  <select
                    value={campaignForm.type}
                    onChange={e => setCampaignForm({ ...campaignForm, type: e.target.value as AdType })}
                    className="w-full px-3 py-2 border rounded-md mt-1"
                  >
                    {Object.entries(AD_TYPES).map(([key, value]) => (
                      <option key={key} value={key}>
                        {value.label} - {value.description}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Total Budget (Pi)</label>
                    <Input
                      type="number"
                      value={campaignForm.budget}
                      onChange={e => setCampaignForm({ ...campaignForm, budget: parseFloat(e.target.value) })}
                      min="1"
                      step="0.5"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Daily Budget (Pi)</label>
                    <Input
                      type="number"
                      value={campaignForm.dailyBudget}
                      onChange={e => setCampaignForm({ ...campaignForm, dailyBudget: parseFloat(e.target.value) })}
                      min="0.1"
                      step="0.1"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Start Date</label>
                    <Input
                      type="date"
                      value={campaignForm.startDate}
                      onChange={e => setCampaignForm({ ...campaignForm, startDate: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">End Date</label>
                    <Input
                      type="date"
                      value={campaignForm.endDate}
                      onChange={e => setCampaignForm({ ...campaignForm, endDate: e.target.value })}
                    />
                  </div>
                </div>
                {campaignForm.type === "sponsored-search" && (
                  <div>
                    <label className="text-sm font-medium">Bid Amount per Click (Pi)</label>
                    <Input
                      type="number"
                      value={campaignForm.bidAmount}
                      onChange={e => setCampaignForm({ ...campaignForm, bidAmount: parseFloat(e.target.value) })}
                      min="0.1"
                      step="0.1"
                    />
                  </div>
                )}
                <div className="flex gap-2">
                  <Button onClick={handleCreateCampaign} className="flex-1 bg-blue-600 hover:bg-blue-700">
                    Create Campaign
                  </Button>
                  <Button variant="outline" onClick={() => setShowCreateCampaign(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* Campaign Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="p-4">
              <div className="text-sm text-muted-foreground mb-1">Active Campaigns</div>
              <p className="text-3xl font-bold">{activeCampaigns.length}</p>
            </Card>
            <Card className="p-4">
              <div className="text-sm text-muted-foreground mb-1">Total Impressions</div>
              <p className="text-3xl font-bold">{campaigns.reduce((sum, c) => sum + c.impressions, 0).toLocaleString()}</p>
            </Card>
            <Card className="p-4">
              <div className="text-sm text-muted-foreground mb-1">Total Clicks</div>
              <p className="text-3xl font-bold">{campaigns.reduce((sum, c) => sum + c.clicks, 0).toLocaleString()}</p>
            </Card>
            <Card className="p-4">
              <div className="text-sm text-muted-foreground mb-1">Total Conversions</div>
              <p className="text-3xl font-bold">{campaigns.reduce((sum, c) => sum + c.conversions, 0).toLocaleString()}</p>
            </Card>
          </div>

          {/* Campaigns List */}
          <Tabs defaultValue="active" className="w-full">
            <TabsList>
              <TabsTrigger value="active">Active ({activeCampaigns.length})</TabsTrigger>
              <TabsTrigger value="paused">Paused ({pausedCampaigns.length})</TabsTrigger>
              <TabsTrigger value="completed">Completed ({completedCampaigns.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="space-y-3">
              {activeCampaigns.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-muted-foreground">No active campaigns</p>
                </Card>
              ) : (
                activeCampaigns.map(campaign => {
                  const metrics = getMetrics(campaign)
                  return (
                    <Card
                      key={campaign.id}
                      onClick={() => setSelectedCampaign(campaign.id)}
                      className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-semibold">{AD_TYPES[campaign.type]?.label}</p>
                            <p className="text-xs text-muted-foreground">{campaign.id.slice(0, 8)}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="ghost" onClick={e => { e.stopPropagation(); onPauseCampaign?.(campaign.id) }}>
                              <Pause className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={e => { e.stopPropagation(); onDeleteCampaign?.(campaign.id) }}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-5 gap-2 text-xs">
                          <div>
                            <p className="text-muted-foreground">Budget</p>
                            <p className="font-semibold">{campaign.budget} Pi</p>
                          </div>
                          <div>
                            <div className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              <p className="font-semibold">{campaign.impressions}</p>
                            </div>
                          </div>
                          <div>
                            <div className="flex items-center gap-1">
                              <Click className="h-3 w-3" />
                              <p className="font-semibold">{campaign.clicks}</p>
                            </div>
                          </div>
                          <div>
                            <div className="flex items-center gap-1">
                              <ShoppingCart className="h-3 w-3" />
                              <p className="font-semibold">{campaign.conversions}</p>
                            </div>
                          </div>
                          <div>
                            <p className="text-muted-foreground">CTR</p>
                            <p className="font-semibold">{metrics.ctr}%</p>
                          </div>
                        </div>
                      </div>
                    </Card>
                  )
                })
              )}
            </TabsContent>

            <TabsContent value="paused">
              {pausedCampaigns.map(campaign => (
                <Card key={campaign.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{AD_TYPES[campaign.type]?.label}</p>
                      <p className="text-sm text-muted-foreground">{campaign.budget} Pi budget</p>
                    </div>
                    <Button size="sm" onClick={() => onResumeCampaign?.(campaign.id)}>
                      <Play className="h-4 w-4 mr-1" />
                      Resume
                    </Button>
                  </div>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="completed">
              {completedCampaigns.map(campaign => (
                <Card key={campaign.id} className="p-4 opacity-75">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{AD_TYPES[campaign.type]?.label}</p>
                      <p className="text-sm text-muted-foreground">{campaign.conversions} conversions • {campaign.clicks} clicks</p>
                    </div>
                  </div>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* OFFERS TAB */}
        <TabsContent value="offers" className="space-y-4">
          {!showCreateOffer && (
            <Button
              onClick={() => setShowCreateOffer(true)}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Promotion
            </Button>
          )}

          {showCreateOffer && (
            <Card className="p-6 border-green-200 bg-green-50">
              <h3 className="font-semibold mb-4">Create Promotional Offer</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Discount Type</label>
                  <select
                    value={offerForm.discountType}
                    onChange={e => setOfferForm({ ...offerForm, discountType: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-md mt-1"
                  >
                    <option value="percentage">Percentage Off</option>
                    <option value="fixed">Fixed Amount</option>
                    <option value="bogo">Buy One Get One</option>
                    <option value="tiered">Tiered Discount</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Discount Value</label>
                    <Input
                      type="number"
                      value={offerForm.discountValue}
                      onChange={e => setOfferForm({ ...offerForm, discountValue: parseFloat(e.target.value) })}
                      placeholder="10"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Min Purchase (Pi)</label>
                    <Input
                      type="number"
                      value={offerForm.minPurchase}
                      onChange={e => setOfferForm({ ...offerForm, minPurchase: parseFloat(e.target.value) })}
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Max Discount (Pi)</label>
                    <Input
                      type="number"
                      value={offerForm.maxDiscount}
                      onChange={e => setOfferForm({ ...offerForm, maxDiscount: parseFloat(e.target.value) })}
                      placeholder="0 (unlimited)"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Max Uses</label>
                    <Input
                      type="number"
                      value={offerForm.maxUses}
                      onChange={e => setOfferForm({ ...offerForm, maxUses: parseFloat(e.target.value) })}
                      placeholder="100"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleCreateOffer} className="flex-1 bg-green-600 hover:bg-green-700">
                    Create Offer
                  </Button>
                  <Button variant="outline" onClick={() => setShowCreateOffer(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* Offers List */}
          <div className="space-y-3">
            {offers.length === 0 ? (
              <Card className="p-8 text-center">
                <p className="text-muted-foreground">No active promotions</p>
              </Card>
            ) : (
              offers.map(offer => (
                <Card key={offer.id} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="font-semibold">
                        {offer.discountValue}
                        {offer.discountType === "percentage" ? "% Off" : " Pi Off"}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Used {offer.currentUses} / {offer.maxUses} times
                      </p>
                      {offer.minPurchaseAmount && (
                        <p className="text-xs text-muted-foreground">
                          Min purchase: {offer.minPurchaseAmount} Pi
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="ghost">
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
