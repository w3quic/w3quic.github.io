'use client';

import { useState } from 'react';
import { Truck, AlertCircle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { toast } from '@/hooks/use-toast';

interface VehicleMarketplaceButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline';
  showPriceInLabel?: boolean;
  showFeatures?: boolean;
  fullWidth?: boolean;
}

export function VehicleMarketplaceButton({ 
  onSuccess, 
  variant = 'default', 
  showPriceInLabel = true, 
  showFeatures = false,
  fullWidth = false 
}: VehicleMarketplaceButtonProps) {
  const piAuth = usePiAuth();
  const { go } = useNav();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { products, sdk, restoredPurchases } = piAuth || {};

  // Find the vehicle marketplace product using the correct product ID (6a34c37c8a9e196fe6e7f4f1 - 0.5 Pi)
  const product = products?.find(p => p.id === PRODUCT_CONFIG.PRODUCT_6a34c37c8a9e196fe6e7f4f1);

  // Check if already purchased
  const isVehicleMarketplacePurchased = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  // Show activated badge if already purchased
  if (isVehicleMarketplacePurchased) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 px-3 py-2">
        <Truck className="h-4 w-4 text-green-600" />
        <span className="text-sm font-medium text-green-700">Vehicle Marketplace Activated</span>
      </div>
    );
  }

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Vehicle marketplace product not available');
      toast({
        title: 'Error',
        description: 'Vehicle marketplace product not available',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result?.ok) {
        setSuccess(true);
        
        toast({
          title: 'Success!',
          description: 'Vehicle Marketplace unlocked successfully!',
        });
        
        onSuccess?.();
        
        // Navigate to vehicle marketplace after a short delay
        setTimeout(() => {
          setSuccess(false);
          go({ name: 'vehicle-marketplace' });
        }, 1500);
      } else {
        setError('Purchase failed. Please try again.');
        toast({
          title: 'Purchase Failed',
          description: 'Please try again.',
          variant: 'destructive',
        });
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Vehicle marketplace product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      const errorMsg = errorMessages[errorCode] || 'Purchase failed';
      setError(errorMsg);
      toast({
        title: 'Purchase Error',
        description: errorMsg,
        variant: 'destructive',
      });
      console.error('[Vehicle Marketplace] Purchase error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Product not available
  if (!product) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <AlertCircle className="mr-2 h-4 w-4" />
        Vehicle Marketplace Unavailable
      </Button>
    );
  }

  // SDK not ready
  if (!sdk || !piAuth?.isAuthenticated) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <Truck className="mr-2 h-4 w-4" />
        Loading...
      </Button>
    );
  }

  const priceLabel = showPriceInLabel && product ? ` (${product.price_in_pi} π)` : '';
  const buttonVariant = variant === 'outline' ? 'outline' : 'default';
  const isDefaultVariant = variant === 'default';

  const features = [
    'Buy & Sell Vehicles',
    'Cars, Trucks & Motorcycles',
    'Heavy Equipment',
    'Advanced Search & Filters',
    'Seller Verification',
    'Premium Listings',
    'Favorites & Saved Items',
    'Secure Pi Payment'
  ];

  return (
    <div className="space-y-3">
      {showFeatures && (
        <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 space-y-2">
          <h3 className="text-sm font-semibold text-amber-900">Vehicle Marketplace Features:</h3>
          <ul className="text-xs text-amber-800 space-y-1">
            {features.map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Zap className="h-3 w-3 mt-0.5 text-amber-600 flex-shrink-0" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Button
        onClick={handlePurchase}
        disabled={isLoading || !product || !sdk}
        variant={buttonVariant}
        className={isDefaultVariant ? `${fullWidth ? 'w-full' : ''} bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white` : fullWidth ? 'w-full' : ''}
      >
        <Truck className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing Payment...' : `Vehicle Marketplace${priceLabel}`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          ✓ Vehicle Marketplace unlocked successfully!
        </div>
      )}
    </div>
  );
}
