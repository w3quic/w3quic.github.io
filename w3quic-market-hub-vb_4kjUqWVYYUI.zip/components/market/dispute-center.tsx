"use client"

import React, { useState } from "react"
import { AlertCircle, MessageSquare, Upload, Clock, CheckCircle, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { Dispute, Order, DisputeReasonType } from "@/lib/market/types"
import { addDisputeMessage, addDisputeEvidence } from "@/lib/market/secure-trading"

interface DisputeCenterProps {
  disputes: Dispute[]
  orders: Record<string, Order>
  onCreateDispute?: (orderId: string, reason: DisputeReasonType, description: string) => void
  onAddEvidence?: (disputeId: string, type: "image" | "document" | "message" | "tracking", url: string, description: string) => void
  onAddMessage?: (disputeId: string, text: string) => void
  isAdmin?: boolean
  onResolveDispute?: (disputeId: string, type: string, reason: string, compensation?: number) => void
}

const DISPUTE_REASONS: { id: DisputeReasonType; label: string }[] = [
  { id: "item-not-received", label: "Item Not Received" },
  { id: "item-not-as-described", label: "Item Not As Described" },
  { id: "defective-damaged", label: "Defective or Damaged" },
  { id: "counterfeit", label: "Counterfeit Product" },
  { id: "unauthorized-transaction", label: "Unauthorized Transaction" },
  { id: "wrong-item", label: "Wrong Item Received" },
  { id: "other", label: "Other" },
]

export function DisputeCenter({
  disputes,
  orders,
  onCreateDispute,
  onAddEvidence,
  onAddMessage,
  isAdmin = false,
  onResolveDispute,
}: DisputeCenterProps) {
  const [activeTab, setActiveTab] = useState("active")
  const [selectedDispute, setSelectedDispute] = useState<string | null>(null)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [createForm, setCreateForm] = useState({
    orderId: "",
    reason: "item-not-received" as DisputeReasonType,
    description: "",
  })
  const [messageText, setMessageText] = useState("")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [evidenceDescription, setEvidenceDescription] = useState("")

  const activeDisputes = disputes.filter(d => d.status === "open")
  const resolvedDisputes = disputes.filter(d => d.status === "resolved")

  const currentDispute = disputes.find(d => d.id === selectedDispute)

  const handleCreateDispute = () => {
    if (createForm.orderId && createForm.description && onCreateDispute) {
      onCreateDispute(createForm.orderId, createForm.reason, createForm.description)
      setCreateForm({ orderId: "", reason: "item-not-received", description: "" })
      setShowCreateDialog(false)
    }
  }

  const handleSendMessage = () => {
    if (messageText && currentDispute && onAddMessage) {
      onAddMessage(currentDispute.id, messageText)
      setMessageText("")
    }
  }

  const handleAddEvidence = () => {
    if (currentDispute && onAddEvidence && selectedFile) {
      const url = URL.createObjectURL(selectedFile)
      const type = selectedFile.type.startsWith("image") ? "image" : "document"
      onAddEvidence(currentDispute.id, type as any, url, evidenceDescription)
      setSelectedFile(null)
      setEvidenceDescription("")
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Dispute Center</h2>
          <p className="text-sm text-muted-foreground">Manage and resolve order disputes</p>
        </div>
        <Button onClick={() => setShowCreateDispute(!showCreateDialog)}>Open Dispute</Button>
      </div>

      {/* Create Dispute Dialog */}
      {showCreateDialog && (
        <Card className="p-6 border-blue-200 bg-blue-50">
          <h3 className="font-semibold mb-4">Open a New Dispute</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Order ID</label>
              <Input
                value={createForm.orderId}
                onChange={e => setCreateForm({ ...createForm, orderId: e.target.value })}
                placeholder="Select order"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Dispute Reason</label>
              <select
                value={createForm.reason}
                onChange={e => setCreateForm({ ...createForm, reason: e.target.value as DisputeReasonType })}
                className="w-full px-3 py-2 border rounded-md"
              >
                {DISPUTE_REASONS.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={createForm.description}
                onChange={e => setCreateForm({ ...createForm, description: e.target.value })}
                placeholder="Describe the issue in detail..."
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCreateDispute} className="bg-blue-600 hover:bg-blue-700">
                Create Dispute
              </Button>
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList>
          <TabsTrigger value="active" className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4" />
            Active ({activeDisputes.length})
          </TabsTrigger>
          <TabsTrigger value="resolved" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            Resolved ({resolvedDisputes.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          {activeDisputes.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No active disputes</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Disputes List */}
              <div className="lg:col-span-1 space-y-2">
                {activeDisputes.map(dispute => (
                  <Card
                    key={dispute.id}
                    onClick={() => setSelectedDispute(dispute.id)}
                    className={`p-4 cursor-pointer transition-colors ${
                      selectedDispute === dispute.id ? "border-blue-500 bg-blue-50" : "hover:bg-gray-50"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="min-w-0">
                        <p className="font-medium truncate">Dispute #{dispute.id.slice(0, 8)}</p>
                        <p className="text-xs text-muted-foreground">{dispute.reason}</p>
                      </div>
                      <Clock className="h-4 w-4 text-orange-500 flex-shrink-0" />
                    </div>
                  </Card>
                ))}
              </div>

              {/* Dispute Details */}
              {currentDispute && (
                <div className="lg:col-span-2 space-y-4">
                  {/* Header */}
                  <Card className="p-4 border-blue-200 bg-blue-50">
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">Order #{currentDispute.orderId}</p>
                      <h3 className="font-semibold text-lg capitalize">{currentDispute.reason.replace(/-/g, " ")}</h3>
                      <p className="text-sm">{currentDispute.description}</p>
                    </div>
                  </Card>

                  {/* Evidence Tabs */}
                  <Tabs defaultValue="messages" className="w-full">
                    <TabsList>
                      <TabsTrigger value="messages">Messages ({currentDispute.messages.length})</TabsTrigger>
                      <TabsTrigger value="evidence">Evidence ({currentDispute.buyerEvidence.length + currentDispute.sellerEvidence.length})</TabsTrigger>
                    </TabsList>

                    <TabsContent value="messages" className="space-y-4">
                      <Card className="p-4 h-64 overflow-y-auto bg-gray-50">
                        <div className="space-y-3">
                          {currentDispute.messages.map((msg, i) => (
                            <div key={i} className="flex gap-3">
                              <div className="text-xs font-medium bg-white px-2 py-1 rounded min-w-fit">
                                {msg.userId === currentDispute.buyerId ? "Buyer" : "Seller"}
                              </div>
                              <div>
                                <p className="text-sm">{msg.text}</p>
                                <p className="text-xs text-muted-foreground">{new Date(msg.at).toLocaleString()}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </Card>

                      {currentDispute.status === "open" && (
                        <div className="space-y-2">
                          <Textarea
                            value={messageText}
                            onChange={e => setMessageText(e.target.value)}
                            placeholder="Add message to dispute..."
                          />
                          <Button onClick={handleSendMessage} className="w-full">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Send Message
                          </Button>
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="evidence" className="space-y-4">
                      {currentDispute.status === "open" && (
                        <Card className="p-4 border-blue-200 bg-blue-50">
                          <div className="space-y-3">
                            <div>
                              <label className="text-sm font-medium">Upload Evidence</label>
                              <input
                                type="file"
                                onChange={e => setSelectedFile(e.target.files?.[0] || null)}
                                className="mt-1 block w-full text-sm"
                              />
                            </div>
                            <Textarea
                              value={evidenceDescription}
                              onChange={e => setEvidenceDescription(e.target.value)}
                              placeholder="Describe the evidence..."
                            />
                            <Button onClick={handleAddEvidence} className="w-full">
                              <Upload className="h-4 w-4 mr-2" />
                              Upload Evidence
                            </Button>
                          </div>
                        </Card>
                      )}

                      {/* Evidence Lists */}
                      {currentDispute.buyerEvidence.length > 0 && (
                        <div>
                          <p className="font-medium mb-2">Buyer Evidence</p>
                          <div className="space-y-2">
                            {currentDispute.buyerEvidence.map(ev => (
                              <Card key={ev.id} className="p-2">
                                <p className="text-sm">{ev.description}</p>
                              </Card>
                            ))}
                          </div>
                        </div>
                      )}

                      {currentDispute.sellerEvidence.length > 0 && (
                        <div>
                          <p className="font-medium mb-2">Seller Evidence</p>
                          <div className="space-y-2">
                            {currentDispute.sellerEvidence.map(ev => (
                              <Card key={ev.id} className="p-2">
                                <p className="text-sm">{ev.description}</p>
                              </Card>
                            ))}
                          </div>
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>

                  {/* Admin Resolution */}
                  {isAdmin && currentDispute.status === "open" && (
                    <Card className="p-4 border-amber-200 bg-amber-50">
                      <h4 className="font-semibold mb-3">Admin Resolution</h4>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => onResolveDispute?.(currentDispute.id, "refund-buyer", "Refund approved")}>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Refund Buyer
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => onResolveDispute?.(currentDispute.id, "release-to-seller", "Approved for seller")}>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Release to Seller
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => onResolveDispute?.(currentDispute.id, "partial-refund", "Partial resolution")}>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Partial Refund
                        </Button>
                      </div>
                    </Card>
                  )}
                </div>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent value="resolved" className="space-y-4">
          {resolvedDisputes.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No resolved disputes</p>
            </Card>
          ) : (
            <div className="space-y-2">
              {resolvedDisputes.map(dispute => (
                <Card key={dispute.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Dispute #{dispute.id.slice(0, 8)}</p>
                      <p className="text-sm text-muted-foreground">{dispute.reason}</p>
                    </div>
                    <div className="text-right">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <p className="text-xs text-muted-foreground">{dispute.resolution?.type}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
