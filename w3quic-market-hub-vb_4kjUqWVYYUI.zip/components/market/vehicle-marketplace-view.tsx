'use client';

import { useMemo, useState } from 'react';
import { Truck, Search, SlidersHorizontal, X } from 'lucide-react';
import { useMarket } from '@/lib/market/store';
import { ProductCard } from './product-card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetFooter } from '@/components/ui/sheet';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty';
import { EscrowPaymentButton } from './escrow-payment-button';
import { effectivePrice } from '@/lib/market/helpers';

type Sort = 'trending' | 'newest' | 'price-low' | 'price-high' | 'rating' | 'popularity';

// Vehicle categories
const VEHICLE_CATEGORIES = [
  { id: 'cars', label: 'Cars' },
  { id: 'trucks', label: 'Trucks' },
  { id: 'motorcycles', label: 'Motorcycles' },
  { id: 'heavy-equipment', label: 'Heavy Equipment' },
  { id: 'parts', label: 'Parts & Accessories' },
];

export function VehicleMarketplaceView() {
  const { products, getSeller } = useMarket();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState<string>('all');
  const [sort, setSort] = useState<Sort>('trending');
  const [maxPrice, setMaxPrice] = useState(700);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [open, setOpen] = useState(false);

  // Filter for vehicle-related products
  const vehicleProducts = useMemo(
    () => products.filter(p => 
      p.category === 'vehicles' || 
      p.title.toLowerCase().includes('car') ||
      p.title.toLowerCase().includes('truck') ||
      p.title.toLowerCase().includes('motorcycle') ||
      p.title.toLowerCase().includes('vehicle')
    ),
    [products]
  );

  const list = useMemo(() => {
    let r = vehicleProducts.filter((p) => p.stock > 0 || p.auction);
    
    if (q.trim()) {
      const s = q.toLowerCase();
      r = r.filter((p) => 
        p.title.toLowerCase().includes(s) || 
        p.description.toLowerCase().includes(s)
      );
    }
    
    if (cat !== 'all') {
      r = r.filter((p) => {
        const title = p.title.toLowerCase();
        switch (cat) {
          case 'cars':
            return title.includes('car');
          case 'trucks':
            return title.includes('truck');
          case 'motorcycles':
            return title.includes('motorcycle') || title.includes('bike');
          case 'heavy-equipment':
            return title.includes('equipment') || title.includes('excavator') || title.includes('loader');
          case 'parts':
            return title.includes('part') || title.includes('accessory');
          default:
            return true;
        }
      });
    }
    
    r = r.filter((p) => effectivePrice(p) <= maxPrice);
    
    if (verifiedOnly) {
      r = r.filter((p) => {
        const s = getSeller(p.sellerId);
        return s && (s.verification === 'verified' || s.verification === 'trusted');
      });
    }

    const sellerRating = (id: string) => getSeller(id)?.rating ?? 0;
    switch (sort) {
      case 'newest':
        r = [...r].sort((a, b) => b.createdAt - a.createdAt);
        break;
      case 'price-low':
        r = [...r].sort((a, b) => effectivePrice(a) - effectivePrice(b));
        break;
      case 'price-high':
        r = [...r].sort((a, b) => effectivePrice(b) - effectivePrice(a));
        break;
      case 'rating':
        r = [...r].sort((a, b) => sellerRating(b.sellerId) - sellerRating(a.sellerId));
        break;
      case 'popularity':
        r = [...r].sort((a, b) => b.views - a.views);
        break;
      default:
        r = [...r].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || b.views - a.views);
    }
    
    return r;
  }, [vehicleProducts, q, cat, maxPrice, verifiedOnly, sort, getSeller]);

  const activeFilters = [verifiedOnly].filter(Boolean).length + (maxPrice < 700 ? 1 : 0);

  return (
    <div className="animate-fade-in px-4 py-4">
      {/* Header */}
      <div className="mb-4 flex items-center gap-2">
        <Truck className="h-6 w-6 text-amber-600" />
        <div>
          <h1 className="text-xl font-bold">Vehicle Marketplace</h1>
          <p className="text-xs text-muted-foreground">Buy, sell & trade vehicles</p>
        </div>
      </div>

      <div className="sticky top-14 z-20 -mx-4 mb-3 bg-background/95 px-4 py-2 backdrop-blur">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search vehicles..."
              className="pl-9"
              aria-label="Search vehicles"
            />
            {q && (
              <button
                onClick={() => setQ('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                aria-label="Clear"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="relative shrink-0" aria-label="Filters">
                <SlidersHorizontal className="h-4 w-4" />
                {activeFilters > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
                    {activeFilters}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <SheetHeader>
                <SheetTitle>Filters & Sort</SheetTitle>
              </SheetHeader>
              <div className="flex flex-col gap-5 overflow-y-auto px-4 py-2">
                <div className="grid gap-2">
                  <Label>Sort by</Label>
                  <Select value={sort} onValueChange={(v) => setSort(v as Sort)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="trending">Trending / Relevance</SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="rating">Top Rated</SelectItem>
                      <SelectItem value="popularity">Most Popular</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Vehicle Type</Label>
                  <Select value={cat} onValueChange={(v) => setCat(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {VEHICLE_CATEGORIES.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Max price: {maxPrice} π</Label>
                  <Slider
                    value={[maxPrice]}
                    min={10}
                    max={700}
                    step={10}
                    onValueChange={(v) => setMaxPrice(v[0])}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="vf">Verified sellers only</Label>
                  <Switch
                    id="vf"
                    checked={verifiedOnly}
                    onCheckedChange={setVerifiedOnly}
                  />
                </div>
              </div>
              <SheetFooter>
                <Button onClick={() => setOpen(false)}>Show {list.length} results</Button>
              </SheetFooter>
            </SheetContent>
          </Sheet>
        </div>
        <div className="no-scrollbar mt-2 flex gap-1.5 overflow-x-auto">
          <CatChip
            active={cat === 'all'}
            onClick={() => setCat('all')}
            label="All"
          />
          {VEHICLE_CATEGORIES.map((c) => (
            <CatChip
              key={c.id}
              active={cat === c.id}
              onClick={() => setCat(c.id)}
              label={c.label}
            />
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Truck />
            </EmptyMedia>
            <EmptyTitle>No vehicles found</EmptyTitle>
            <EmptyDescription>Try adjusting your search or filters.</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 pb-20">
            {list.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
          {/* Escrow Protection */}
          <div className="fixed inset-x-0 bottom-20 z-30 mx-auto max-w-2xl px-4">
            <EscrowPaymentButton fullWidth variant="default" />
          </div>
        </>
      )}
    </div>
  );
}

function CatChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
        active
          ? 'bg-primary text-primary-foreground'
          : 'border border-border bg-card text-card-foreground hover:bg-accent'
      }`}
    >
      {label}
    </button>
  );
}
