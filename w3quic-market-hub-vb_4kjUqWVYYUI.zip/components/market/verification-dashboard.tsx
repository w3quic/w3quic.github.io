"use client"

import React, { useState } from "react"
import {
  CheckCircle, Clock, XCircle, Upload, Mail, FileText, Building, CreditCard,
  Eye, EyeOff, AlertCircle, Award,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { BusinessVerification, IdentityVerification, VerificationBadgeType } from "@/lib/market/types"
import { VERIFICATION_BADGES } from "@/lib/market/business-verification"

interface VerificationDashboardProps {
  businessVerification?: BusinessVerification
  identityVerification?: IdentityVerification
  badges: VerificationBadgeType[]
  onSubmitBusiness?: (data: any) => void
  onSubmitIdentity?: (data: any) => void
  onUploadDocument?: (type: string, file: File) => void
}

const DOCUMENT_TYPES = [
  { id: "business-license", label: "Business License" },
  { id: "tax-id", label: "Tax ID Document" },
  { id: "identity-document", label: "Identity Document" },
  { id: "address-proof", label: "Address Proof" },
  { id: "bank-statement", label: "Bank Statement" },
  { id: "incorporation-cert", label: "Incorporation Certificate" },
]

export function VerificationDashboard({
  businessVerification,
  identityVerification,
  badges,
  onSubmitBusiness,
  onSubmitIdentity,
  onUploadDocument,
}: VerificationDashboardProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const [showBusinessForm, setShowBusinessForm] = useState(false)
  const [showIdentityForm, setShowIdentityForm] = useState(false)
  const [businessForm, setBusinessForm] = useState({
    businessName: businessVerification?.businessName || "",
    registrationNumber: businessVerification?.registrationNumber || "",
    businessType: businessVerification?.businessType || "sole-proprietor",
  })
  const [identityForm, setIdentityForm] = useState({
    documentType: identityVerification?.documentType || "passport",
    documentNumber: identityVerification?.documentNumber || "",
  })

  const getStatusColor = (status?: string) => {
    switch (status) {
      case "approved":
        return "text-green-600 bg-green-50"
      case "pending":
        return "text-amber-600 bg-amber-50"
      case "rejected":
        return "text-red-600 bg-red-50"
      default:
        return "text-gray-600 bg-gray-50"
    }
  }

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-5 w-5" />
      case "pending":
        return <Clock className="h-5 w-5" />
      case "rejected":
        return <XCircle className="h-5 w-5" />
      default:
        return <AlertCircle className="h-5 w-5" />
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Verification Dashboard</h2>
        <p className="text-sm text-muted-foreground">Build trust and unlock exclusive features</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="business">Business</TabsTrigger>
          <TabsTrigger value="identity">Identity</TabsTrigger>
          <TabsTrigger value="badges">Badges</TabsTrigger>
        </TabsList>

        {/* OVERVIEW TAB */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Email Verification */}
            <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-6 w-6 text-blue-600" />
                  <div>
                    <p className="font-semibold">Email Verified</p>
                    <p className="text-sm text-muted-foreground">Email confirmation</p>
                  </div>
                </div>
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <Button disabled variant="outline" className="w-full">
                Verified
              </Button>
            </Card>

            {/* Business Verification */}
            <Card className={`p-6 ${businessVerification?.status === "approved" ? "border-green-200 bg-green-50" : businessVerification?.status === "pending" ? "border-amber-200 bg-amber-50" : "border-gray-200"}`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Building className="h-6 w-6 text-indigo-600" />
                  <div>
                    <p className="font-semibold">Business Verified</p>
                    <p className="text-sm text-muted-foreground">{businessVerification?.status || "Not started"}</p>
                  </div>
                </div>
                {getStatusIcon(businessVerification?.status)}
              </div>
              <Button
                onClick={() => setShowBusinessForm(!showBusinessForm)}
                variant={businessVerification?.status === "approved" ? "outline" : "default"}
                className="w-full"
              >
                {businessVerification ? "Update" : "Start Verification"}
              </Button>
            </Card>

            {/* Identity Verification */}
            <Card className={`p-6 ${identityVerification?.status === "approved" ? "border-green-200 bg-green-50" : identityVerification?.status === "pending" ? "border-amber-200 bg-amber-50" : "border-gray-200"}`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <CreditCard className="h-6 w-6 text-purple-600" />
                  <div>
                    <p className="font-semibold">Identity Verified</p>
                    <p className="text-sm text-muted-foreground">{identityVerification?.status || "Not started"}</p>
                  </div>
                </div>
                {getStatusIcon(identityVerification?.status)}
              </div>
              <Button
                onClick={() => setShowIdentityForm(!showIdentityForm)}
                variant={identityVerification?.status === "approved" ? "outline" : "default"}
                className="w-full"
              >
                {identityVerification ? "Update" : "Start Verification"}
              </Button>
            </Card>

            {/* Overall Progress */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Overall Progress</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Verification Complete</span>
                  <span className="font-semibold">66%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full w-2/3"></div>
                </div>
                <p className="text-xs text-muted-foreground">Identity verification pending</p>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* BUSINESS TAB */}
        <TabsContent value="business" className="space-y-4">
          {showBusinessForm && (
            <Card className="p-6 border-blue-200 bg-blue-50">
              <h3 className="font-semibold mb-4">Business Information</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Business Name</label>
                  <Input
                    value={businessForm.businessName}
                    onChange={e => setBusinessForm({ ...businessForm, businessName: e.target.value })}
                    placeholder="Your business name"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Registration Number</label>
                  <Input
                    value={businessForm.registrationNumber}
                    onChange={e => setBusinessForm({ ...businessForm, registrationNumber: e.target.value })}
                    placeholder="Business registration number"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Business Type</label>
                  <select
                    value={businessForm.businessType}
                    onChange={e => setBusinessForm({ ...businessForm, businessType: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="sole-proprietor">Sole Proprietor</option>
                    <option value="partnership">Partnership</option>
                    <option value="corporation">Corporation</option>
                    <option value="llc">LLC</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <Button onClick={() => onSubmitBusiness?.(businessForm)} className="w-full">
                  Submit for Review
                </Button>
              </div>
            </Card>
          )}

          {/* Documents */}
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Required Documents</h3>
            <div className="space-y-3">
              {DOCUMENT_TYPES.map(doc => (
                <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FileText className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="text-sm font-medium">{doc.label}</p>
                      <p className="text-xs text-muted-foreground">Upload to verify</p>
                    </div>
                  </div>
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      onChange={e => {
                        const file = e.target.files?.[0]
                        if (file) onUploadDocument?.(doc.id, file)
                      }}
                      className="hidden"
                    />
                    <Upload className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                  </label>
                </div>
              ))}
            </div>
          </Card>

          {/* Status */}
          {businessVerification && (
            <Card className={`p-6 ${getStatusColor(businessVerification.status)}`}>
              <div className="flex items-center gap-3">
                {getStatusIcon(businessVerification.status)}
                <div>
                  <p className="font-semibold capitalize">{businessVerification.status}</p>
                  <p className="text-sm">
                    {businessVerification.status === "approved"
                      ? "Your business is verified"
                      : businessVerification.status === "pending"
                        ? "Under review (3-5 business days)"
                        : "Please resubmit with correct documents"}
                  </p>
                </div>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* IDENTITY TAB */}
        <TabsContent value="identity" className="space-y-4">
          {showIdentityForm && (
            <Card className="p-6 border-purple-200 bg-purple-50">
              <h3 className="font-semibold mb-4">Identity Verification</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Document Type</label>
                  <select
                    value={identityForm.documentType}
                    onChange={e => setIdentityForm({ ...identityForm, documentType: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="passport">Passport</option>
                    <option value="national-id">National ID</option>
                    <option value="driver-license">Driver's License</option>
                    <option value="visa">Visa</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium">Document Number</label>
                  <Input
                    value={identityForm.documentNumber}
                    onChange={e => setIdentityForm({ ...identityForm, documentNumber: e.target.value })}
                    placeholder="Enter document number"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Upload Document</label>
                  <div className="mt-2 border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50">
                    <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                    <p className="text-sm text-muted-foreground">Click to upload or drag and drop</p>
                  </div>
                </div>
                <Button onClick={() => onSubmitIdentity?.(identityForm)} className="w-full bg-purple-600 hover:bg-purple-700">
                  Verify Identity
                </Button>
              </div>
            </Card>
          )}

          {/* Status */}
          {identityVerification && (
            <Card className={`p-6 ${getStatusColor(identityVerification.status)}`}>
              <div className="flex items-center gap-3">
                {getStatusIcon(identityVerification.status)}
                <div>
                  <p className="font-semibold capitalize">{identityVerification.status}</p>
                  <p className="text-sm">
                    {identityVerification.status === "approved"
                      ? "Your identity is verified"
                      : identityVerification.status === "pending"
                        ? "Being verified (24-48 hours)"
                        : "Please resubmit with correct information"}
                  </p>
                </div>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* BADGES TAB */}
        <TabsContent value="badges" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(VERIFICATION_BADGES).map(([key, badge]) => {
              const hasEarned = badges.includes(key as VerificationBadgeType)
              return (
                <Card
                  key={key}
                  className={`p-6 ${
                    hasEarned
                      ? "border-amber-200 bg-amber-50"
                      : "border-gray-200 opacity-50"
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <Award className={`h-8 w-8 flex-shrink-0 ${hasEarned ? "text-amber-600" : "text-gray-400"}`} />
                    <div className="flex-1">
                      <p className="font-semibold">{badge.label}</p>
                      <p className="text-sm text-muted-foreground mb-3">{badge.description}</p>
                      <div className="text-xs space-y-1">
                        {badge.requirements.map((req, i) => (
                          <div key={i} className="flex items-center gap-2">
                            <div className={`h-1.5 w-1.5 rounded-full ${hasEarned ? "bg-amber-600" : "bg-gray-300"}`}></div>
                            <span>{req}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
