"use client"

import React, { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Gift,
  TrendingUp,
  Users,
  Award,
  Calendar,
  Zap,
  Target,
  Star,
} from "lucide-react"
import type {
  ReferralProgram,
  AffiliateAccount,
  LoyaltyReward,
  Achievement,
  DailyCheckIn,
  ReputationScore,
} from "@/lib/market/types"

interface GrowthDashboardProps {
  userId: string
  reputationScore?: ReputationScore
  loyaltyPoints?: number
  achievements?: Achievement[]
  referralCode?: string
  affiliateAccount?: AffiliateAccount
  dailyCheckInStreaks?: number
}

export function GrowthDashboard({
  userId,
  reputationScore,
  loyaltyPoints = 0,
  achievements = [],
  referralCode,
  affiliateAccount,
  dailyCheckInStreaks = 0,
}: GrowthDashboardProps) {
  const [copied, setCopied] = useState(false)
  const [checkedInToday, setCheckedInToday] = useState(false)

  const copyReferralCode = () => {
    if (referralCode) {
      navigator.clipboard.writeText(referralCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="space-y-6">
      {/* Reputation Score */}
      {reputationScore && (
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">
                Reputation Score
              </h3>
              <p className="text-sm text-gray-600">
                Level: <span className="font-semibold capitalize">{reputationScore.level}</span>
              </p>
            </div>
            <Star className="h-8 w-8 text-blue-600 fill-blue-600" />
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full rounded-full transition-all"
              style={{ width: `${reputationScore.score}%` }}
            />
          </div>
          <div className="mt-3 text-2xl font-bold text-blue-900">
            {reputationScore.score}/100
          </div>
        </Card>
      )}

      {/* Loyalty Points */}
      <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Loyalty Points</h3>
            <p className="text-sm text-gray-600">Earn rewards for shopping and referrals</p>
          </div>
          <div className="text-4xl font-bold text-amber-600">{loyaltyPoints.toLocaleString()}</div>
        </div>
        <Button variant="outline" className="mt-4 w-full">
          Redeem Points
        </Button>
      </Card>

      {/* Daily Check-in */}
      <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Daily Check-in</h3>
            <p className="text-sm text-gray-600">
              {dailyCheckInStreaks > 0
                ? `${dailyCheckInStreaks} day streak!`
                : "Start your streak today"}
            </p>
          </div>
          <Calendar className="h-8 w-8 text-green-600" />
        </div>
        <Button
          disabled={checkedInToday}
          onClick={() => setCheckedInToday(true)}
          className="w-full bg-green-600 hover:bg-green-700"
        >
          {checked InToday ? "Checked in Today" : "Check in Now"}
        </Button>
      </Card>

      {/* Referral Program */}
      {referralCode && (
        <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Referral Program</h3>
            <Users className="h-6 w-6 text-purple-600" />
          </div>
          <p className="text-sm text-gray-600 mb-3">
            Share your code and earn 5 Pi for each friend who joins
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              value={referralCode}
              readOnly
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-white text-sm font-mono"
            />
            <Button
              onClick={copyReferralCode}
              variant="outline"
              size="sm"
              className="whitespace-nowrap"
            >
              {copied ? "Copied!" : "Copy"}
            </Button>
          </div>
        </Card>
      )}

      {/* Affiliate Account */}
      {affiliateAccount && affiliateAccount.status === "active" && (
        <Card className="border-indigo-200 bg-gradient-to-br from-indigo-50 to-blue-50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Affiliate Earnings</h3>
            <TrendingUp className="h-6 w-6 text-indigo-600" />
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-gray-600 font-medium">Commission Rate</p>
              <p className="text-lg font-bold text-indigo-900">
                {affiliateAccount.commissionRate}%
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-600 font-medium">Total Earnings</p>
              <p className="text-lg font-bold text-indigo-900">
                {affiliateAccount.earnings.toFixed(2)} Pi
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-600 font-medium">Withdrawn</p>
              <p className="text-lg font-bold text-indigo-900">
                {affiliateAccount.withdrawn.toFixed(2)} Pi
              </p>
            </div>
          </div>
          <Button variant="default" className="mt-4 w-full">
            Withdraw Earnings
          </Button>
        </Card>
      )}

      {/* Achievements */}
      {achievements.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Achievements</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className="flex flex-col items-center p-4 rounded-lg bg-gray-50 border border-gray-200 hover:border-amber-400 hover:bg-amber-50 transition-all"
              >
                <Award className="h-8 w-8 text-amber-600 mb-2" />
                <p className="text-sm font-semibold text-gray-900 text-center">
                  {achievement.name}
                </p>
                <Badge variant="secondary" className="mt-2">
                  +{achievement.rewardPoints} pts
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Growth Tips */}
      <Card className="border-blue-200 bg-blue-50 p-6">
        <div className="flex gap-3">
          <Zap className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-gray-900 mb-2">Quick Tips to Grow Faster</h4>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Daily check-ins earn bonus points</li>
              <li>• Leave product reviews to earn rewards</li>
              <li>• Refer friends and earn 5 Pi per signup</li>
              <li>• Maintain high ratings to unlock seller benefits</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  )
}
