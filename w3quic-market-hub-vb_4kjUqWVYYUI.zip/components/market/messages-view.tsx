"use client"

import { useMemo, useState, useEffect, useRef } from "react"
import { ChevronLeft, Send, MessageSquare, Check, X, RefreshCw } from "lucide-react"
import { cn } from "@/lib/utils"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { CURRENT_USER_ID } from "@/lib/market/seed"
import { formatPi, timeAgo } from "@/lib/market/helpers"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty"
import { toast } from "@/hooks/use-toast"

export function MessagesView({ conversationId }: { conversationId?: string }) {
  const market = useMarket()
  const { conversations, messages, getSeller, getProduct } = market
  const { go } = useNav()
  const [activeId, setActiveId] = useState<string | undefined>(conversationId)
  const [text, setText] = useState("")
  const [counter, setCounter] = useState("")
  const endRef = useRef<HTMLDivElement>(null)

  const myConvos = useMemo(
    () => conversations.filter((c) => c.buyerId === CURRENT_USER_ID || c.sellerId === CURRENT_USER_ID).sort((a, b) => b.lastMessageAt - a.lastMessageAt),
    [conversations],
  )
  const active = myConvos.find((c) => c.id === activeId)
  const thread = useMemo(() => messages.filter((m) => m.conversationId === activeId).sort((a, b) => a.at - b.at), [messages, activeId])

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }) }, [thread.length])

  const otherId = active ? (active.buyerId === CURRENT_USER_ID ? active.sellerId : active.buyerId) : ""
  const other = getSeller(otherId)
  const isSellerSide = active?.sellerId === CURRENT_USER_ID

  const send = () => {
    if (!text.trim() || !activeId) return
    market.sendMessage(activeId, text.trim())
    setText("")
  }

  if (!activeId || !active) {
    return (
      <div className="animate-fade-in px-4 py-4">
        <h1 className="mb-3 text-xl font-bold">Messages</h1>
        {myConvos.length === 0 ? (
          <Empty>
            <EmptyHeader><EmptyMedia variant="icon"><MessageSquare /></EmptyMedia><EmptyTitle>No conversations</EmptyTitle><EmptyDescription>Message a seller from any product page.</EmptyDescription></EmptyHeader>
          </Empty>
        ) : (
          <div className="space-y-2">
            {myConvos.map((c) => {
              const o = getSeller(c.buyerId === CURRENT_USER_ID ? c.sellerId : c.buyerId)
              const last = messages.filter((m) => m.conversationId === c.id).sort((a, b) => b.at - a.at)[0]
              const p = c.productId ? getProduct(c.productId) : undefined
              return (
                <button key={c.id} onClick={() => setActiveId(c.id)} className="flex w-full items-center gap-3 rounded-xl border border-border bg-card p-3 text-left">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 font-semibold text-primary">{(o?.displayName || "?")[0]}</span>
                  <span className="flex-1 overflow-hidden">
                    <span className="block text-sm font-medium">{o?.displayName || "User"}</span>
                    <span className="block truncate text-xs text-muted-foreground">{last?.text || (p ? `About: ${p.title}` : "Start chatting")}</span>
                  </span>
                  {last && <span className="text-[10px] text-muted-foreground">{timeAgo(last.at)}</span>}
                </button>
              )
            })}
          </div>
        )}
      </div>
    )
  }

  const product = active.productId ? getProduct(active.productId) : undefined

  return (
    <div className="flex h-[calc(100vh-7rem)] flex-col lg:h-[calc(100vh-3.5rem)]">
      <header className="flex items-center gap-2 border-b border-border p-3">
        <button onClick={() => setActiveId(undefined)} aria-label="Back"><ChevronLeft className="h-5 w-5" /></button>
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 font-semibold text-primary">{(other?.displayName || "?")[0]}</span>
        <div className="flex-1">
          <p className="text-sm font-semibold">{other?.displayName || "User"}</p>
          {product && <button onClick={() => go({ name: "product", id: product.id })} className="text-xs text-primary">{product.title}</button>}
        </div>
      </header>

      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        {thread.length === 0 && <p className="text-center text-xs text-muted-foreground">Say hello to start the conversation.</p>}
        {thread.map((m) => {
          const mine = m.senderId === CURRENT_USER_ID
          return (
            <div key={m.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
              <div className={cn("max-w-[80%] rounded-2xl px-3 py-2 text-sm", mine ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground")}>
                <p>{m.text}</p>
                {m.offer && (
                  <div className={cn("mt-2 rounded-lg p-2 text-xs", mine ? "bg-primary-foreground/15" : "bg-background")}>
                    <p className="font-semibold">Offer: {formatPi(m.offer.amount)} <span className="font-normal opacity-80">· {m.offer.status} · round {m.offer.round}</span></p>
                    {/* Seller can act on a pending buyer offer */}
                    {isSellerSide && !mine && m.offer.status === "pending" && (
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        <Button size="sm" variant="secondary" className="h-7 px-2" onClick={() => { market.respondOffer(m.id, "accept"); toast({ title: "Offer accepted" }) }}><Check className="mr-1 h-3 w-3" />Accept</Button>
                        <Button size="sm" variant="secondary" className="h-7 px-2" onClick={() => { market.respondOffer(m.id, "reject"); toast({ title: "Offer rejected" }) }}><X className="mr-1 h-3 w-3" />Reject</Button>
                        {m.offer.round < 3 && (
                          <span className="flex items-center gap-1">
                            <Input value={counter} onChange={(e) => setCounter(e.target.value)} placeholder="Counter" className="h-7 w-20 text-foreground" />
                            <Button size="sm" variant="secondary" className="h-7 px-2" onClick={() => { const a = Number.parseFloat(counter); if (a > 0) { market.respondOffer(m.id, "counter", a); setCounter(""); toast({ title: "Counter sent" }) } }}><RefreshCw className="h-3 w-3" /></Button>
                          </span>
                        )}
                      </div>
                    )}
                    {m.offer.status === "accepted" && <p className="mt-1 font-medium text-green-500">Deal agreed — proceed to checkout.</p>}
                  </div>
                )}
                <p className="mt-0.5 text-right text-[10px] opacity-60">{timeAgo(m.at)}</p>
              </div>
            </div>
          )
        })}
        <div ref={endRef} />
      </div>

      <div className="flex gap-2 border-t border-border p-3">
        <Input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Type a message..." aria-label="Message" />
        <Button size="icon" onClick={send} aria-label="Send"><Send className="h-4 w-4" /></Button>
      </div>
    </div>
  )
}
