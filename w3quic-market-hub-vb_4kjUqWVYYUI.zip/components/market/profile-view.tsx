'use client';
import { useState } from 'react';
import Image from 'next/image';
import { Edit, Gift, TrendingUp, ShoppingBag, Award } from 'lucide-react';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { CURRENT_USER_ID } from '@/lib/market/seed';
import { formatPi, timeAgo } from '@/lib/market/helpers';
import { RatingStars, VerifiedBadge, Pill } from './ui-bits';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { PremiumSellerButton } from './premium-seller-button';
import { PremiumSellerSubscriptionButton } from './premium-seller-subscription-button';
import { PremiumJobListingsButton } from './premium-job-listings-button';
import { RealEstateButton } from './real-estate-button';
import { VehicleMarketplaceButton } from './vehicle-marketplace-button';
import { ServicesMarketplaceButton } from './services-marketplace-button';

export function ProfileView() {
  const market = useMarket();
  const { me, updateProfile, orders, reviews, wishlist } = market;
  const { go } = useNav();
  const [editName, setEditName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [open, setOpen] = useState(false);

  const buyerOrders = orders.filter((o) => o.buyerId === CURRENT_USER_ID);
  const sellerOrders = orders.filter((o) => o.sellerId === CURRENT_USER_ID);
  const buyerCompleted = buyerOrders.filter((o) => o.status === 'completed').length;
  const sellerReviews = reviews.filter((r) => r.sellerId === CURRENT_USER_ID);
  const achievements = [
    buyerOrders.length >= 1 && 'First Purchase',
    sellerReviews.length >= 1 && 'First Review',
    buyerCompleted >= 10 && '10 Orders',
    buyerCompleted >= 50 && '50 Orders',
    wishlist.length >= 100 && 'Wishlist 100 Items',
    me.isSeller && sellerOrders.length >= 100 && '100 Sales',
    me.isSeller && sellerOrders.length >= 500 && '500 Sales',
    me.verification === 'verified' && 'Verified',
  ].filter(Boolean) as string[];

  const handleEditProfile = () => {
    updateProfile({ displayName: editName || me.displayName, bio: editBio || me.bio });
    toast({ title: 'Profile updated' });
    setOpen(false);
  };

  return (
    <div className="animate-fade-in px-4 py-4">
      {/* Header card */}
      <div className="rounded-xl border border-border bg-gradient-to-br from-primary/10 to-accent/10 p-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold">{me.displayName}</h1>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
              <span className="inline-block h-2 w-2 rounded-full bg-green-500" /> Joined {timeAgo(me.joinedAt)}
            </p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={() => { setEditName(me.displayName); setEditBio(me.bio); }}>
                <Edit className="mr-1 h-4 w-4" /> Edit
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit profile</DialogTitle>
              </DialogHeader>
              <div className="grid gap-3">
                <div>
                  <Label>Display name</Label>
                  <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
                </div>
                <div>
                  <Label>Bio</Label>
                  <Input value={editBio} onChange={(e) => setEditBio(e.target.value)} placeholder="Tell us about yourself..." />
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button onClick={handleEditProfile}>Save</Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Bio */}
        {me.bio && <p className="mt-3 text-sm text-muted-foreground">{me.bio}</p>}

        {/* Stats */}
        <div className="mt-4 grid grid-cols-3 gap-2">
          <StatBox label="Rating" value={me.rating.toFixed(1)} icon="⭐" />
          <StatBox label="Rep Score" value={me.reputationScore.toString()} icon="🏆" />
          <StatBox label="Loyalty Points" value={me.loyaltyPoints.toString()} icon="💎" />
        </div>

        {/* Verification badge */}
        <div className="mt-3 flex items-center gap-1.5">
          <span className="text-xs font-medium text-muted-foreground">Verification:</span>
          <VerifiedBadge level={me.verification} />
        </div>
      </div>

      {/* Orders summary */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        <SummaryCard
          icon={<ShoppingBag className="h-5 w-5" />}
          label="Purchases"
          value={buyerOrders.length}
          onClick={() => go({ name: 'orders' })}
        />
        {me.isSeller && (
          <SummaryCard
            icon={<TrendingUp className="h-5 w-5" />}
            label="Sales"
            value={sellerOrders.length}
            onClick={() => go({ name: 'orders' })}
          />
        )}
        <SummaryCard
          icon={<Award className="h-5 w-5" />}
          label="Reviews"
          value={sellerReviews.length}
        />
        <SummaryCard
          icon={<Gift className="h-5 w-5" />}
          label="Achievements"
          value={achievements.length}
        />
      </div>

      {/* Achievements */}
      {achievements.length > 0 && (
        <section className="mt-4">
          <h2 className="mb-2 text-sm font-bold">Achievements</h2>
          <div className="flex flex-wrap gap-2">
            {achievements.map((a) => (
              <Pill key={a} className="bg-primary/10 text-primary">
                <Award className="h-3 w-3" /> {a}
              </Pill>
            ))}
          </div>
        </section>
      )}

      {/* Premium seller upgrade section for sellers */}
      {me.isSeller && !me.isPremium && (
        <section className="mt-4">
          <div className="rounded-xl border border-amber-200 bg-gradient-to-br from-amber-50 to-amber-100 p-4">
            <h2 className="mb-2 font-semibold text-amber-900">Upgrade to Premium Seller</h2>
            <p className="text-sm text-amber-800 mb-3">
              Unlock verified seller status, priority listings, advanced analytics, and more.
            </p>
            <PremiumSellerButton variant="default" />
          </div>
        </section>
      )}

      {/* Premium Seller Subscription Section */}
      {me.isSeller && !me.isPremium && (
        <section className="mt-4">
          <div className="rounded-xl border border-purple-300 bg-gradient-to-br from-purple-50 to-purple-100 p-4">
            <h2 className="mb-2 font-semibold text-purple-900">Premium Seller Subscription (0.5 π)</h2>
            <p className="text-sm text-purple-800 mb-3">
              Get verified seller badge, featured listings, advanced analytics, promotional tools, and increased buyer trust.
            </p>
            <PremiumSellerSubscriptionButton variant="default" showFeatures={false} fullWidth={true} />
          </div>
        </section>
      )}

      {/* Premium Job Listings Section */}
      <section className="mt-4">
        <div className="rounded-xl border border-cyan-300 bg-gradient-to-br from-cyan-50 to-cyan-100 p-4">
          <h2 className="mb-2 font-semibold text-cyan-900">Premium Job Listings (0.5 π)</h2>
          <p className="text-sm text-cyan-800 mb-3">
            Post featured job opportunities, access verified employers, promote vacancies, receive priority visibility, and connect with trusted job seekers.
          </p>
          <PremiumJobListingsButton variant="default" />
        </div>
      </section>

      {/* Real Estate Hub Section */}
      <section className="mt-4">
        <div className="rounded-xl border border-blue-300 bg-gradient-to-br from-blue-50 to-blue-100 p-4">
          <h2 className="mb-2 font-semibold text-blue-900">Real Estate Hub (0.5 π)</h2>
          <p className="text-sm text-blue-800 mb-3">
            Buy, sell & rent properties including houses, apartments, land, and commercial spaces.
          </p>
          <RealEstateButton variant="default" fullWidth={true} />
        </div>
      </section>

      {/* Vehicle Marketplace Section */}
      <section className="mt-4">
        <div className="rounded-xl border border-amber-300 bg-gradient-to-br from-amber-50 to-amber-100 p-4">
          <h2 className="mb-2 font-semibold text-amber-900">Vehicle Marketplace (0.5 π)</h2>
          <p className="text-sm text-amber-800 mb-3">
            Buy, sell & trade vehicles including cars, trucks, motorcycles, and heavy equipment.
          </p>
          <VehicleMarketplaceButton variant="default" fullWidth={true} />
        </div>
      </section>

      {/* Services Marketplace Section */}
      <section className="mt-4">
        <div className="rounded-xl border border-purple-300 bg-gradient-to-br from-purple-50 to-purple-100 p-4">
          <h2 className="mb-2 font-semibold text-purple-900">Services Marketplace (0.5 π)</h2>
          <p className="text-sm text-purple-800 mb-3">
            Find and offer professional services including developers, designers, electricians, plumbers, lawyers, doctors, consultants, and freelancers.
          </p>
          <ServicesMarketplaceButton variant="default" fullWidth={true} />
        </div>
      </section>

      {/* Quick actions */}
      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button variant="outline" onClick={() => go({ name: 'wishlist' })}>
          Wishlist
        </Button>
        {me.isSeller && (
          <Button variant="outline" onClick={() => go({ name: 'loyalty' })}>
            Loyalty Dashboard
          </Button>
        )}
        <Button variant="outline" onClick={() => go({ name: 'messages' })}>
          Messages
        </Button>
        {me.isSeller && (
          <Button variant="outline" onClick={() => go({ name: 'subscription' })}>
            Subscriptions
          </Button>
        )}
        <Button variant="outline" onClick={() => go({ name: 'settings' })}>
          Settings
        </Button>
      </div>
    </div>
  );
}

function StatBox({ label, value, icon }: { label: string; value: string; icon: string }) {
  return (
    <div className="rounded-lg bg-background p-2 text-center">
      <p className="text-xl">{icon}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-bold">{value}</p>
    </div>
  );
}

function SummaryCard({ icon, label, value, onClick }: { icon: React.ReactNode; label: string; value: number; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 rounded-lg border border-border bg-card p-3 text-left transition-colors hover:bg-accent"
    >
      <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">{icon}</span>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-bold">{value}</p>
      </div>
    </button>
  );
}
