'use client';

import { useState, useMemo } from 'react';
import { ArrowLeft, Home, Search, Filter, MapPin, DollarSign, Bed, Bath } from 'lucide-react';
import { useNav } from '@/lib/market/nav';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty';
import { EscrowPaymentButton } from './escrow-payment-button';

interface Property {
  id: string;
  title: string;
  type: 'house' | 'apartment' | 'land' | 'commercial';
  price: number;
  location: string;
  bedrooms?: number;
  bathrooms?: number;
  sqft: number;
  image: string;
  featured: boolean;
}

// Sample properties data
const SAMPLE_PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'Modern Apartment in Downtown',
    type: 'apartment',
    price: 5.5,
    location: 'Downtown District',
    bedrooms: 2,
    bathrooms: 2,
    sqft: 1200,
    image: '/placeholder.svg?height=200&width=300',
    featured: true,
  },
  {
    id: '2',
    title: 'Spacious Family House',
    type: 'house',
    price: 12.0,
    location: 'Suburban Area',
    bedrooms: 4,
    bathrooms: 3,
    sqft: 3500,
    image: '/placeholder.svg?height=200&width=300',
    featured: true,
  },
  {
    id: '3',
    title: 'Commercial Office Space',
    type: 'commercial',
    price: 8.0,
    location: 'Business District',
    sqft: 2000,
    image: '/placeholder.svg?height=200&width=300',
    featured: false,
  },
  {
    id: '4',
    title: 'Residential Land Plot',
    type: 'land',
    price: 4.0,
    location: 'Urban Development Zone',
    sqft: 5000,
    image: '/placeholder.svg?height=200&width=300',
    featured: false,
  },
];

export function RealEstateView() {
  const { back } = useNav();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<Property['type'] | 'all'>('all');

  const filteredProperties = useMemo(() => {
    return SAMPLE_PROPERTIES.filter((p) => {
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            p.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === 'all' || p.type === selectedType;
      return matchesSearch && matchesType;
    });
  }, [searchQuery, selectedType]);

  const typeOptions: Array<{ value: Property['type'] | 'all'; label: string }> = [
    { value: 'all', label: 'All' },
    { value: 'house', label: 'House' },
    { value: 'apartment', label: 'Apartment' },
    { value: 'land', label: 'Land' },
    { value: 'commercial', label: 'Commercial' },
  ];

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="sticky top-0 z-20 border-b border-border bg-background/95 backdrop-blur px-4 py-3">
        <button
          onClick={back}
          className="mb-3 flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="flex items-center gap-2">
          <Home className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-bold">Real Estate Hub</h1>
        </div>
      </div>

      <div className="px-4 py-4 pb-24">
        {/* Search */}
        <div className="mb-4 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search properties..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button variant="outline" size="sm" className="px-2">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        {/* Type filters */}
        <div className="mb-4 flex gap-2 overflow-x-auto pb-2">
          {typeOptions.map((type) => (
            <button
              key={type.value}
              onClick={() => setSelectedType(type.value)}
              className={`whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                selectedType === type.value
                  ? 'bg-primary text-primary-foreground'
                  : 'border border-border bg-card text-card-foreground hover:bg-accent'
              }`}
            >
              {type.label}
            </button>
          ))}
        </div>

        {/* Properties grid */}
        {filteredProperties.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Home />
              </EmptyMedia>
              <EmptyTitle>No properties found</EmptyTitle>
              <EmptyDescription>Try adjusting your search filters.</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="grid gap-3">
            {filteredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        )}

        {/* Escrow Protection */}
        {filteredProperties.length > 0 && (
          <div className="mt-6 fixed inset-x-0 bottom-20 z-30 mx-auto max-w-2xl px-4">
            <EscrowPaymentButton fullWidth variant="default" />
          </div>
        )}
      </div>
    </div>
  );
}

function PropertyCard({ property }: { property: Property }) {
  return (
    <div className="overflow-hidden rounded-lg border border-border bg-card transition-all hover:shadow-lg">
      <div className="flex gap-4">
        {/* Image */}
        <div className="relative h-32 w-32 shrink-0 overflow-hidden bg-muted">
          <img
            src={property.image}
            alt={property.title}
            className="h-full w-full object-cover"
          />
          {property.featured && (
            <div className="absolute top-2 right-2 rounded bg-primary px-2 py-1 text-xs font-semibold text-primary-foreground">
              Featured
            </div>
          )}
        </div>

        {/* Details */}
        <div className="flex-1 py-3 pr-3">
          <h3 className="line-clamp-2 font-semibold text-card-foreground">{property.title}</h3>
          <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" /> {property.location}
          </p>

          {/* Property specs */}
          <div className="mt-2 flex gap-3 text-xs text-muted-foreground">
            {property.bedrooms && (
              <span className="flex items-center gap-1">
                <Bed className="h-3 w-3" /> {property.bedrooms} bed
              </span>
            )}
            {property.bathrooms && (
              <span className="flex items-center gap-1">
                <Bath className="h-3 w-3" /> {property.bathrooms} bath
              </span>
            )}
            <span className="flex items-center gap-1">
              {property.sqft.toLocaleString()} sqft
            </span>
          </div>

          {/* Price */}
          <div className="mt-3 flex items-center justify-between">
            <span className="font-bold text-primary">
              <DollarSign className="mr-1 inline h-4 w-4" />
              {property.price} π
            </span>
            <Button size="sm" variant="default">
              View Details
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
