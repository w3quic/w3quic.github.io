"use client"

import { useMemo } from "react"
import Image from "next/image"
import { Trash2, ShoppingCart, Minus, Plus } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { effectivePrice, formatPi } from "@/lib/market/helpers"
import { Button } from "@/components/ui/button"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty"

export function CartView() {
  const { cart, getProduct, updateCartQty, removeFromCart } = useMarket()
  const { go } = useNav()

  const lines = useMemo(() => cart.map((c) => {
    const p = getProduct(c.productId)
    if (!p) return null
    const v = p.variations.find((x) => x.id === c.variationId)
    const price = v ? v.price : effectivePrice(p)
    return { c, p, v, price, total: price * c.quantity }
  }).filter(Boolean) as { c: typeof cart[number]; p: NonNullable<ReturnType<typeof getProduct>>; v: any; price: number; total: number }[], [cart, getProduct])

  const subtotal = lines.reduce((s, l) => s + l.total, 0)

  if (lines.length === 0) {
    return (
      <div className="px-4 py-6">
        <h1 className="mb-4 text-xl font-bold">Cart</h1>
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><ShoppingCart /></EmptyMedia>
            <EmptyTitle>Your cart is empty</EmptyTitle>
            <EmptyDescription>Browse the marketplace and add items you love.</EmptyDescription>
          </EmptyHeader>
          <Button onClick={() => go({ name: "browse" })}>Start shopping</Button>
        </Empty>
      </div>
    )
  }

  return (
    <div className="animate-fade-in px-4 py-4 pb-28">
      <h1 className="mb-4 text-xl font-bold">Cart ({lines.length})</h1>
      <div className="space-y-3">
        {lines.map(({ c, p, v, price, total }) => (
          <div key={`${c.productId}-${c.variationId}`} className="flex gap-3 rounded-xl border border-border bg-card p-3">
            <button onClick={() => go({ name: "product", id: p.id })} className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-muted">
              <Image src={p.images[0] || "/placeholder.svg"} alt={p.title} fill sizes="80px" className="object-cover" />
            </button>
            <div className="flex flex-1 flex-col">
              <p className="line-clamp-2 text-sm font-medium">{p.title}</p>
              {v && <p className="text-xs text-muted-foreground">{v.name}</p>}
              <p className="text-sm font-bold text-primary">{formatPi(price)}</p>
              <div className="mt-auto flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button onClick={() => updateCartQty(c.productId, c.variationId, c.quantity - 1)} className="flex h-7 w-7 items-center justify-center rounded-md border border-border" aria-label="Decrease"><Minus className="h-3.5 w-3.5" /></button>
                  <span className="w-6 text-center text-sm font-medium">{c.quantity}</span>
                  <button onClick={() => updateCartQty(c.productId, c.variationId, c.quantity + 1)} className="flex h-7 w-7 items-center justify-center rounded-md border border-border" aria-label="Increase"><Plus className="h-3.5 w-3.5" /></button>
                </div>
                <button onClick={() => removeFromCart(c.productId, c.variationId)} className="text-muted-foreground hover:text-destructive" aria-label="Remove"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="fixed inset-x-0 bottom-16 z-30 mx-auto max-w-2xl border-t border-border bg-background/95 p-4 backdrop-blur lg:bottom-0">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Subtotal</span>
          <span className="text-lg font-bold text-primary">{formatPi(subtotal)}</span>
        </div>
        <Button className="w-full" size="lg" onClick={() => go({ name: "checkout" })}>Proceed to checkout</Button>
      </div>
    </div>
  )
}
