'use client'

import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { TrendingUp, Users, ShoppingCart, Eye, Target, AlertCircle } from 'lucide-react'
import { useMarket } from '@/lib/market/store'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function MarketplaceIntelligence() {
  const market = useMarket()
  const insights = market.getMarketplaceInsights()
  const trendingCategories = market.getTrendingCategories()

  const statCards = [
    {
      title: 'Total Browsing',
      value: insights.buyer.conversionFunnel.browsed,
      icon: Eye,
      color: 'text-blue-600',
    },
    {
      title: 'Avg Order Value',
      value: `π${Math.round(insights.buyer.avgOrderValue)}`,
      icon: ShoppingCart,
      color: 'text-green-600',
    },
    {
      title: 'Conversion Rate',
      value:
        insights.buyer.conversionFunnel.browsed > 0
          ? `${Math.round((insights.buyer.conversionFunnel.purchased / insights.buyer.conversionFunnel.browsed) * 100)}%`
          : '0%',
      icon: Target,
      color: 'text-purple-600',
    },
    {
      title: 'Total Sales',
      value: insights.seller.totalSales,
      icon: TrendingUp,
      color: 'text-orange-600',
    },
  ]

  const conversionData = [
    { name: 'Browsed', value: insights.buyer.conversionFunnel.browsed },
    { name: 'Viewed', value: insights.buyer.conversionFunnel.viewed },
    { name: 'Added to Cart', value: insights.buyer.conversionFunnel.added },
    { name: 'Purchased', value: insights.buyer.conversionFunnel.purchased },
  ]

  const categoryChartData = trendingCategories.slice(0, 5).map((cat: any) => ({
    name: cat.categoryId.charAt(0).toUpperCase() + cat.categoryId.slice(1),
    score: Math.round(cat.trendScore),
    growth: Math.round(cat.growthRate),
  }))

  const COLORS = ['#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444']

  return (
    <div className="space-y-6 p-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Conversion Funnel */}
        <Card>
          <CardHeader>
            <CardTitle>Buyer Conversion Funnel</CardTitle>
            <CardDescription>Path from browse to purchase</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={conversionData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Trending Categories */}
        <Card>
          <CardHeader>
            <CardTitle>Trending Categories</CardTitle>
            <CardDescription>Top performing product categories</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoryChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="score" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Search Queries */}
        <Card>
          <CardHeader>
            <CardTitle>Top Search Queries</CardTitle>
            <CardDescription>Most searched terms</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {insights.buyer.topSearchQueries.slice(0, 5).map((q: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center p-2 rounded bg-secondary/50">
                  <span className="text-sm font-medium">{q.query || 'N/A'}</span>
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded">{q.count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Product Categories */}
        <Card>
          <CardHeader>
            <CardTitle>Top Categories</CardTitle>
            <CardDescription>By buyer interest</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {insights.buyer.topCategories.slice(0, 5).map((cat: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center p-2 rounded bg-secondary/50">
                  <span className="text-sm font-medium capitalize">{cat.category}</span>
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded">{cat.count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Seller Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Your Seller Performance</CardTitle>
            <CardDescription>Key metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between p-2 rounded bg-secondary/50">
                <span className="text-sm">Response Time</span>
                <span className="text-sm font-medium">{insights.seller.responseTime}m</span>
              </div>
              <div className="flex justify-between p-2 rounded bg-secondary/50">
                <span className="text-sm">Avg Rating</span>
                <span className="text-sm font-medium">{insights.seller.avgReviewScore}⭐</span>
              </div>
              <div className="flex justify-between p-2 rounded bg-secondary/50">
                <span className="text-sm">Refund Rate</span>
                <span className="text-sm font-medium">{Math.round(insights.seller.refundRate * 100)}%</span>
              </div>
              <div className="flex justify-between p-2 rounded bg-secondary/50">
                <span className="text-sm">Repeat Customers</span>
                <span className="text-sm font-medium">{Math.round(insights.seller.repeatCustomerRate * 100)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Market Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            Market Insights
          </CardTitle>
          <CardDescription>Data-driven recommendations for sellers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800">
              <div className="font-medium text-sm text-green-900 dark:text-green-100 mb-1">
                Opportunity: Price-competitive products
              </div>
              <div className="text-xs text-green-800 dark:text-green-200">
                Products with flash deals are getting 40% more engagement. Consider adding competitive pricing.
              </div>
            </div>

            <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">
              <div className="font-medium text-sm text-blue-900 dark:text-blue-100 mb-1">
                Trending: Electronics & Fashion
              </div>
              <div className="text-xs text-blue-800 dark:text-blue-200">
                These categories account for 65% of marketplace activity. Strong demand expected to continue.
              </div>
            </div>

            <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800">
              <div className="font-medium text-sm text-purple-900 dark:text-purple-100 mb-1">
                Tip: Feature seasonal items
              </div>
              <div className="text-xs text-purple-800 dark:text-purple-200">
                Seasonal collections increase conversion by 25%. Update your store with current season items.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
