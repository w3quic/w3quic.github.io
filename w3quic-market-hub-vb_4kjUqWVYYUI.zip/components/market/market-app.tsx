"use client"

import { useState } from "react"
import { NavProvider, useNav } from "@/lib/market/nav"
import { MarketStoreProvider } from "@/lib/market/store"
import { TopBar } from "./top-bar"
import { BottomNav, SideNav } from "./navigation"
import { AiAssistant } from "./ai-assistant"
import { DailyReward } from "./daily-reward"
import { HomeView } from "./home-view"
import { BrowseView } from "./browse-view"
import { ProductView } from "./product-view"
import { CartView } from "./cart-view"
import { WishlistView } from "./wishlist-view"
import { CheckoutView } from "./checkout-view"
import { OrdersView } from "./orders-view"
import { OrderDetailView } from "./order-detail-view"
import { MessagesView } from "./messages-view"
import { NotificationsView } from "./notifications-view"
import { ProfileView } from "./profile-view"
import { SettingsView } from "./settings-view"
import { SubscriptionManagementView } from "./subscription-management-view"
import { StoreView } from "./store-view"
import { SellerView } from "./seller-view"
import { CreateListingView } from "./create-listing-view"
import { LoyaltyView } from "./loyalty-view"
import { AdminView } from "./admin-view"
import { ListView } from "./list-view"
import { RealEstateView } from "./real-estate-view"
import { VehicleMarketplaceView } from "./vehicle-marketplace-view"
import { ServicesMarketplaceView } from "./services-marketplace-view"

function Router({ onOpenAssistant }: { onOpenAssistant: () => void }) {
  const { view } = useNav()
  switch (view.name) {
    case "home": return <HomeView onOpenAssistant={onOpenAssistant} />
    case "browse": return <BrowseView category={view.category} query={view.query} filter={view.filter} />
    case "product": return <ProductView id={view.id} onOpenAssistant={onOpenAssistant} />
    case "cart": return <CartView />
    case "wishlist": return <WishlistView />
    case "checkout": return <CheckoutView />
    case "orders": return <OrdersView />
    case "order": return <OrderDetailView id={view.id} />
    case "messages": return <MessagesView conversationId={view.conversationId} />
    case "notifications": return <NotificationsView />
    case "profile": return <ProfileView />
    case "settings": return <SettingsView />
    case "subscription": return <SubscriptionManagementView />
    case "store": return <StoreView sellerId={view.sellerId} />
    case "seller": return <SellerView />
    case "create-listing": return <CreateListingView editId={view.editId} />
    case "loyalty": return <LoyaltyView />
    case "admin": return <AdminView />
    case "auctions": return <ListView mode="auctions" />
    case "flash": return <ListView mode="flash" />
    case "real-estate": return <RealEstateView />
    case "vehicle-marketplace": return <VehicleMarketplaceView />
    case "services": return <ServicesMarketplaceView />
    default: return <HomeView onOpenAssistant={onOpenAssistant} />
  }
}

function Shell() {
  const [assistant, setAssistant] = useState(false)
  return (
    <div className="mx-auto min-h-screen max-w-2xl bg-background lg:max-w-5xl">
      <TopBar onOpenAssistant={() => setAssistant(true)} />
      <div className="flex">
        <SideNav />
        <main className="min-h-[calc(100vh-3.5rem)] flex-1 pb-20 lg:pb-6">
          <Router onOpenAssistant={() => setAssistant(true)} />
        </main>
      </div>
      <BottomNav />
      <AiAssistant open={assistant} onClose={() => setAssistant(false)} />
      <DailyReward />
    </div>
  )
}

export function MarketApp() {
  return (
    <MarketStoreProvider>
      <NavProvider>
        <Shell />
      </NavProvider>
    </MarketStoreProvider>
  )
}
