'use client'

import { Sparkles, TrendingUp, Tag, Clock, RotateCcw, Eye } from 'lucide-react'
import { useMarket } from '@/lib/market/store'
import { ProductCard } from './product-card'
import type { Product } from '@/lib/market/types'

interface RecommendationsSectionProps {
  title: string
  type:
    | 'trending'
    | 'recommendations'
    | 'similar'
    | 'better-value'
    | 'price-dropped'
    | 'restocked'
    | 'verified-sellers'
  productId?: string
  onProductSelect?: (product: Product) => void
}

export function RecommendationsSection({
  title,
  type,
  productId,
  onProductSelect,
}: RecommendationsSectionProps) {
  const market = useMarket()

  const getProducts = (): Product[] => {
    switch (type) {
      case 'trending':
        return market.getTrendingProducts()
      case 'recommendations':
        return market.getProductRecommendations()
      case 'similar':
        return productId ? market.getSimilarProducts(productId) : []
      case 'better-value':
        return productId ? market.getBetterValueSuggestions(productId) : []
      case 'price-dropped':
        return market.getRecentlyPriceDropped()
      case 'restocked':
        return market.getRecentlyRestocked()
      default:
        return []
    }
  }

  const getIcon = () => {
    switch (type) {
      case 'trending':
        return <TrendingUp className="w-5 h-5" />
      case 'recommendations':
        return <Sparkles className="w-5 h-5" />
      case 'price-dropped':
        return <Tag className="w-5 h-5" />
      case 'restocked':
        return <RotateCcw className="w-5 h-5" />
      case 'better-value':
        return <Eye className="w-5 h-5" />
      default:
        return <Clock className="w-5 h-5" />
    }
  }

  const products = getProducts()

  if (products.length === 0) {
    return null
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="text-primary">{getIcon()}</div>
        <h3 className="font-semibold text-lg">{title}</h3>
        {type === 'better-value' && (
          <span className="ml-auto px-2 py-1 text-xs rounded-full bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-100">
            Save money
          </span>
        )}
        {type === 'price-dropped' && (
          <span className="ml-auto px-2 py-1 text-xs rounded-full bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-100">
            Limited time
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {products.slice(0, 8).map((product) => (
          <div
            key={product.id}
            onClick={() => onProductSelect?.(product)}
            className="cursor-pointer transition-transform hover:scale-105"
          >
            <ProductCard product={product} hideActions={true} compact={true} />
          </div>
        ))}
      </div>
    </div>
  )
}
