import type { Product, Category, UserProfile, Order } from "./types"

/**
 * Market Intelligence Infrastructure
 * Modular adapters for recommendations, trending, analytics, and discovery features
 * All implementations are client-side ready; swap with real backends without UI changes
 */

// ============ TYPES ============

export interface SearchContext {
  query: string
  category?: Category
  maxPrice?: number
  minPrice?: number
  condition?: string
  location?: string
  sortBy?: "relevance" | "price-asc" | "price-desc" | "newest" | "popular" | "rating"
}

export interface RecommendationContext {
  userId: string
  recentViews: string[]
  wishlist: string[]
  purchaseHistory: string[]
  browseCategoryFreq: Record<Category, number>
  viewDurationByProduct: Record<string, number>
  priceRangePreference: { min: number; max: number }
}

export interface ProductAnalytics {
  productId: string
  totalViews: number
  conversionRate: number
  avgTimeOnPage: number
  addToCartRate: number
  wishlistRate: number
  returnRate: number
  trendingScore: number
  seasonalDemand: number
}

export interface MarketTrend {
  categoryId: Category
  trendScore: number
  growthRate: number
  searchFrequency: number
  avgPriceChange: number
  seasonality: "peak" | "normal" | "low"
}

export interface BuyerInsight {
  topSearchQueries: { query: string; count: number }[]
  topCategories: { category: Category; count: number }[]
  priceRangeMost: { min: number; max: number; count: number }
  avgOrderValue: number
  conversionFunnel: {
    browsed: number
    viewed: number
    added: number
    purchased: number
  }
}

export interface SellerInsight {
  topProducts: { productId: string; sales: number }[]
  avgReviewScore: number
  totalSales: number
  responseTime: number
  refundRate: number
  repeatCustomerRate: number
}

export interface SearchSuggestion {
  text: string
  category?: Category
  score: number
  type: "query" | "product" | "seller" | "category"
}

export interface ComparisonRow {
  attribute: string
  products: (string | number | boolean | null)[]
}

// ============ RECOMMENDATION ENGINE ============

export function getProductRecommendations(
  context: RecommendationContext,
  products: Product[],
  limit: number = 10,
): Product[] {
  const scored = products
    .filter((p) => !context.purchaseHistory.includes(p.id))
    .map((p) => {
      let score = 0

      // Category affinity
      const catScore = context.browseCategoryFreq[p.category] || 0
      score += catScore * 15

      // Price preference match
      if (p.price >= context.priceRangePreference.min && p.price <= context.priceRangePreference.max) {
        score += 20
      }

      // Recent view similarity
      const viewedInCategory = context.recentViews
        .map((id) => products.find((pr) => pr.id === id))
        .filter((pr) => pr?.category === p.category).length
      score += viewedInCategory * 8

      // Popularity + quality
      score += (p.views * 0.1 + p.featured ? 5 : 0)

      // Engagement potential
      score += p.stock > 0 ? 3 : 0

      return { product: p, score }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.product)

  return scored
}

export function getSimilarProducts(
  productId: string,
  products: Product[],
  limit: number = 8,
): Product[] {
  const ref = products.find((p) => p.id === productId)
  if (!ref) return []

  const similar = products
    .filter((p) => p.id !== productId && p.category === ref.category)
    .map((p) => {
      let score = 0

      // Same subcategory
      if (p.subcategory === ref.subcategory) score += 25
      else if (p.category === ref.category) score += 10

      // Price proximity (within 30%)
      const priceDiff = Math.abs(p.price - ref.price) / ref.price
      if (priceDiff < 0.3) score += 15
      if (priceDiff < 0.15) score += 10

      // Condition match
      if (p.condition === ref.condition) score += 8

      // Availability
      score += p.stock > 0 ? 5 : 0

      // Seller quality
      return { product: p, score }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.product)

  return similar
}

export function getBetterValueSuggestions(
  productId: string,
  products: Product[],
  limit: number = 5,
): Product[] {
  const ref = products.find((p) => p.id === productId)
  if (!ref) return []

  const better = products
    .filter(
      (p) =>
        p.id !== productId &&
        p.category === ref.category &&
        p.stock > 0 &&
        p.price < ref.price &&
        Math.abs(p.price - ref.price) / ref.price < 0.4, // Similar price range
    )
    .map((p) => {
      let value = 0

      // Price savings
      const savings = ref.price - p.price
      value += savings * 2

      // Similar quality (condition)
      if (p.condition === ref.condition) value += 15
      if (p.condition === "new" && ref.condition !== "new") value += 20

      // Rating/views (popularity indicator)
      value += p.views * 0.05

      // Stock availability
      value += p.stock > 5 ? 10 : 0

      return { product: p, value }
    })
    .sort((a, b) => b.value - a.value)
    .slice(0, limit)
    .map((s) => s.product)

  return better
}

// ============ TRENDING & DISCOVERY ============

export function getTrendingProducts(products: Product[], limit: number = 12): Product[] {
  const now = Date.now()
  const day = 86400000

  return products
    .map((p) => {
      let score = 0

      // Recent activity (views in last 24h)
      const ageHours = (now - p.updatedAt) / 3600000
      if (ageHours < 24) score += 30
      else if (ageHours < 72) score += 15

      // View velocity
      score += Math.min(p.views / 10, 25)

      // Featured / sponsored boost
      score += p.featured ? 10 : 0
      score += p.sponsored ? 5 : 0

      // Flash deal boost
      if (p.flashDeal && p.flashDeal.endsAt > now) score += 20

      // Stock status
      if (p.stock < 5 && p.stock > 0) score += 5 // Scarcity

      return { product: p, score }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((s) => s.product)
}

export function getTrendingCategories(products: Product[], limit: number = 5): MarketTrend[] {
  const now = Date.now()
  const categoryStats = new Map<Category, { views: number; sales: number; priceChanges: number; products: Product[] }>()

  for (const p of products) {
    if (!categoryStats.has(p.category)) {
      categoryStats.set(p.category, { views: 0, sales: 0, priceChanges: 0, products: [] })
    }
    const stat = categoryStats.get(p.category)!
    stat.views += p.views
    stat.products.push(p)
    if (p.flashDeal) stat.priceChanges++
    if (p.featured || p.sponsored) stat.sales++
  }

  const trends = Array.from(categoryStats.entries())
    .map(([catId, stat]) => {
      const recentProducts = stat.products.filter((p) => now - p.updatedAt < 7 * 86400000)
      const trendScore = stat.views * 0.3 + stat.sales * 10 + recentProducts.length * 2

      return {
        categoryId: catId,
        trendScore,
        growthRate: trendScore / (stat.products.length + 1),
        searchFrequency: stat.views,
        avgPriceChange: stat.priceChanges,
        seasonality: "normal" as const,
      }
    })
    .sort((a, b) => b.trendScore - a.trendScore)
    .slice(0, limit)

  return trends
}

export function getRecentlyPriceDropped(products: Product[], limit: number = 8): Product[] {
  // In real scenario, track historical prices; here we simulate with flashDeal products
  return products
    .filter((p) => p.flashDeal && p.flashDeal.endsAt > Date.now())
    .sort((a, b) => {
      const discA = a.flashDeal?.discountPercent || 0
      const discB = b.flashDeal?.discountPercent || 0
      return discB - discA
    })
    .slice(0, limit)
}

export function getRecentlyRestocked(products: Product[], limit: number = 8): Product[] {
  const now = Date.now()
  const day = 86400000

  return products
    .filter((p) => now - p.updatedAt < 3 * day && p.stock > 0)
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, limit)
}

// ============ SMART SEARCH ============

export function generateSearchSuggestions(
  query: string,
  products: Product[],
  recentSearches: string[] = [],
  limit: number = 8,
): SearchSuggestion[] {
  if (!query) return []

  const q = query.toLowerCase().trim()
  const suggestions: SearchSuggestion[] = []

  // Recent searches matching
  for (const search of recentSearches.slice(0, 3)) {
    if (search.toLowerCase().includes(q)) {
      suggestions.push({ text: search, score: 40, type: "query" })
    }
  }

  // Product title matches
  for (const p of products) {
    const title = p.title.toLowerCase()
    if (title.includes(q)) {
      const score = title.startsWith(q) ? 60 : 30
      suggestions.push({
        text: p.title,
        score,
        type: "product",
        category: p.category,
      })
    }
  }

  // Category matches
  const categoryMap: Record<string, Category> = {
    electronic: "electronics",
    phone: "electronics",
    laptop: "electronics",
    fashion: "fashion",
    clothes: "fashion",
    home: "home",
    vehicle: "vehicles",
    bike: "vehicles",
  }

  for (const [key, cat] of Object.entries(categoryMap)) {
    if (key.includes(q) || q.includes(key)) {
      suggestions.push({
        text: cat.charAt(0).toUpperCase() + cat.slice(1),
        score: 35,
        type: "category",
        category: cat,
      })
    }
  }

  // Dedup and sort
  const deduped = Array.from(
    new Map(suggestions.map((s) => [s.text.toLowerCase(), s])).values(),
  )

  return deduped
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
}

export function performSmartSearch(
  context: SearchContext,
  products: Product[],
): Product[] {
  let results = [...products]

  // Category filter
  if (context.category) {
    results = results.filter((p) => p.category === context.category)
  }

  // Price filter
  if (context.minPrice !== undefined) {
    results = results.filter((p) => p.price >= context.minPrice!)
  }
  if (context.maxPrice !== undefined) {
    results = results.filter((p) => p.price <= context.maxPrice!)
  }

  // Text search on title + description
  if (context.query) {
    const q = context.query.toLowerCase()
    results = results.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.subcategory?.toLowerCase().includes(q),
    )
  }

  // Condition filter
  if (context.condition) {
    results = results.filter((p) => p.condition === context.condition)
  }

  // Location filter
  if (context.location) {
    results = results.filter((p) => p.location.toLowerCase().includes(context.location!.toLowerCase()))
  }

  // Sorting
  switch (context.sortBy || "relevance") {
    case "price-asc":
      results.sort((a, b) => a.price - b.price)
      break
    case "price-desc":
      results.sort((a, b) => b.price - a.price)
      break
    case "newest":
      results.sort((a, b) => b.createdAt - a.createdAt)
      break
    case "popular":
      results.sort((a, b) => b.views - a.views)
      break
    case "rating":
      // Would need review ratings added; placeholder
      break
  }

  return results
}

// ============ PRODUCT COMPARISON ============

export function buildComparisonTable(
  productIds: string[],
  products: Product[],
): ComparisonRow[] {
  const items = productIds.map((id) => products.find((p) => p.id === id)).filter(Boolean) as Product[]
  if (items.length === 0) return []

  const attributes = [
    "price",
    "condition",
    "category",
    "subcategory",
    "stock",
    "location",
    "deliveryOptions",
    "featured",
    "handlingTimeDays",
  ]

  return attributes.map((attr) => {
    let row: ComparisonRow = { attribute: attr, products: [] }

    for (const p of items) {
      if (attr === "price") row.products.push(p.price)
      else if (attr === "condition") row.products.push(p.condition)
      else if (attr === "category") row.products.push(p.category)
      else if (attr === "subcategory") row.products.push(p.subcategory || "—")
      else if (attr === "stock") row.products.push(p.stock)
      else if (attr === "location") row.products.push(p.location)
      else if (attr === "deliveryOptions") row.products.push(p.deliveryOptions.join(", "))
      else if (attr === "featured") row.products.push(p.featured)
      else if (attr === "handlingTimeDays") row.products.push(p.handlingTimeDays)
    }

    return row
  })
}

// ============ MARKETPLACE ANALYTICS ============

export function computeBuyerInsights(
  orders: Order[],
  products: Product[],
): BuyerInsight {
  const searchFreq: Record<string, number> = {}
  const categoryFreq: Record<Category, number> = {}
  let totalSpent = 0
  const priceBrackets: Record<string, number> = {}

  for (const order of orders) {
    totalSpent += order.total

    for (const item of order.items) {
      const prod = products.find((p) => p.id === item.productId)
      if (prod) {
        categoryFreq[prod.category] = (categoryFreq[prod.category] || 0) + 1

        const bracket = `${Math.floor(item.price / 50) * 50}-${(Math.floor(item.price / 50) + 1) * 50}`
        priceBrackets[bracket] = (priceBrackets[bracket] || 0) + 1
      }
    }
  }

  return {
    topSearchQueries: Object.entries(searchFreq)
      .map(([q, c]) => ({ query: q, count: c }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5),
    topCategories: Object.entries(categoryFreq)
      .map(([c, count]) => ({ category: c as Category, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5),
    priceRangeMost: {
      min: 0,
      max: 100,
      count: Object.values(priceBrackets).reduce((a, b) => Math.max(a, b), 0),
    },
    avgOrderValue: orders.length > 0 ? totalSpent / orders.length : 0,
    conversionFunnel: {
      browsed: products.length,
      viewed: Math.floor(products.reduce((s, p) => s + p.views, 0) / products.length),
      added: Math.floor(orders.length * 0.6),
      purchased: orders.length,
    },
  }
}

export function computeSellerInsights(
  sellerId: string,
  orders: Order[],
  products: Product[],
): SellerInsight {
  const sellerOrders = orders.filter((o) => o.sellerId === sellerId)
  const sellerProducts = products.filter((p) => p.sellerId === sellerId)

  const productSales: Record<string, number> = {}
  for (const order of sellerOrders) {
    for (const item of order.items) {
      productSales[item.productId] = (productSales[item.productId] || 0) + item.quantity
    }
  }

  return {
    topProducts: Object.entries(productSales)
      .map(([id, sales]) => ({ productId: id, sales }))
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5),
    avgReviewScore: 4.5, // Would be computed from actual reviews
    totalSales: sellerOrders.length,
    responseTime: 120, // Would be from actual data
    refundRate: 0.05,
    repeatCustomerRate: 0.3,
  }
}

// ============ VOICE SEARCH ARCHITECTURE ============

export function parseVoiceQuery(voiceText: string): SearchContext {
  const lower = voiceText.toLowerCase()
  const context: SearchContext = { query: voiceText }

  // Extract price ceiling: "under 100" "less than 50"
  const priceMatch = lower.match(/(?:under|below|less than)\s+(\d+)/)
  if (priceMatch) context.maxPrice = Number.parseInt(priceMatch[1], 10)

  // Extract category
  const categoryKeywords: Record<string, Category> = {
    phone: "electronics",
    laptop: "electronics",
    electronic: "electronics",
    gadget: "electronics",
    fashion: "fashion",
    clothes: "fashion",
    home: "home",
    furniture: "home",
    vehicle: "vehicles",
    car: "vehicles",
    bike: "vehicles",
  }

  for (const [key, cat] of Object.entries(categoryKeywords)) {
    if (lower.includes(key)) {
      context.category = cat
      break
    }
  }

  // Extract sort preference
  if (lower.includes("cheapest") || lower.includes("lowest")) context.sortBy = "price-asc"
  if (lower.includes("expensive") || lower.includes("highest")) context.sortBy = "price-desc"
  if (lower.includes("new") || lower.includes("latest")) context.sortBy = "newest"
  if (lower.includes("popular") || lower.includes("trending")) context.sortBy = "popular"

  return context
}

// ============ IMAGE SEARCH ARCHITECTURE (Future-ready) ============

export interface ImageSearchAdapter {
  extractFeatures(imageUrl: string): Promise<Record<string, number>>
  findSimilarProducts(features: Record<string, number>, products: Product[]): Product[]
}

export const imageSearchAdapter: ImageSearchAdapter = {
  async extractFeatures(imageUrl: string) {
    // Future: Connect to vision API (Google Cloud Vision, AWS Rekognition, etc.)
    // For now, return placeholder
    return { color_distribution: 0.5, object_type: 0.7, brand_signature: 0.3 }
  },

  findSimilarProducts(features: Record<string, number>, products: Product[]) {
    // Future: Use ML model to match features
    // For now, return random sampling
    return products.slice(0, 8)
  },
}

// ============ LOCAL MARKETPLACE ============

export function getLocalProducts(
  products: Product[],
  userLocation: string,
  radiusKm: number = 50,
): Product[] {
  // Future: Integrate with geolocation service
  // For now, filter by location name
  return products.filter((p) => p.location.toLowerCase().includes(userLocation.toLowerCase()))
}

// ============ SEASONAL COLLECTIONS ============

export function getSeasonalCollections(): { name: string; tag: string; theme: string }[] {
  const now = new Date()
  const month = now.getMonth()
  const collections = []

  if (month >= 11 || month === 0) collections.push({ name: "Holiday & New Year", tag: "holiday-2024", theme: "Festive" })
  if (month >= 2 && month <= 4) collections.push({ name: "Spring Collection", tag: "spring-2024", theme: "Fresh" })
  if (month >= 5 && month <= 7) collections.push({ name: "Summer Sale", tag: "summer-2024", theme: "Outdoor" })
  if (month >= 8 && month <= 10) collections.push({ name: "Autumn Essentials", tag: "autumn-2024", theme: "Cozy" })

  return collections
}

// ============ VERIFIED BUSINESSES ============

export function getVerifiedBusinesses(sellers: UserProfile[]): UserProfile[] {
  return sellers
    .filter((s) => s.verification === "verified" && s.isSeller)
    .sort((a, b) => b.reputationScore - a.reputationScore)
}
