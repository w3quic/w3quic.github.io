# Integration Guide - Adding AI Features to Market App

## Quick Start Integration

### 1. Add to Home View (Recommended)
**File**: `components/market/home-view.tsx`

\`\`\`tsx
import { DiscoveryHub } from './discovery-hub'
import { RecommendationsSection } from './recommendations-section'

export function HomeView() {
  const market = useMarket()

  return (
    <div className="space-y-8 pb-24">
      {/* Existing content */}
      
      {/* Add Discovery Hub - NEW */}
      <DiscoveryHub 
        onProductSelect={(product) => {
          // Navigate to product detail
          setSelectedProduct(product)
        }}
      />
      
      {/* OR individual sections */}
      <RecommendationsSection
        title="Recommended For You"
        type="recommendations"
        onProductSelect={handleProductSelect}
      />
      
      <RecommendationsSection
        title="Trending Now"
        type="trending"
        onProductSelect={handleProductSelect}
      />
    </div>
  )
}
\`\`\`

### 2. Update Header Search
**File**: `components/market/top-bar.tsx` or `components/market/navigation.tsx`

\`\`\`tsx
import { SmartSearch } from './smart-search'

export function TopBar() {
  const [searchResults, setSearchResults] = useState([])

  return (
    <header className="sticky top-0 z-40 border-b">
      <div className="px-4 py-2">
        {/* Logo etc */}
        
        {/* Replace existing search with SmartSearch */}
        <SmartSearch
          onSearch={(results) => setSearchResults(results)}
          compact={true}
        />
      </div>
    </header>
  )
}
\`\`\`

### 3. Add Search Page
**New File**: `components/market/search-view.tsx`

\`\`\`tsx
import { AdvancedSearch } from './advanced-search'
import { SmartSearch } from './smart-search'

export function SearchView() {
  return (
    <div className="p-4 space-y-6">
      <SmartSearch compact={false} />
      <AdvancedSearch />
    </div>
  )
}
\`\`\`

### 4. Add to Profile/Dashboard
**File**: `components/market/profile-view.tsx`

\`\`\`tsx
import { PersonalizationHub } from './personalization-hub'
import { MarketplaceIntelligence } from './marketplace-intelligence'

export function ProfileView() {
  return (
    <Tabs defaultValue="personalization">
      <TabsList>
        <TabsTrigger value="personalization">Personalization</TabsTrigger>
        <TabsTrigger value="wishlist">Wishlist</TabsTrigger>
        {isSeller && <TabsTrigger value="insights">Insights</TabsTrigger>}
      </TabsList>

      <TabsContent value="personalization">
        <PersonalizationHub 
          onProductSelect={handleProductSelect}
        />
      </TabsContent>

      {isSeller && (
        <TabsContent value="insights">
          <MarketplaceIntelligence />
        </TabsContent>
      )}
    </Tabs>
  )
}
\`\`\`

### 5. Add Comparison Feature
**File**: `components/market/product-view.tsx` (Product Detail)

\`\`\`tsx
import { Button } from '@/components/ui/button'
import { ComparisonView } from './comparison-view'

export function ProductDetailView() {
  const [showComparison, setShowComparison] = useState(false)
  const [similarProducts, setSimilarProducts] = useState([])
  const market = useMarket()

  useEffect(() => {
    setSimilarProducts(market.getSimilarProducts(product.id))
  }, [product.id])

  return (
    <div className="space-y-4">
      {/* Product details */}
      
      <div className="flex gap-2">
        <Button 
          onClick={() => market.toggleWishlist(product.id)}
          variant="outline"
        >
          Add to Wishlist
        </Button>
        <Button 
          onClick={() => setShowComparison(true)}
          variant="outline"
        >
          Compare
        </Button>
      </div>

      {/* Similar Products */}
      {similarProducts.length > 0 && (
        <div className="mt-8">
          <h3 className="font-semibold mb-4">Similar Products</h3>
          <div className="grid grid-cols-2 gap-3">
            {similarProducts.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}

      {showComparison && (
        <ComparisonView onClose={() => setShowComparison(false)} />
      )}
    </div>
  )
}
\`\`\`

## Navigation Integration

### Add Tabs/Routes
**File**: `lib/market/nav.tsx`

\`\`\`tsx
export const NAV_ITEMS = [
  { name: 'home', label: 'Home', icon: 'Home' },
  { name: 'browse', label: 'Browse', icon: 'Search' },
  { name: 'discover', label: 'Discover', icon: 'Sparkles' }, // NEW
  { name: 'cart', label: 'Cart', icon: 'ShoppingCart' },
  { name: 'profile', label: 'Profile', icon: 'User' },
]
\`\`\`

Then in `market-app.tsx`:
\`\`\`tsx
case 'discover':
  return <DiscoveryHub onProductSelect={handleProductSelect} />
\`\`\`

## Store Hook Usage

### Getting Recommendations
\`\`\`tsx
const market = useMarket()

// Personalized recommendations
const recommendations = market.getProductRecommendations()

// Similar products
const similar = market.getSimilarProducts(productId)

// Better alternatives
const alternatives = market.getBetterValueSuggestions(productId)

// Trending
const trending = market.getTrendingProducts()
const trendingCats = market.getTrendingCategories()

// Deals
const priceDropped = market.getRecentlyPriceDropped()
const restocked = market.getRecentlyRestocked()

// Analytics
const insights = market.getMarketplaceInsights()

// Discovery
const verified = market.getVerifiedBusinesses()
const local = market.getLocalProducts('Singapore')
\`\`\`

### Search Features
\`\`\`tsx
// Search suggestions
const suggestions = market.getSearchSuggestions('laptop')

// Advanced search
const results = market.performSmartSearch({
  query: 'gaming laptop',
  category: 'electronics',
  maxPrice: 500,
  sortBy: 'price-asc'
})

// Comparison table
const comparison = market.buildComparisonTable([id1, id2, id3])

// Search management
market.addSearch('laptop under 500')
market.saveSearch('laptop under 500')
market.removeSearch('old search')
\`\`\`

## Styling Considerations

All components use existing shadcn/ui components:
- Button
- Input
- Card, CardContent, CardDescription, CardHeader, CardTitle
- Tabs, TabsContent, TabsList, TabsTrigger
- Empty (for empty states)

Tailwind classes follow existing convention. No additional CSS needed.

## Performance Tips

### 1. Lazy Load Components
\`\`\`tsx
const DiscoveryHub = lazy(() => import('./discovery-hub'))
const PersonalizationHub = lazy(() => import('./personalization-hub'))

// In component
<Suspense fallback={<Spinner />}>
  <DiscoveryHub />
</Suspense>
\`\`\`

### 2. Memoize List Renders
\`\`\`tsx
const MemoProductCard = memo(ProductCard)

{results.map(p => (
  <MemoProductCard key={p.id} product={p} />
))}
\`\`\`

### 3. Debounce Search Input
\`\`\`tsx
import { useDebouncedCallback } from 'use-debounce'

const handleSearch = useDebouncedCallback((query) => {
  const suggestions = market.getSearchSuggestions(query)
  setSuggestions(suggestions)
}, 300)
\`\`\`

## Testing Examples

### Unit Test - Store Methods
\`\`\`typescript
import { renderHook, act } from '@testing-library/react'
import { useMarket } from '@/lib/market/store'

test('getTrendingProducts returns sorted products', () => {
  const { result } = renderHook(() => useMarket())
  const trending = result.current.getTrendingProducts()
  expect(trending.length).toBeGreaterThan(0)
})
\`\`\`

### Component Test - SmartSearch
\`\`\`tsx
import { render, screen, fireEvent } from '@testing-library/react'
import { SmartSearch } from './smart-search'

test('search suggestions appear on input', async () => {
  const { getByPlaceholderText } = render(<SmartSearch />)
  const input = getByPlaceholderText(/search/i)
  
  fireEvent.change(input, { target: { value: 'laptop' } })
  
  await waitFor(() => {
    expect(screen.getByText(/laptop/i)).toBeInTheDocument()
  })
})
\`\`\`

## Configuration & Customization

### Limits & Pagination
\`\`\`tsx
// In intelligence.ts adapter functions
// Edit these constants:
const limit = 10 // getProductRecommendations
const limit = 8  // getSimilarProducts
const limit = 12 // getTrendingProducts
\`\`\`

### Category Scoring
\`\`\`tsx
// In getProductRecommendations()
score += categoryScore * 15  // Adjust weight
\`\`\`

### Price Proximity (Similar Products)
\`\`\`tsx
// In getSimilarProducts()
if (priceDiff < 0.3) score += 15  // Adjust tolerance
\`\`\`

### Trending Calculation
\`\`\`tsx
// In getTrendingProducts()
score += Math.min(p.views / 10, 25)  // Adjust view weight
\`\`\`

## Troubleshooting

### Voice Search Not Working
1. Check browser support (requires https://, except localhost)
2. Ensure microphone permission granted
3. Check browser console for errors
4. Test in Chrome/Edge first (best support)

### Slow Recommendations
1. Reduce product count in seed data for testing
2. Add memoization to expensive functions
3. Implement pagination for large result sets
4. Consider server-side computation later

### Comparison Not Showing
1. Ensure min 2 products selected (max 4)
2. Check product IDs are valid
3. Verify buildComparisonTable returns non-empty array

### Missing Wishlist Recommendations
1. Add at least 1 item to wishlist
2. Ensure product exists with similar category
3. Check market.wishlist is populated

## Deployment Checklist

- [ ] Import all new components in market-app.tsx
- [ ] Add discovery hub to home view
- [ ] Update header search with smart-search
- [ ] Add personalization hub to profile
- [ ] Enable comparison feature in product detail
- [ ] Add advanced search page/modal
- [ ] Test voice search on target devices
- [ ] Test on mobile viewport
- [ ] Verify existing features still work
- [ ] Check performance metrics
- [ ] Update user documentation
- [ ] Deploy to staging
- [ ] Beta test with users
- [ ] Deploy to production

## Support & Debugging

### Enable Debug Logging
\`\`\`tsx
// In components
console.log('[Market] Search results:', results)
console.log('[Market] Recommendations:', recommendations)
console.log('[Market] Store state:', market)
\`\`\`

### Check Store State
\`\`\`tsx
const market = useMarket()
console.log({
  recentSearches: market.recentSearches,
  savedSearches: market.savedSearches,
  wishlist: market.wishlist,
  recentlyViewed: market.recentlyViewed
})
\`\`\`

### Monitor Performance
\`\`\`tsx
useEffect(() => {
  const start = performance.now()
  const results = market.getTrendingProducts()
  console.log('Trending time:', performance.now() - start, 'ms')
}, [])
\`\`\`

## Next Steps

1. **Choose Integration Points**: Decide which features to enable first
2. **Test Components**: Render each component in isolation
3. **Integrate Gradually**: Add features one at a time
4. **Gather User Feedback**: Monitor adoption and engagement
5. **Connect Backend APIs**: When ready, swap adapters for real services
6. **Scale Infrastructure**: Move to server-side computation as needed

The modular design ensures you can start small and grow as needed!
