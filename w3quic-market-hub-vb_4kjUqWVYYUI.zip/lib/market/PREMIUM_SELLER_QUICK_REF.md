# Premium Seller Payment Button - Quick Reference

## 📍 WHERE IS THE BUTTON?

### Seller Dashboard
`/components/market/seller-view.tsx` → Overview Tab → "Premium Seller Status" section

### Profile View
`/components/market/profile-view.tsx` → "Upgrade to Premium Seller" section + Quick Actions "Subscriptions"

### Settings
`/components/market/settings-view.tsx` → "Seller Subscriptions" section

### Subscription Management (NEW PAGE)
`/components/market/subscription-management-view.tsx` → Dedicated subscription page

---

## 🛠️ KEY COMPONENT

**File**: `/components/market/premium-seller-button.tsx`

**Usage**:
\`\`\`tsx
<PremiumSellerButton 
  variant="default"
  showFeatures={true}
  showPriceInLabel={true}
  onSuccess={() => console.log('Premium activated!')}
/>
\`\`\`

---

## 💎 PRODUCT DETAILS

| Field | Value |
|-------|-------|
| Product ID | `6a34b3d1ac92b4f7f73dd4d3` |
| Price | 0.5 π |
| Name | Premium Seller |
| Type | Lifetime Subscription |

---

## ⚡ PAYMENT FLOW

1. Click button → SDK shows Pi payment screen
2. User approves payment
3. SDK returns result with `ok: true` on success
4. Component updates user status: `isPremium: true`
5. UI refreshes to show premium status
6. Success toast shown: "Premium seller status activated!"

---

## 🎯 PREMIUM BENEFITS

1. ⭐ Featured Listings
2. 📊 Advanced Analytics
3. 🚀 Priority Search Visibility
4. ✓ Seller Verification Badge
5. 🛠️ Premium Business Tools
6. 🎯 Exclusive Promotions
7. 📈 Marketplace Growth Features

---

## ✅ WHAT HAPPENS AFTER PURCHASE

- User status: `isPremium: true`
- Badge added: `'premium_seller'`
- Timestamp saved: `premiumActivatedAt: Date.now()`
- UI updates immediately across all pages
- Seller can access Subscription Management page

---

## 🔍 DEBUGGING

### Button not showing?
- Check if `me.isSeller` is true
- Verify component is imported
- Check route is correct

### Purchase not working?
- Verify SDK is ready: `usePiAuth()?.sdk` exists
- Check product exists: `PRODUCT_CONFIG.PRODUCT_6a34b3d1ac92b4f7f73dd4d3`
- Check browser console for errors

### Status not updating?
- Verify `updateMe()` is called
- Check `me.isPremium` state in market store
- Look for localStorage updates

---

## 📁 FILES TO KNOW

| File | Purpose |
|------|---------|
| `premium-seller-button.tsx` | Main button component |
| `subscription-management-view.tsx` | Subscription management page |
| `seller-view.tsx` | Seller dashboard |
| `profile-view.tsx` | User profile |
| `settings-view.tsx` | Settings page |
| `nav.tsx` | Navigation routes |
| `market-app.tsx` | App router |
| `types.ts` | Data types |

---

## 🎨 STYLING NOTES

- Button color: Amber/Gold gradient (`from-amber-600 to-amber-700`)
- Premium status color: Green (`text-green-600`)
- Non-premium section: Amber background (`from-amber-50 to-amber-100`)
- Premium section: Green background (`from-green-50 to-green-100`)

---

## 📱 RESPONSIVE

✅ Mobile: Full width button with proper padding
✅ Tablet: Adapts to screen size
✅ Desktop: Normal size with hover effects

---

## 🔐 ERROR CODES

| Code | Message |
|------|---------|
| `product_not_found` | Product not available |
| `purchase_cancelled` | User cancelled payment |
| `purchase_error` | Payment failed |
| `unknown_error` | Unexpected error |

---

## 📊 TRACKING

- Purchase attempts logged
- Success/failure recorded
- User activation timestamp saved
- Premium status tracked in user profile

---

## 🚀 QUICK START

1. **View Button**: Go to Seller Dashboard → Overview section
2. **See Benefits**: PremiumSellerButton shows features
3. **Make Purchase**: Click "Upgrade to Premium Seller (0.5 π)"
4. **Authorize Payment**: Approve via Pi wallet
5. **Done!**: Premium status activated instantly

---

## 💬 USER COMMUNICATION

**Non-Premium Message**: 
"Get verified seller status, priority product listings, advanced analytics, promotional tools, and increased visibility to grow your business."

**Premium Message**: 
"You have premium seller status! Enjoy verified seller badge, priority listings, advanced analytics, promotional tools, and increased visibility."

---

## 🎯 SUCCESS INDICATORS

✅ Button shows price: "Upgrade to Premium Seller (0.5 π)"
✅ Green checkmark appears after purchase
✅ Premium status badge visible on profile
✅ Subscription Management page accessible
✅ Toast notification: "Premium seller status activated! 🎉"

---

## ⚙️ CONFIGURATION

**Product Config** (`/lib/product-config.ts`):
\`\`\`typescript
PRODUCT_6a34b3d1ac92b4f7f73dd4d3: "6a34b3d1ac92b4f7f73dd4d3"
\`\`\`

**Navigation** (`/lib/market/nav.tsx`):
\`\`\`typescript
| { name: "subscription" }
\`\`\`

---

**Last Updated**: June 18, 2026
**Status**: Active & Deployed
**Support**: See PREMIUM_SELLER_PAYMENT_GUIDE.md
