# Pi Market Hub - Advanced Systems Guide

This guide covers the four enterprise-grade systems implemented for Pi Market Hub.

## Table of Contents

1. [Secure Trading System](#secure-trading-system)
2. [Business Verification System](#business-verification-system)
3. [Shipping & Logistics System](#shipping--logistics-system)
4. [Advertising Platform](#advertising-platform)

---

## Secure Trading System

**Location**: `lib/market/secure-trading.ts` | **Component**: `components/market/dispute-center.tsx`

### Overview

The secure trading system protects both buyers and sellers through escrow management, dispute resolution, and protection programs.

### Key Features

#### 1. Escrow System

Holds Pi in escrow until the buyer confirms delivery, protecting both parties.

\`\`\`typescript
import { createEscrow, releaseEscrow, refundEscrow, disputeEscrow } from "@/lib/market/secure-trading"

// Create escrow when order is placed
const escrow = createEscrow(order)

// Buyer confirms delivery
escrow = confirmBuyerReceivedDelivery(escrow)

// Release funds to seller
escrow = releaseEscrow(escrow)
\`\`\`

**Features**:
- 14-day escrow hold period
- Auto-release after 14 days if no dispute
- Buyer confirmation triggers immediate release
- Prevents chargeback fraud

#### 2. Dispute Resolution

Comprehensive dispute handling with evidence collection and admin resolution.

\`\`\`typescript
import { createDispute, addDisputeEvidence, addDisputeMessage, resolveDispute } from "@/lib/market/secure-trading"

// Open dispute
const dispute = createDispute(
  orderId, escrowId, buyerId, sellerId,
  "item-not-as-described",
  "Item received was different from listing"
)

// Add evidence
dispute = addDisputeEvidence(dispute, buyerId, {
  type: "image",
  url: "https://...",
  description: "Photo of defect"
})

// Admin resolution
dispute = resolveDispute(dispute, adminId, "refund-buyer", "Item defect verified")
\`\`\`

**Dispute Reasons**:
- `item-not-received`
- `item-not-as-described`
- `defective-damaged`
- `counterfeit`
- `unauthorized-transaction`
- `wrong-item`
- `other`

**Resolution Types**:
- `refund-buyer` - Full refund to buyer
- `release-to-seller` - Release funds to seller
- `partial-refund` - Split funds between parties
- `no-action` - No compensation needed

#### 3. Buyer Protection

Money-back guarantee program for buyers.

\`\`\`typescript
import { createBuyerProtection, claimBuyerProtection } from "@/lib/market/secure-trading"

// Create 30-day protection
const protection = createBuyerProtection(orderId, buyerId, orderAmount)

// Claim if item not as described
protection = claimBuyerProtection(protection, "Item not as described")
\`\`\`

#### 4. Seller Protection

Protects sellers from chargebacks and false claims.

\`\`\`typescript
import { createSellerProtection } from "@/lib/market/secure-trading"

// 90-day protection
const protection = createSellerProtection(orderId, sellerId, orderAmount)
\`\`\`

#### 5. Refund System

Structured refund workflow.

\`\`\`typescript
import { createRefundRequest, approveRefund, completeRefund } from "@/lib/market/secure-trading"

// Buyer requests refund
const refund = createRefundRequest(orderId, buyerId, sellerId, amount, "Defective item")

// Admin approves
refund = approveRefund(refund, adminId, "Item damage verified")

// Process refund
refund = completeRefund(refund)
\`\`\`

#### 6. Money Back Guarantee

Extended guarantees for buyer confidence.

\`\`\`typescript
import { createMoneyBackGuarantee, claimMoneyBackGuarantee } from "@/lib/market/secure-trading"

// 30-day guarantee
const guarantee = createMoneyBackGuarantee(orderId, buyerId, amount, 30)

// Claim within period
guarantee = claimMoneyBackGuarantee(guarantee, amount)
\`\`\`

#### 7. Trust Metrics

Calculate seller trustworthiness.

\`\`\`typescript
import { calculateTrustMetrics } from "@/lib/market/secure-trading"

const metrics = calculateTrustMetrics(orders, disputes)
// Returns: { disputeRate, refundRate, escrowReleaseRate, trustScore, trustLevel }

// Trust levels: "low" | "medium" | "high" | "premium"
\`\`\`

---

## Business Verification System

**Location**: `lib/market/business-verification.ts` | **Component**: `components/market/verification-dashboard.tsx`

### Overview

Multi-tier verification system for individual and business accounts with badges.

### Key Features

#### 1. Business Verification

Verify business legitimacy through documentation.

\`\`\`typescript
import {
  createBusinessVerification,
  addVerificationDocument,
  approveBusinessVerification,
} from "@/lib/market/business-verification"

// Create business verification
const verification = createBusinessVerification(
  userId,
  "Acme Corporation",
  "REG-12345",
  "corporation"
)

// Add required documents
verification = addVerificationDocument(
  verification,
  "business-license",
  "https://...",
  expiryDate
)

// Approve (requires all docs)
verification = approveBusinessVerification(verification, adminId, 365)
\`\`\`

**Document Types**:
- `business-license` - Sole prop/Partnership/Corporation
- `tax-id` - Partnership/Corporation/LLC
- `identity-document` - Sole prop only
- `address-proof` - Sole prop only
- `bank-statement` - Additional verification
- `incorporation-cert` - Corporation/LLC

#### 2. Identity Verification

Personal identity verification with biometrics.

\`\`\`typescript
import {
  createIdentityVerification,
  addFaceVerification,
  approveIdentityVerification,
} from "@/lib/market/business-verification"

const identity = createIdentityVerification(
  userId,
  "passport",
  "AB123456",
  "https://..."
)

// Add face verification
identity = addFaceVerification(identity, "https://face-selfie...")

// Approve
identity = approveIdentityVerification(identity, adminId, 1095) // 3 years
\`\`\`

#### 3. Verification Badges

Earn badges based on verification status.

\`\`\`typescript
import { getEligibleBadges, VERIFICATION_BADGES } from "@/lib/market/business-verification"

const badges = getEligibleBadges(
  true,  // email verified
  true,  // identity verified
  false, // business verified
  500,   // transaction count
  4.8,   // rating
  2,     // dispute rate %
  true   // premium
)
// Returns array of badge types earned

// Available badges:
// - email-verified
// - identity-verified
// - business-verified
// - high-volume-seller (1000+ transactions)
// - trusted-seller (4.8+ rating, <5% disputes)
// - premium-seller
// - eco-friendly
\`\`\`

#### 4. Verification Progress Tracking

Track overall verification progress.

\`\`\`typescript
import { calculateVerificationProgress } from "@/lib/market/business-verification"

const progress = calculateVerificationProgress(
  true,        // email verified
  "approved",  // identity status
  "pending",   // business status
  4            // documents submitted
)
// Returns: { emailVerified, identityVerified, businessVerified, overallProgress, estimatedApprovalTime }
\`\`\`

#### 5. Verification Expiry & Renewal

Manage verification expiration.

\`\`\`typescript
import { isVerificationExpired, getDaysUntilExpiry, needsRenewal } from "@/lib/market/business-verification"

const expired = isVerificationExpired(expiresAt)
const daysLeft = getDaysUntilExpiry(expiresAt)
const needsRenewal = needsRenewal(expiresAt) // Reminds 30 days before
\`\`\`

---

## Shipping & Logistics System

**Location**: `lib/market/shipping-logistics.ts` | **Component**: `components/market/shipping-tracker.tsx`

### Overview

Complete shipping management with real-time tracking and delivery confirmation.

### Key Features

#### 1. Shipping Labels

Generate shipping labels with tracking numbers.

\`\`\`typescript
import { createShippingLabel, CARRIERS } from "@/lib/market/shipping-logistics"

const label = createShippingLabel(
  orderId,
  "dhl",  // dhl | fedex | ups | local
  5       // estimated delivery days
)
// Returns: { trackingNumber, carrier, estimatedDelivery, cost }
\`\`\`

**Shipping Costs** (in Pi):
- DHL: 8.5 Pi
- FedEx: 10.0 Pi
- UPS: 9.5 Pi
- Local: 2.0 Pi

#### 2. Shipment Tracking

Track package throughout delivery.

\`\`\`typescript
import {
  createShipment,
  markAsPickedUp,
  markAsInTransit,
  markAsOutForDelivery,
  markAsDelivered,
  reportException,
} from "@/lib/market/shipping-logistics"

// Create shipment
let shipment = createShipment(orderId, sellerId, buyerId, items, label)

// Update status
shipment = markAsPickedUp(shipment, "Singapore Center")
shipment = markAsInTransit(shipment, "Taipei Hub")
shipment = markAsOutForDelivery(shipment, "Taipei District")
shipment = markAsDelivered(shipment, "Home", "John Doe", "signature")

// Handle exceptions
shipment = reportException(shipment, "Delivery attempt failed", "Recipient not home")
\`\`\`

**Tracking Statuses**:
- `label-created` - Shipping label generated
- `picked-up` - Package collected from sender
- `in-transit` - En route to destination
- `out-for-delivery` - On delivery vehicle
- `delivered` - Successfully delivered
- `exception` - Issue during delivery
- `returned` - Package returned to sender

#### 3. Delivery Preferences

Set user delivery preferences.

\`\`\`typescript
import { createDeliveryPreference, updateDeliveryPreference } from "@/lib/market/shipping-logistics"

let preference = createDeliveryPreference(userId)

preference = updateDeliveryPreference(preference, {
  preferredCarrier: "dhl",
  preferredDeliveryType: "express",
  requireSignature: true,
  allowHoldAtLocation: true,
})

preference = setPreferredTimeSlots(preference, ["9AM-12PM", "2PM-5PM"])
\`\`\`

#### 4. Delivery Confirmation

Confirm delivery receipt.

\`\`\`typescript
import { confirmDelivery, hasDeliveryBeenConfirmed } from "@/lib/market/shipping-logistics"

shipment = confirmDelivery(shipment, "Item received in perfect condition")

if (hasDeliveryBeenConfirmed(shipment)) {
  // Release escrow funds to seller
}
\`\`\`

#### 5. Return Shipping

Generate return labels.

\`\`\`typescript
import { createReturnShippingLabel } from "@/lib/market/shipping-logistics"

// Free return label (seller pays)
const returnLabel = createReturnShippingLabel(orderId, "dhl")
\`\`\`

#### 6. Shipping Analytics

Analyze shipping performance.

\`\`\`typescript
import { calculateShippingMetrics } from "@/lib/market/shipping-logistics"

const metrics = calculateShippingMetrics(shipments)
// Returns: { totalShipments, averageDeliveryTime, onTimeDeliveryRate, exceptionRate, carrierPerformance }
\`\`\`

#### 7. Estimated Delivery Calculation

Smart delivery date calculation.

\`\`\`typescript
import { calculateEstimatedDelivery } from "@/lib/market/shipping-logistics"

const deliveryDate = calculateEstimatedDelivery(
  "dhl",       // carrier
  "domestic",  // domestic | regional | international
  5            // base days
)
// Automatically skips weekends
\`\`\`

---

## Advertising Platform

**Location**: `lib/market/advertising-platform.ts` | **Component**: `components/market/advertising-manager.tsx`

### Overview

Complete advertising platform for product promotion and sales boosting.

### Key Features

#### 1. Ad Campaigns

Create and manage advertising campaigns.

\`\`\`typescript
import {
  createAdCampaign,
  activateCampaign,
  pauseCampaign,
  resumeCampaign,
  completeCampaign,
  recordImpression,
  recordClick,
  recordConversion,
} from "@/lib/market/advertising-platform"

// Create draft campaign
let campaign = createAdCampaign(
  sellerId,
  "featured-product",  // featured-product | featured-store | sponsored-search | promotion | flash-sale
  50,                  // budget in Pi
  startDate,
  endDate,
  productId
)

// Set budgets
campaign = setDailyBudget(campaign, 10)
campaign = setBidAmount(campaign, 0.5)

// Activate
campaign = activateCampaign(campaign, adminId)

// Track metrics
campaign = recordImpression(campaign)
campaign = recordClick(campaign)
campaign = recordConversion(campaign)

// Pause/Resume
campaign = pauseCampaign(campaign)
campaign = resumeCampaign(campaign)
\`\`\`

**Campaign Types**:
- `featured-product` - Homepage showcase
- `featured-store` - Store promotion
- `sponsored-search` - Top search results
- `promotion` - Discount campaigns
- `flash-sale` - Time-limited deals

#### 2. Campaign Metrics

Analyze campaign performance.

\`\`\`typescript
import { calculateAdMetrics } from "@/lib/market/advertising-platform"

const metrics = calculateAdMetrics(campaign)
// Returns: { impressions, clicks, conversions, spend, roi, ctr, conversionRate }
\`\`\`

#### 3. Ad Quality Scoring

Evaluate ad quality and optimize.

\`\`\`typescript
import { evaluateAdQuality, shouldOptimizeAd } from "@/lib/market/advertising-platform"

const qualityScore = evaluateAdQuality(metrics, campaign)
if (shouldOptimizeAd(qualityScore)) {
  // Recommend optimizations
}
\`\`\`

#### 4. Budget Management

Track spending and remaining budget.

\`\`\`typescript
import {
  getRemainingBudget,
  getDailySpendRate,
  estimateRemainingDays,
  isNearBudgetLimit,
} from "@/lib/market/advertising-platform"

const remaining = getRemainingBudget(campaign, metrics)
const dailyRate = getDailySpendRate(campaign, metrics)
const daysLeft = estimateRemainingDays(campaign, metrics)

if (isNearBudgetLimit(campaign, metrics)) {
  // Alert: approaching budget limit
}
\`\`\`

#### 5. Promotional Offers

Create and manage promotions.

\`\`\`typescript
import {
  createPromotionalOffer,
  applyPromotion,
  canUseOffer,
  incrementOfferUsage,
} from "@/lib/market/advertising-platform"

// Create offer
let offer = createPromotionalOffer(
  sellerId,
  "percentage",     // percentage | fixed | bogo | tiered
  10,               // 10% off
  startDate,
  endDate,
  productId
)

// Configure
offer = setMaxDiscountAmount(offer, 50)
offer = setMinPurchaseAmount(offer, 100)
offer = setMaxUses(offer, 1000)

// Apply to order
const { discountAmount, finalAmount } = applyPromotion(offer, 250)

// Track usage
if (canUseOffer(offer, 250)) {
  offer = incrementOfferUsage(offer)
}
\`\`\`

**Discount Types**:
- `percentage` - % off with optional max
- `fixed` - Fixed Pi amount off
- `bogo` - Buy one get one
- `tiered` - Progressive discounts

#### 6. Featured Listings

Highlight products and stores.

\`\`\`typescript
import { createFeaturedListing, assignFeaturedPosition } from "@/lib/market/advertising-platform"

const listing = createFeaturedListing(
  "product",     // product | store
  productId,
  7,             // duration days
  5.0,           // cost in Pi
  false          // sponsored
)

// Assign position (1-10)
listing = assignFeaturedPosition(listing, 3)
\`\`\`

#### 7. Sponsored Search

Bid on search keywords.

\`\`\`typescript
import { createSponsoredSearchListing, calculateAdRank } from "@/lib/market/advertising-platform"

const search = createSponsoredSearchListing(
  productId,
  sellerId,
  0.5,                                    // bid per click
  10,                                     // daily budget
  ["wireless headphones", "audio", "bluetooth"],  // keywords
  "Premium Wireless Headphones",
  "Noise-cancelling with 30-hour battery"
)

// Calculate ad rank (higher = better position)
const adRank = calculateAdRank(search, qualityScore)
\`\`\`

---

## Implementation Checklist

### Phase 1: Secure Trading ✓
- [x] Escrow system
- [x] Dispute center
- [x] Buyer/Seller protection
- [x] Refund workflow
- [x] Money back guarantee
- [x] Trust metrics

### Phase 2: Business Verification ✓
- [x] Business verification
- [x] Identity verification
- [x] Verification badges
- [x] Progress tracking
- [x] Expiry management

### Phase 3: Shipping & Logistics ✓
- [x] Shipping labels
- [x] Real-time tracking
- [x] Delivery confirmation
- [x] Return shipping
- [x] Shipping analytics

### Phase 4: Advertising Platform ✓
- [x] Ad campaigns
- [x] Campaign metrics
- [x] Quality scoring
- [x] Promotional offers
- [x] Featured listings
- [x] Sponsored search

---

## Integration Notes

### Store Integration

Update `lib/market/store.tsx` to include:

\`\`\`typescript
interface PersistShape {
  // ... existing fields
  escrows: EscrowTransaction[]
  disputes: Dispute[]
  buyerProtections: BuyerProtection[]
  sellerProtections: SellerProtection[]
  refunds: RefundRequest[]
  verifications: BusinessVerification[]
  identities: IdentityVerification[]
  shipments: Shipment[]
  campaigns: AdCampaign[]
  offers: PromotionalOffer[]
}
\`\`\`

### Component Usage

\`\`\`tsx
// Dispute Center
<DisputeCenter
  disputes={state.disputes}
  orders={orderMap}
  onCreateDispute={createDispute}
  onResolveDispute={resolveDispute}
  isAdmin={me.adminRole !== null}
/>

// Verification Dashboard
<VerificationDashboard
  businessVerification={myBusiness}
  identityVerification={myIdentity}
  badges={myBadges}
  onSubmitBusiness={submitVerification}
/>

// Shipping Tracker
<ShippingTracker
  shipments={myShipments}
  onDeliveryConfirmed={confirmDelivery}
/>

// Advertising Manager
<AdvertisingManager
  campaigns={myCampaigns}
  offers={myOffers}
  onCreateCampaign={createCampaign}
/>
\`\`\`

---

## Best Practices

1. **Escrow Safety**: Always use escrow for high-value transactions
2. **Dispute Evidence**: Require photo/document evidence for resolutions
3. **Verification**: Complete verification before premium features
4. **Shipping**: Update tracking status with location data
5. **Advertising**: Monitor ROI and adjust bids accordingly
6. **Trust**: Maintain >95% escrow release rate as seller

---

## Next Steps

1. Integrate all systems into main store
2. Create admin dashboard for moderation
3. Add analytics and reporting
4. Implement notifications for all events
5. Add multi-language support
6. Create mobile optimizations
7. Set up automated compliance checks
