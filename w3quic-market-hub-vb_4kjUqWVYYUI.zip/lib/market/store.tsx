"use client"

import React, { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react"
import type {
  Product, SellerStore, UserProfile, Order, OrderStatus, CartItem, Review,
  Message, Conversation, AppNotification, NotificationType, Report, AuditLog, Coupon, Category,
} from "./types"
import {
  CURRENT_USER_ID, SEED_PRODUCTS, SEED_SELLERS, SEED_STORES, SEED_REVIEWS, SEED_COUPONS, makeCurrentUser,
} from "./seed"
import { uid } from "./helpers"
import { computeReputation } from "./adapters"
import * as Intelligence from "./intelligence"

const KEY = "pi-market-hub-v1"

interface PersistShape {
  users: UserProfile[]
  products: Product[]
  stores: SellerStore[]
  orders: Order[]
  reviews: Review[]
  messages: Message[]
  conversations: Conversation[]
  notifications: AppNotification[]
  reports: Report[]
  auditLogs: AuditLog[]
  cart: CartItem[]
  wishlist: string[]
  recentlyViewed: string[]
  followedStores: string[]
  theme: "light" | "dark"
  recentSearches: string[]
  savedSearches: string[]
  viewDurationByProduct: Record<string, number>
}

function load(): PersistShape {
  if (typeof window !== "undefined") {
    try {
      const raw = localStorage.getItem(KEY)
      if (raw) return JSON.parse(raw)
    } catch {}
  }
  const me = makeCurrentUser()
  return {
    users: [me, ...SEED_SELLERS],
    products: SEED_PRODUCTS,
    stores: SEED_STORES,
    orders: [],
    reviews: SEED_REVIEWS,
    messages: [],
    conversations: [],
    notifications: [
      { id: uid("n"), userId: CURRENT_USER_ID, type: "flash", title: "Flash Deal Started", body: "25% off Pi Phone X — ends soon!", at: Date.now() - 3600000, read: false, link: "p-phone" },
      { id: uid("n"), userId: CURRENT_USER_ID, type: "announcement", title: "TechHub Pi", body: "Summer Tech Sale: up to 30% off!", at: Date.now() - 7200000, read: false },
    ],
    reports: [],
    auditLogs: [],
    cart: [],
    wishlist: ["p-jacket"],
    recentlyViewed: [],
    followedStores: ["seller-techhub"],
    theme: "light",
    recentSearches: [],
    savedSearches: [],
    viewDurationByProduct: {},
  }
}

interface StoreCtx extends PersistShape {
  me: UserProfile
  // products
  getProduct: (id: string) => Product | undefined
  getSeller: (id: string) => UserProfile | undefined
  getStore: (id: string) => SellerStore | undefined
  addProduct: (p: Partial<Product>) => Product
  updateProduct: (id: string, patch: Partial<Product>) => void
  removeProduct: (id: string) => void
  recordView: (id: string) => void
  // cart / wishlist
  addToCart: (productId: string, variationId?: string, qty?: number) => void
  removeFromCart: (productId: string, variationId?: string) => void
  updateCartQty: (productId: string, variationId: string | undefined, qty: number) => void
  clearCart: () => void
  toggleWishlist: (id: string) => void
  // checkout
  reserveProduct: (id: string) => void
  placeOrder: (o: Omit<Order, "id" | "createdAt" | "timeline" | "escrowStatus" | "status" | "reviewed">) => Order
  advanceOrder: (id: string, status: OrderStatus) => void
  openDispute: (id: string, reason: string, msg: string) => void
  respondDispute: (id: string, msg: string) => void
  resolveDispute: (id: string, resolution: string, refund: boolean) => void
  // reviews
  addReview: (r: Omit<Review, "id" | "createdAt">) => void
  // messaging
  getOrCreateConversation: (sellerId: string, productId?: string) => string
  sendMessage: (conversationId: string, text: string, offer?: Message["offer"]) => void
  respondOffer: (messageId: string, action: "accept" | "reject" | "counter", counterAmount?: number) => void
  // notifications
  notify: (userId: string, type: NotificationType, title: string, body: string, link?: string) => void
  markNotificationRead: (id: string) => void
  markAllRead: () => void
  // social
  toggleFavoriteSeller: (id: string) => void
  toggleFollowStore: (id: string) => void
  updateStore: (id: string, patch: Partial<SellerStore>) => void
  // reports / admin
  addReport: (r: Omit<Report, "id" | "at" | "status">) => void
  updateReport: (id: string, status: Report["status"]) => void
  audit: (action: string, target: string, before?: string, after?: string) => void
  banUser: (id: string) => void
  setAdminRole: (id: string, role: UserProfile["adminRole"]) => void
  // profile
  updateMe: (patch: Partial<UserProfile>) => void
  updateProfile: (patch: Partial<UserProfile>) => void
  updateUser: (id: string, patch: Partial<UserProfile>) => void
  becomeSeller: (storeName: string) => void
  addLoyalty: (n: number) => void
  spendLoyalty: (n: number) => void
  claimDailyReward: () => number
  // products (extended)
  createProduct: (data: any) => Product
  suggestPrice: (category: string) => { min: number; max: number } | null
  // social
  favoriteSellers: string[]
  // coupons
  coupons: Coupon[]
  // theme
  toggleTheme: () => void
  exportData: () => string
  importData: (json: string) => boolean
  // intelligence & discovery
  getTrendingProducts: () => Product[]
  getTrendingCategories: () => any[]
  getProductRecommendations: () => Product[]
  getSimilarProducts: (id: string) => Product[]
  getBetterValueSuggestions: (id: string) => Product[]
  getRecentlyPriceDropped: () => Product[]
  getRecentlyRestocked: () => Product[]
  getSearchSuggestions: (query: string) => any[]
  performSmartSearch: (context: any) => Product[]
  buildComparisonTable: (ids: string[]) => any[]
  getLocalProducts: (location: string) => Product[]
  getVerifiedBusinesses: () => UserProfile[]
  getMarketplaceInsights: () => any
  addSearch: (query: string) => void
  saveSearch: (query: string) => void
  removeSearch: (query: string) => void
}

const Ctx = createContext<StoreCtx | undefined>(undefined)

export function MarketStoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistShape>(() => load())
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => { setHydrated(true) }, [])

  useEffect(() => {
    if (!hydrated) return
    try { localStorage.setItem(KEY, JSON.stringify(state)) } catch {}
  }, [state, hydrated])

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.classList.toggle("dark", state.theme === "dark")
    }
  }, [state.theme])

  const me = state.users.find((u) => u.id === CURRENT_USER_ID) || state.users[0]

  const patch = useCallback((fn: (s: PersistShape) => PersistShape) => {
    setState((s) => fn({ ...s }))
  }, [])

  const getProduct = useCallback((id: string) => state.products.find((p) => p.id === id), [state.products])
  const getSeller = useCallback((id: string) => state.users.find((u) => u.id === id), [state.users])
  const getStore = useCallback((id: string) => state.stores.find((s) => s.sellerId === id), [state.stores])

  const notify = useCallback((userId: string, type: NotificationType, title: string, body: string, link?: string) => {
    patch((s) => ({ ...s, notifications: [{ id: uid("n"), userId, type, title, body, at: Date.now(), read: false, link }, ...s.notifications] }))
  }, [patch])

  const value: StoreCtx = {
    ...state,
    me,
    coupons: SEED_COUPONS,
    getProduct, getSeller, getStore,

    addProduct: (p) => {
      const product: Product = {
        id: uid("p-"), sellerId: CURRENT_USER_ID, title: "", description: "", price: 0,
        category: "other", condition: "new", variations: [], stock: 1, location: "", images: [],
        deliveryOptions: ["Standard"], createdAt: Date.now(), updatedAt: Date.now(), views: 0,
        featured: false, sponsored: false, scamScore: 0, handlingTimeDays: 2, ...p,
      }
      patch((s) => ({ ...s, products: [product, ...s.products] }))
      return product
    },
    updateProduct: (id, p) => patch((s) => ({ ...s, products: s.products.map((x) => x.id === id ? { ...x, ...p, updatedAt: Date.now() } : x) })),
    removeProduct: (id) => patch((s) => ({ ...s, products: s.products.filter((x) => x.id !== id) })),
    recordView: (id) => patch((s) => ({
      ...s,
      products: s.products.map((x) => x.id === id ? { ...x, views: x.views + 1 } : x),
      recentlyViewed: [id, ...s.recentlyViewed.filter((r) => r !== id)].slice(0, 20),
    })),

    addToCart: (productId, variationId, qty = 1) => patch((s) => {
      const existing = s.cart.find((c) => c.productId === productId && c.variationId === variationId)
      if (existing) return { ...s, cart: s.cart.map((c) => c === existing ? { ...c, quantity: c.quantity + qty } : c) }
      return { ...s, cart: [...s.cart, { productId, variationId, quantity: qty }] }
    }),
    removeFromCart: (productId, variationId) => patch((s) => ({ ...s, cart: s.cart.filter((c) => !(c.productId === productId && c.variationId === variationId)) })),
    updateCartQty: (productId, variationId, qty) => patch((s) => ({ ...s, cart: s.cart.map((c) => c.productId === productId && c.variationId === variationId ? { ...c, quantity: Math.max(1, qty) } : c) })),
    clearCart: () => patch((s) => ({ ...s, cart: [] })),
    toggleWishlist: (id) => patch((s) => ({ ...s, wishlist: s.wishlist.includes(id) ? s.wishlist.filter((w) => w !== id) : [...s.wishlist, id] })),

    reserveProduct: (id) => patch((s) => ({ ...s, products: s.products.map((p) => p.id === id ? { ...p, reservedUntil: Date.now() + 15 * 60000, reservedBy: CURRENT_USER_ID } : p) })),

    placeOrder: (o) => {
      const order: Order = {
        ...o, id: uid("o-"), createdAt: Date.now(), status: "placed", escrowStatus: "held",
        timeline: [{ status: "placed", at: Date.now() }], reviewed: false,
      }
      patch((s) => ({
        ...s,
        orders: [order, ...s.orders],
        cart: [],
        products: s.products.map((p) => {
          const item = o.items.find((i) => i.productId === p.id)
          if (!item) return p
          const stock = Math.max(0, p.stock - item.quantity)
          return { ...p, stock, reservedUntil: undefined, reservedBy: undefined }
        }),
      }))
      notify(o.sellerId, "order", "New Order", `You received a new order worth ${o.total} π.`, order.id)
      return order
    },
    advanceOrder: (id, status) => patch((s) => ({
      ...s,
      orders: s.orders.map((o) => {
        if (o.id !== id) return o
        const escrowStatus = status === "completed" ? "released" : o.escrowStatus
        return { ...o, status, escrowStatus, timeline: [...o.timeline, { status, at: Date.now() }] }
      }),
    })),
    openDispute: (id, reason, msg) => {
      patch((s) => ({ ...s, orders: s.orders.map((o) => o.id === id ? { ...o, status: "disputed", dispute: { reason, buyerMsg: msg, status: "open" } } : o) }))
      const order = state.orders.find((o) => o.id === id)
      if (order) notify(order.sellerId, "dispute", "Dispute Opened", "A buyer opened a dispute on an order.", id)
    },
    respondDispute: (id, msg) => patch((s) => ({ ...s, orders: s.orders.map((o) => o.id === id && o.dispute ? { ...o, dispute: { ...o.dispute, sellerMsg: msg } } : o) })),
    resolveDispute: (id, resolution, refund) => patch((s) => ({
      ...s,
      orders: s.orders.map((o) => o.id === id && o.dispute ? {
        ...o, status: refund ? "cancelled" : "completed",
        escrowStatus: refund ? "refunded" : "released",
        dispute: { ...o.dispute, resolution, status: "resolved" },
      } : o),
    })),

    addReview: (r) => {
      patch((s) => {
        const review: Review = { ...r, id: uid("r"), createdAt: Date.now() }
        // recompute seller rating
        const sellerReviews = [...s.reviews.filter((x) => x.sellerId === r.sellerId), review]
        const avg = sellerReviews.reduce((a, b) => a + b.rating, 0) / sellerReviews.length
        return {
          ...s,
          reviews: [review, ...s.reviews],
          orders: s.orders.map((o) => o.items.some((i) => i.productId === r.productId) && o.buyerId === r.buyerId ? { ...o, reviewed: true } : o),
          users: s.users.map((u) => {
            if (u.id !== r.sellerId) return u
            const rep = computeReputation({ rating: avg, totalTransactions: u.totalTransactions, responseTimeMins: u.responseTimeMins, disputesResolved: u.disputesResolved })
            return { ...u, rating: Math.round(avg * 10) / 10, ratingCount: sellerReviews.length, reputationScore: rep }
          }),
        }
      })
      notify(r.sellerId, "review", "New Review", `You received a ${r.rating}-star review.`)
    },

    getOrCreateConversation: (sellerId, productId) => {
      const existing = state.conversations.find((c) => c.sellerId === sellerId && c.buyerId === CURRENT_USER_ID)
      if (existing) return existing.id
      const id = uid("c")
      patch((s) => ({ ...s, conversations: [{ id, buyerId: CURRENT_USER_ID, sellerId, productId, lastMessageAt: Date.now() }, ...s.conversations] }))
      return id
    },
    sendMessage: (conversationId, text, offer) => {
      patch((s) => ({
        ...s,
        messages: [...s.messages, { id: uid("m"), conversationId, senderId: CURRENT_USER_ID, text, at: Date.now(), offer }],
        conversations: s.conversations.map((c) => c.id === conversationId ? { ...c, lastMessageAt: Date.now() } : c),
      }))
      const conv = state.conversations.find((c) => c.id === conversationId)
      if (conv) {
        if (offer) notify(conv.sellerId, "offer", "New Offer", `A buyer offered ${offer.amount} π.`)
        else notify(conv.sellerId, "message", "New Message", text.slice(0, 50))
      }
    },
    respondOffer: (messageId, action, counterAmount) => patch((s) => ({
      ...s,
      messages: s.messages.map((m) => {
        if (m.id !== messageId || !m.offer) return m
        if (action === "accept") return { ...m, offer: { ...m.offer, status: "accepted" } }
        if (action === "reject") return { ...m, offer: { ...m.offer, status: "rejected" } }
        return { ...m, offer: { ...m.offer, status: "countered", amount: counterAmount ?? m.offer.amount, round: m.offer.round + 1 } }
      }),
    })),

    notify,
    markNotificationRead: (id) => patch((s) => ({ ...s, notifications: s.notifications.map((n) => n.id === id ? { ...n, read: true } : n) })),
    markAllRead: () => patch((s) => ({ ...s, notifications: s.notifications.map((n) => n.userId === CURRENT_USER_ID ? { ...n, read: true } : n) })),

    toggleFavoriteSeller: (id) => patch((s) => ({
      ...s, users: s.users.map((u) => u.id === CURRENT_USER_ID ? { ...u, favoriteSellers: u.favoriteSellers.includes(id) ? u.favoriteSellers.filter((f) => f !== id) : [...u.favoriteSellers, id] } : u),
    })),
    toggleFollowStore: (id) => patch((s) => {
      const following = s.followedStores.includes(id)
      return {
        ...s,
        followedStores: following ? s.followedStores.filter((f) => f !== id) : [...s.followedStores, id],
        stores: s.stores.map((st) => st.sellerId === id ? { ...st, followers: following ? st.followers.filter((f) => f !== CURRENT_USER_ID) : [...st.followers, CURRENT_USER_ID] } : st),
      }
    }),
    updateStore: (id, p) => patch((s) => ({ ...s, stores: s.stores.map((st) => st.sellerId === id ? { ...st, ...p } : st) })),

    addReport: (r) => patch((s) => ({ ...s, reports: [{ ...r, id: uid("rep"), at: Date.now(), status: "pending" }, ...s.reports] })),
    updateReport: (id, status) => patch((s) => ({ ...s, reports: s.reports.map((r) => r.id === id ? { ...r, status } : r) })),
    audit: (action, target, before, after) => patch((s) => ({ ...s, auditLogs: [{ id: uid("a"), adminId: CURRENT_USER_ID, action, target, before, after, at: Date.now() }, ...s.auditLogs] })),
    banUser: (id) => patch((s) => ({ ...s, users: s.users.map((u) => u.id === id ? { ...u, verification: "none", reputationScore: 0 } : u) })),
    setAdminRole: (id, role) => patch((s) => ({ ...s, users: s.users.map((u) => u.id === id ? { ...u, adminRole: role } : u) })),

    updateMe: (p) => patch((s) => ({ ...s, users: s.users.map((u) => u.id === CURRENT_USER_ID ? { ...u, ...p } : u) })),
    becomeSeller: (storeName) => patch((s) => ({
      ...s,
      users: s.users.map((u) => u.id === CURRENT_USER_ID ? { ...u, isSeller: true } : u),
      stores: s.stores.some((st) => st.sellerId === CURRENT_USER_ID) ? s.stores : [...s.stores, { sellerId: CURRENT_USER_ID, storeName, description: "Welcome to my store!", categories: [], followers: [], views: 0 }],
    })),
    addLoyalty: (n) => patch((s) => ({ ...s, users: s.users.map((u) => u.id === CURRENT_USER_ID ? { ...u, loyaltyPoints: u.loyaltyPoints + n } : u) })),
    spendLoyalty: (n) => patch((s) => ({ ...s, users: s.users.map((u) => u.id === CURRENT_USER_ID ? { ...u, loyaltyPoints: Math.max(0, u.loyaltyPoints - n) } : u) })),
    claimDailyReward: () => {
      const today = new Date().toDateString()
      const last = me.lastLogin ? new Date(me.lastLogin).toDateString() : null
      if (last === today) return 0
      const yesterday = new Date(Date.now() - 86400000).toDateString()
      const streak = last === yesterday ? Math.min(7, me.loginStreak + 1) : 1
      const reward = streak
      patch((s) => ({ ...s, users: s.users.map((u) => u.id === CURRENT_USER_ID ? { ...u, loyaltyPoints: u.loyaltyPoints + reward, lastLogin: Date.now(), loginStreak: streak } : u) }))
      return reward
    },

    toggleTheme: () => patch((s) => ({ ...s, theme: s.theme === "dark" ? "light" : "dark" })),
    exportData: () => JSON.stringify(state, null, 2),
    importData: (json) => {
      try { const parsed = JSON.parse(json); setState(parsed); return true } catch { return false }
    },

    // Intelligence & Discovery Methods
    getTrendingProducts: () => {
      const { getTrendingProducts } = require("./intelligence")
      return getTrendingProducts(state.products, 12)
    },
    getTrendingCategories: () => {
      const { getTrendingCategories } = require("./intelligence")
      return getTrendingCategories(state.products, 5)
    },
    getProductRecommendations: () => {
      const { getProductRecommendations } = require("./intelligence")
      const context = {
        userId: CURRENT_USER_ID,
        recentViews: state.recentlyViewed,
        wishlist: state.wishlist,
        purchaseHistory: state.orders.flatMap((o) => o.items.map((i) => i.productId)),
        browseCategoryFreq: { electronics: 3, fashion: 2, home: 1, services: 0, vehicles: 0, food: 0, sports: 0, books: 0, toys: 0, other: 0 },
        viewDurationByProduct: state.viewDurationByProduct,
        priceRangePreference: { min: 10, max: 500 },
      }
      return getProductRecommendations(context, state.products, 10)
    },
    getSimilarProducts: (id) => {
      const { getSimilarProducts } = require("./intelligence")
      return getSimilarProducts(id, state.products, 8)
    },
    getBetterValueSuggestions: (id) => {
      const { getBetterValueSuggestions } = require("./intelligence")
      return getBetterValueSuggestions(id, state.products, 5)
    },
    getRecentlyPriceDropped: () => {
      const { getRecentlyPriceDropped } = require("./intelligence")
      return getRecentlyPriceDropped(state.products, 8)
    },
    getRecentlyRestocked: () => {
      const { getRecentlyRestocked } = require("./intelligence")
      return getRecentlyRestocked(state.products, 8)
    },
    getSearchSuggestions: (query) => {
      const { generateSearchSuggestions } = require("./intelligence")
      return generateSearchSuggestions(query, state.products, state.recentSearches, 8)
    },
    performSmartSearch: (context) => {
      const { performSmartSearch } = require("./intelligence")
      return performSmartSearch(context, state.products)
    },
    buildComparisonTable: (ids) => {
      const { buildComparisonTable } = require("./intelligence")
      return buildComparisonTable(ids, state.products)
    },
    getLocalProducts: (location) => {
      const { getLocalProducts } = require("./intelligence")
      return getLocalProducts(state.products, location, 50)
    },
    getVerifiedBusinesses: () => {
      const { getVerifiedBusinesses } = require("./intelligence")
      return getVerifiedBusinesses(state.users)
    },
    getMarketplaceInsights: () => {
      const { computeBuyerInsights, computeSellerInsights } = require("./intelligence")
      return {
        buyer: computeBuyerInsights(state.orders, state.products),
        seller: computeSellerInsights(CURRENT_USER_ID, state.orders, state.products),
      }
    },
    addSearch: (query) => patch((s) => ({
      ...s,
      recentSearches: [query, ...s.recentSearches.filter((q) => q !== query)].slice(0, 10),
    })),
    saveSearch: (query) => patch((s) => ({
      ...s,
      savedSearches: s.savedSearches.includes(query) ? s.savedSearches : [...s.savedSearches, query],
    })),
    removeSearch: (query) => patch((s) => ({
      ...s,
      savedSearches: s.savedSearches.filter((q) => q !== query),
    })),
  }

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useMarket() {
  const c = useContext(Ctx)
  if (!c) throw new Error("useMarket must be used within MarketStoreProvider")
  return c
}
