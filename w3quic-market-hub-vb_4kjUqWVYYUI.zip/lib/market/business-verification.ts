import type {
  BusinessVerification, IdentityVerification, VerificationDocument, VerificationDocumentType,
  VerificationStatus, VerificationBadgeType,
} from "./types"
import { uid } from "./helpers"

/**
 * BUSINESS VERIFICATION SYSTEM
 * Verifies business legitimacy and provides trusted badges
 */

export function createBusinessVerification(
  userId: string,
  businessName: string,
  registrationNumber: string,
  businessType: "sole-proprietor" | "partnership" | "corporation" | "llc" | "other"
): BusinessVerification {
  return {
    userId,
    businessName,
    registrationNumber,
    businessType,
    documents: [],
    status: "pending",
  }
}

export function addVerificationDocument(
  verification: BusinessVerification,
  type: VerificationDocumentType,
  fileUrl: string,
  expiresAt?: number
): BusinessVerification {
  const document: VerificationDocument = {
    id: uid("doc"),
    userId: verification.userId,
    type,
    fileUrl,
    uploadedAt: Date.now(),
    expiresAt,
    status: "pending",
  }

  return {
    ...verification,
    documents: [...verification.documents, document],
  }
}

export function approveDocument(
  verification: BusinessVerification,
  documentId: string,
  adminId: string
): BusinessVerification {
  return {
    ...verification,
    documents: verification.documents.map(doc =>
      doc.id === documentId
        ? { ...doc, status: "approved" as VerificationStatus, uploadedAt: Date.now() }
        : doc
    ),
  }
}

export function rejectDocument(
  verification: BusinessVerification,
  documentId: string,
  rejectionReason: string
): BusinessVerification {
  return {
    ...verification,
    documents: verification.documents.map(doc =>
      doc.id === documentId
        ? { ...doc, status: "rejected" as VerificationStatus, rejectionReason }
        : doc
    ),
  }
}

export function approveBusinessVerification(
  verification: BusinessVerification,
  adminId: string,
  validityDays: number = 365
): BusinessVerification {
  // Check if all required documents are approved
  const requiredDocTypes: VerificationDocumentType[] =
    verification.businessType === "sole-proprietor"
      ? ["identity-document", "address-proof"]
      : ["business-license", "tax-id", "incorporation-cert"]

  const hasAllRequired = requiredDocTypes.every(type =>
    verification.documents.some(d => d.type === type && d.status === "approved")
  )

  if (!hasAllRequired) {
    throw new Error("Not all required documents are approved")
  }

  return {
    ...verification,
    status: "approved",
    verifiedAt: Date.now(),
    approvedBy: adminId,
    expiresAt: Date.now() + validityDays * 24 * 60 * 60 * 1000,
  }
}

export function rejectBusinessVerification(
  verification: BusinessVerification,
  reason: string
): BusinessVerification {
  return {
    ...verification,
    status: "rejected",
  }
}

/**
 * IDENTITY VERIFICATION
 * Verifies individual identity with document and biometric checks
 */

export function createIdentityVerification(
  userId: string,
  documentType: "passport" | "national-id" | "driver-license" | "visa",
  documentNumber: string,
  documentUrl: string
): IdentityVerification {
  return {
    userId,
    documentType,
    documentNumber,
    documentUrl,
    uploadedAt: Date.now(),
    status: "pending",
  }
}

export function addFaceVerification(
  verification: IdentityVerification,
  faceVerificationUrl: string
): IdentityVerification {
  return {
    ...verification,
    faceVerificationUrl,
  }
}

export function approveIdentityVerification(
  verification: IdentityVerification,
  adminId: string,
  validityDays: number = 1095 // 3 years
): IdentityVerification {
  return {
    ...verification,
    status: "approved",
    verifiedAt: Date.now(),
    approvedBy: adminId,
    expiresAt: Date.now() + validityDays * 24 * 60 * 60 * 1000,
  }
}

export function rejectIdentityVerification(
  verification: IdentityVerification,
  reason: string
): IdentityVerification {
  return {
    ...verification,
    status: "rejected",
  }
}

/**
 * VERIFICATION BADGES
 * Determine which badges a user qualifies for
 */

export interface VerificationBadgeInfo {
  id: VerificationBadgeType
  label: string
  icon: string
  description: string
  requirements: string[]
}

export const VERIFICATION_BADGES: Record<VerificationBadgeType, VerificationBadgeInfo> = {
  "email-verified": {
    id: "email-verified",
    label: "Email Verified",
    icon: "Mail",
    description: "Email address verified",
    requirements: ["email-confirmed"],
  },
  "identity-verified": {
    id: "identity-verified",
    label: "Identity Verified",
    icon: "CheckCircle",
    description: "Identity verified through document",
    requirements: ["identity-verification-approved"],
  },
  "business-verified": {
    id: "business-verified",
    label: "Business Verified",
    icon: "Building",
    description: "Business registration verified",
    requirements: ["business-verification-approved"],
  },
  "high-volume-seller": {
    id: "high-volume-seller",
    label: "High Volume Seller",
    icon: "TrendingUp",
    description: "Over 1000 completed transactions",
    requirements: ["1000-transactions"],
  },
  "trusted-seller": {
    id: "trusted-seller",
    label: "Trusted Seller",
    icon: "Award",
    description: "Rating above 4.8 with low dispute rate",
    requirements: ["4.8-rating", "low-dispute-rate"],
  },
  "premium-seller": {
    id: "premium-seller",
    label: "Premium Seller",
    icon: "Crown",
    description: "Premium subscription holder",
    requirements: ["premium-subscription"],
  },
  "eco-friendly": {
    id: "eco-friendly",
    label: "Eco-Friendly",
    icon: "Leaf",
    description: "Commitment to sustainable practices",
    requirements: ["eco-certification"],
  },
}

export function getEligibleBadges(
  isEmailVerified: boolean,
  isIdentityVerified: boolean,
  isBusinessVerified: boolean,
  transactionCount: number,
  rating: number,
  disputeRate: number,
  isPremium: boolean,
  isEcoFriendly: boolean
): VerificationBadgeType[] {
  const badges: VerificationBadgeType[] = []

  if (isEmailVerified) badges.push("email-verified")
  if (isIdentityVerified) badges.push("identity-verified")
  if (isBusinessVerified) badges.push("business-verified")
  if (transactionCount >= 1000) badges.push("high-volume-seller")
  if (rating >= 4.8 && disputeRate < 5) badges.push("trusted-seller")
  if (isPremium) badges.push("premium-seller")
  if (isEcoFriendly) badges.push("eco-friendly")

  return badges
}

/**
 * VERIFICATION STATUS & TRACKING
 */

export interface VerificationProgress {
  emailVerified: boolean
  identityVerified: boolean
  identityVerificationStatus: VerificationStatus
  businessVerified: boolean
  businessVerificationStatus: VerificationStatus
  allDocumentsSubmitted: boolean
  overallProgress: number // 0-100
  estimatedApprovalTime: string
}

export function calculateVerificationProgress(
  isEmailVerified: boolean,
  identityStatus: VerificationStatus | null,
  businessStatus: VerificationStatus | null,
  documentsCount: number
): VerificationProgress {
  let progress = 0

  if (isEmailVerified) progress += 20
  if (identityStatus === "approved") progress += 40
  else if (identityStatus === "pending") progress += 20
  if (businessStatus === "approved") progress += 40
  else if (businessStatus === "pending") progress += 20

  return {
    emailVerified: isEmailVerified,
    identityVerified: identityStatus === "approved",
    identityVerificationStatus: identityStatus || "pending",
    businessVerified: businessStatus === "approved",
    businessVerificationStatus: businessStatus || "pending",
    allDocumentsSubmitted: documentsCount >= 3,
    overallProgress: Math.min(100, progress),
    estimatedApprovalTime: businessStatus === "pending" ? "3-5 business days" : "Completed",
  }
}

/**
 * VERIFICATION EXPIRY & RENEWAL
 */

export function isVerificationExpired(expiresAt?: number): boolean {
  if (!expiresAt) return false
  return Date.now() > expiresAt
}

export function getDaysUntilExpiry(expiresAt?: number): number | null {
  if (!expiresAt) return null
  const daysLeft = Math.ceil((expiresAt - Date.now()) / (24 * 60 * 60 * 1000))
  return Math.max(0, daysLeft)
}

export function needsRenewal(expiresAt?: number): boolean {
  const daysLeft = getDaysUntilExpiry(expiresAt)
  return daysLeft !== null && daysLeft <= 30 // Remind 30 days before expiry
}

/**
 * VERIFICATION NOTIFICATIONS
 */

export function getVerificationNotifications(progress: VerificationProgress): string[] {
  const notifications: string[] = []

  if (!progress.emailVerified) {
    notifications.push("Please verify your email address")
  }
  if (!progress.identityVerified && progress.identityVerificationStatus === "pending") {
    notifications.push("Your identity verification is being reviewed")
  }
  if (!progress.businessVerified && progress.businessVerificationStatus === "pending") {
    notifications.push("Your business verification is being reviewed")
  }
  if (progress.overallProgress === 100) {
    notifications.push("All verifications complete! You're fully trusted on Pi Market Hub")
  }

  return notifications
}
