import type {
  MarketplaceAnalytics,
  AdminAuditLog,
  SellerManagementAction,
  ProductModerationQueue,
  VerificationApprovalQueue,
  SystemMetrics,
  UserProfile,
  Order,
  Product,
  FraudDetection,
} from "./types"
import { uid } from "./helpers"

export class AdminCenter {
  // Analytics Dashboard
  static generateMarketplaceAnalytics(
    users: UserProfile[],
    orders: Order[],
    products: Product[],
  ): MarketplaceAnalytics {
    const today = new Date().toISOString().split("T")[0]
    const last30Days = Date.now() - 30 * 24 * 60 * 60 * 1000
    const last7Days = Date.now() - 7 * 24 * 60 * 60 * 1000

    // Total users
    const totalUsers = users.length
    const activeUsers = users.filter((u) => u.lastLogin && u.lastLogin > last30Days).length

    // Orders
    const totalOrders = orders.length
    const recentOrders = orders.filter((o) => o.createdAt > last30Days)
    const recentOrderCount = recentOrders.length

    // Revenue (in Pi)
    const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0)
    const recentRevenue = recentOrders.reduce((sum, o) => sum + o.total, 0)
    const averageOrderValue =
      recentOrderCount > 0 ? recentRevenue / recentOrderCount : 0

    // Conversion rate (users who made at least 1 order)
    const buyerCount = new Set(orders.map((o) => o.buyerId)).size
    const conversionRate = totalUsers > 0 ? (buyerCount / totalUsers) * 100 : 0

    // Top categories
    const categoryCount = new Map<string, number>()
    for (const order of recentOrders) {
      for (const item of order.items) {
        const product = products.find((p) => p.id === item.productId)
        if (product) {
          const count = categoryCount.get(product.category) || 0
          categoryCount.set(product.category, count + 1)
        }
      }
    }

    const topCategories = Array.from(categoryCount.entries())
      .map(([category, count]) => ({ category: category as any, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5)

    // Top sellers
    const sellerSales = new Map<string, number>()
    for (const order of recentOrders) {
      const count = sellerSales.get(order.sellerId) || 0
      sellerSales.set(order.sellerId, count + 1)
    }

    const topSellers = Array.from(sellerSales.entries())
      .map(([id, sales]) => ({ id, sales }))
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 10)

    // Retention
    const prev30Days = new Set(
      users.filter((u) => u.lastLogin && u.lastLogin > last30Days).map((u) => u.id),
    )
    const prev7Days = new Set(
      users.filter((u) => u.lastLogin && u.lastLogin > last7Days).map((u) => u.id),
    )
    const retained = [...prev7Days].filter((id) => prev30Days.has(id)).length
    const userRetention = prev30Days.size > 0 ? (retained / prev30Days.size) * 100 : 0

    // New users
    const newUsers = users.filter((u) => u.joinedAt > last30Days).length
    const churned = prev30Days.size - retained

    return {
      date: today,
      totalUsers,
      activeUsers,
      totalOrders,
      totalRevenue,
      averageOrderValue,
      conversionRate,
      topCategories,
      topSellers,
      userRetention,
      newUsers,
      churned,
    }
  }

  // Audit Logging
  static logAction(
    adminId: string,
    action: string,
    targetType: string,
    targetId: string,
    changes: Record<string, any> = {},
    ipAddress?: string,
  ): AdminAuditLog {
    return {
      id: uid("audit"),
      adminId,
      action,
      targetType,
      targetId,
      changes,
      timestamp: Date.now(),
      ipAddress,
    }
  }

  // Seller Management
  static suspendSeller(
    sellerId: string,
    adminId: string,
    reason: string,
    durationDays: number = 30,
  ): SellerManagementAction {
    return {
      id: uid("mgmt"),
      sellerId,
      adminId,
      action: "suspend",
      reason,
      duration: durationDays,
      appliedAt: Date.now(),
      expiresAt: Date.now() + durationDays * 24 * 60 * 60 * 1000,
    }
  }

  static restrictSeller(
    sellerId: string,
    adminId: string,
    reason: string,
  ): SellerManagementAction {
    return {
      id: uid("mgmt"),
      sellerId,
      adminId,
      action: "restrict",
      reason,
      appliedAt: Date.now(),
    }
  }

  static reinstateS eller(
    sellerId: string,
    adminId: string,
  ): SellerManagementAction {
    return {
      id: uid("mgmt"),
      sellerId,
      adminId,
      action: "reinstate",
      reason: "Appeals approved or period ended",
      appliedAt: Date.now(),
    }
  }

  static warnSeller(
    sellerId: string,
    adminId: string,
    reason: string,
  ): SellerManagementAction {
    return {
      id: uid("mgmt"),
      sellerId,
      adminId,
      action: "warn",
      reason,
      appliedAt: Date.now(),
    }
  }

  // Product Moderation
  static addToModerationQueue(
    productId: string,
    reason: string,
  ): ProductModerationQueue {
    return {
      id: uid("mod"),
      productId,
      reason,
      submittedAt: Date.now(),
      status: "pending",
    }
  }

  static approveProduct(
    queueId: string,
    adminId: string,
  ): ProductModerationQueue {
    return {
      id: queueId,
      productId: "", // filled from existing
      reason: "", // filled from existing
      submittedAt: 0, // filled from existing
      status: "approved",
      reviewedAt: Date.now(),
    } as any
  }

  static rejectProduct(
    queueId: string,
    adminId: string,
    decision: string,
  ): ProductModerationQueue {
    return {
      id: queueId,
      productId: "", // filled from existing
      reason: "", // filled from existing
      submittedAt: 0, // filled from existing
      status: "rejected",
      reviewedAt: Date.now(),
      decision,
    } as any
  }

  // Verification Approvals
  static approveVerification(
    queueId: string,
    adminId: string,
  ): VerificationApprovalQueue {
    return {
      id: queueId,
      userId: "",
      type: "business",
      documents: [],
      submittedAt: 0,
      status: "approved",
      reviewedAt: Date.now(),
      approvedBy: adminId,
    } as any
  }

  static rejectVerification(
    queueId: string,
    adminId: string,
    notes: string,
  ): VerificationApprovalQueue {
    return {
      id: queueId,
      userId: "",
      type: "business",
      documents: [],
      submittedAt: 0,
      status: "rejected",
      reviewedAt: Date.now(),
      notes,
    } as any
  }

  // Fraud Monitoring
  static flagSuspiciousUser(
    userId: string,
    fraud: FraudDetection,
    adminId?: string,
  ): FraudDetection {
    return {
      ...fraud,
      adminId,
    }
  }

  static resolveFraudCase(
    fraudId: string,
    resolution: "approved" | "blocked" | "reviewed",
    adminId: string,
  ): FraudDetection {
    return {
      id: fraudId,
      entityType: "user",
      entityId: "",
      suspicionLevel: "low",
      flags: [],
      createdAt: 0,
      resolvedAt: Date.now(),
      resolution,
      adminId,
    } as any
  }

  // System Health Monitoring
  static getSystemMetrics(): SystemMetrics {
    // Simulated metrics
    return {
      timestamp: Date.now(),
      apiLatency: Math.random() * 100, // ms
      dbLatency: Math.random() * 50, // ms
      errorRate: Math.random() * 0.01, // percentage
      activeConnections: Math.floor(Math.random() * 1000) + 100,
      memoryUsage: Math.random() * 80 + 20, // percentage
      cpuUsage: Math.random() * 60 + 20, // percentage
      uptime: 99.99, // percentage
    }
  }

  // Dashboard Alerts
  static generateAlerts(
    analytics: MarketplaceAnalytics,
    metrics: SystemMetrics,
    fraudCases: FraudDetection[],
  ): string[] {
    const alerts: string[] = []

    // Performance alerts
    if (metrics.apiLatency > 200) {
      alerts.push("API latency exceeds 200ms")
    }
    if (metrics.errorRate > 0.05) {
      alerts.push("Error rate above 5%")
    }
    if (metrics.cpuUsage > 80) {
      alerts.push("CPU usage above 80%")
    }

    // Business alerts
    if (analytics.churned > analytics.newUsers) {
      alerts.push("Churn rate exceeds new user acquisition")
    }
    if (analytics.conversionRate < 2) {
      alerts.push("Conversion rate below 2%")
    }

    // Security alerts
    const criticalFraud = fraudCases.filter((f) => f.suspicionLevel === "critical")
    if (criticalFraud.length > 0) {
      alerts.push(`${criticalFraud.length} critical fraud cases detected`)
    }

    return alerts
  }
}

// Admin roles and permissions
export const ADMIN_PERMISSIONS = {
  super: [
    "user-management",
    "seller-management",
    "product-moderation",
    "verification-approvals",
    "fraud-monitoring",
    "system-settings",
    "analytics",
  ],
  moderator: ["product-moderation", "seller-management", "user-warnings", "analytics"],
  analyst: ["analytics", "fraud-monitoring", "reporting"],
}
