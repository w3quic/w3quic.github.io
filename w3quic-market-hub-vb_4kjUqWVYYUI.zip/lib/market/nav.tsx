"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type View =
  | { name: "home" }
  | { name: "browse"; category?: string; query?: string; filter?: string }
  | { name: "product"; id: string }
  | { name: "cart" }
  | { name: "wishlist" }
  | { name: "checkout" }
  | { name: "orders" }
  | { name: "order"; id: string }
  | { name: "messages"; conversationId?: string }
  | { name: "notifications" }
  | { name: "profile" }
  | { name: "settings" }
  | { name: "subscription" }
  | { name: "store"; sellerId: string }
  | { name: "seller" }
  | { name: "create-listing"; editId?: string }
  | { name: "loyalty" }
  | { name: "admin" }
  | { name: "auctions" }
  | { name: "flash" }
  | { name: "real-estate" }
  | { name: "vehicle-marketplace" }

interface NavCtx {
  view: View
  go: (v: View) => void
  back: () => void
  tab: string
}

const Ctx = createContext<NavCtx | undefined>(undefined)

export function NavProvider({ children }: { children: ReactNode }) {
  const [stack, setStack] = useState<View[]>([{ name: "home" }])
  const view = stack[stack.length - 1]

  const go = (v: View) => {
    if (typeof window !== "undefined") window.scrollTo({ top: 0 })
    setStack((s) => [...s, v])
  }
  const back = () => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s))

  const topTabs = ["home", "browse", "cart", "seller", "profile"]
  const tab = topTabs.includes(view.name) ? view.name : ""

  return <Ctx.Provider value={{ view, go, back, tab }}>{children}</Ctx.Provider>
}

export function useNav() {
  const c = useContext(Ctx)
  if (!c) throw new Error("useNav must be used within NavProvider")
  return c
}
