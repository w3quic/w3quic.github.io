import type {
  ReferralProgram,
  AffiliateAccount,
  LoyaltyReward,
  Achievement,
  DailyCheckIn,
  SellerRanking,
  ReputationScore,
  UserProfile,
} from "./types"
import { uid } from "./helpers"

export class GrowthSystem {
  // Referral Program Management
  static createReferralLink(userId: string): string {
    return `https://pimarkethub.com?ref=${userId}`
  }

  static processReferral(referrerId: string, referredUserId: string): ReferralProgram {
    return {
      referrerId,
      referredUserId,
      status: "pending",
      bonusAmount: 5, // 5 Pi bonus
      createdAt: Date.now(),
    }
  }

  static completeReferral(referral: ReferralProgram): ReferralProgram {
    return {
      ...referral,
      status: "completed",
      claimedAt: Date.now(),
    }
  }

  // Affiliate Program
  static createAffiliateAccount(userId: string): AffiliateAccount {
    return {
      id: uid("aff"),
      userId,
      commissionRate: 5, // 5% commission
      earnings: 0,
      withdrawn: 0,
      status: "active",
      createdAt: Date.now(),
    }
  }

  static updateAffiliateEarnings(
    account: AffiliateAccount,
    saleAmount: number,
  ): AffiliateAccount {
    const commission = (saleAmount * account.commissionRate) / 100
    return {
      ...account,
      earnings: account.earnings + commission,
    }
  }

  // Loyalty & Points System
  static awardLoyaltyPoints(
    userId: string,
    type: "purchase" | "review" | "referral" | "daily-checkin" | "achievement",
    amount: number,
  ): LoyaltyReward {
    const pointsMap: Record<string, number> = {
      purchase: amount * 10, // 10 points per Pi spent
      review: 50,
      referral: 100,
      "daily-checkin": 25,
      achievement: 200,
    }

    return {
      id: uid("loy"),
      userId,
      type,
      pointsEarned: pointsMap[type] || 0,
      description: `Earned from ${type}`,
      createdAt: Date.now(),
    }
  }

  static redeemLoyaltyPoints(
    currentPoints: number,
    redeemAmount: number,
  ): { success: boolean; remainingPoints: number; discountValue: number } {
    const pointValue = 1 / 100 // 1 point = 0.01 Pi (100 points = 1 Pi discount)
    if (currentPoints < redeemAmount) {
      return { success: false, remainingPoints: currentPoints, discountValue: 0 }
    }
    const discount = redeemAmount * pointValue
    return {
      success: true,
      remainingPoints: currentPoints - redeemAmount,
      discountValue: discount,
    }
  }

  // Daily Check-in System
  static processDailyCheckIn(
    userId: string,
    lastCheckIn?: number,
  ): DailyCheckIn {
    const today = new Date().toISOString().split("T")[0]
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0]

    // Calculate streak
    let streakDays = 1
    let bonusMultiplier = 1

    if (lastCheckIn) {
      const lastDate = new Date(lastCheckIn).toISOString().split("T")[0]
      if (lastDate === yesterday) {
        streakDays += 1 // continuous streak
        bonusMultiplier = 1 + (streakDays - 1) * 0.1 // 10% bonus per day
      }
    }

    // Streak breaks if day is skipped
    if (lastCheckIn && lastCheckIn < Date.now() - 172800000) {
      // older than 2 days
      streakDays = 1
      bonusMultiplier = 1
    }

    const baseReward = 25
    const rewardPoints = Math.floor(baseReward * bonusMultiplier)

    return {
      userId,
      date: today,
      checkedInAt: Date.now(),
      streakDays,
      rewardPoints,
      bonusMultiplier,
    }
  }

  // Achievement System
  static checkAchievements(
    user: UserProfile,
    allAchievements: Achievement[],
  ): Achievement[] {
    const earned: Achievement[] = []

    for (const achievement of allAchievements) {
      const { requirement } = achievement
      let qualifies = false

      switch (requirement.type) {
        case "purchases":
          qualifies = user.totalTransactions >= requirement.value
          break
        case "reviews":
          qualifies = (user.badges?.length || 0) >= requirement.value
          break
        case "referrals":
          // Check referral count in separate data
          qualifies = false
          break
        case "sales":
          qualifies = user.isSeller && user.totalTransactions >= requirement.value
          break
        case "rating":
          qualifies = user.rating >= requirement.value
          break
        case "verification":
          qualifies = user.verification === "verified"
          break
      }

      if (qualifies && !user.achievements?.includes(achievement.code)) {
        earned.push(achievement)
      }
    }

    return earned
  }

  // Reputation Score Calculation
  static calculateReputation(user: UserProfile): ReputationScore {
    let score = 50 // base score

    // Rating impact
    score += user.rating * 5

    // Transaction count impact
    const txnBonus = Math.min(user.totalTransactions * 0.5, 20)
    score += txnBonus

    // Response time (lower is better)
    if (user.responseTimeMins < 60) score += 10
    else if (user.responseTimeMins < 180) score += 5

    // Disputes resolved positively
    const disputeBonus = user.disputesResolved * 2
    score += Math.min(disputeBonus, 10)

    // Verification level
    if (user.verification === "verified") score += 15

    score = Math.min(Math.max(score, 0), 100)

    let level: "new" | "basic" | "trusted" | "expert" | "elite" = "new"
    if (score >= 80) level = "elite"
    else if (score >= 65) level = "expert"
    else if (score >= 50) level = "trusted"
    else if (score >= 30) level = "basic"

    return {
      userId: user.id,
      score,
      level,
      completedSales: user.totalTransactions,
      positiveRatings: Math.floor(user.rating * user.ratingCount),
      neutralRatings: Math.floor(user.ratingCount * 0.2),
      negativeRatings: Math.floor(user.ratingCount * 0.05),
      avgResponseTime: user.responseTimeMins,
      consistencyBonus: Math.min(user.loginStreak * 0.5, 10),
    }
  }

  // Seller Ranking
  static calculateSellerRank(
    sellerId: string,
    metrics: {
      responseTime: number
      shippingSpeed: number
      itemAccuracy: number
      communicationRating: number
      overallRating: number
    },
  ): SellerRanking {
    // Average of all metrics
    const avgScore =
      (metrics.responseTime +
        metrics.shippingSpeed +
        metrics.itemAccuracy +
        metrics.communicationRating +
        metrics.overallRating) /
      5

    let tier: "beginner" | "established" | "professional" | "elite" =
      "beginner"
    if (avgScore >= 90) tier = "elite"
    else if (avgScore >= 75) tier = "professional"
    else if (avgScore >= 60) tier = "established"

    return {
      sellerId,
      rank: Math.floor(avgScore),
      tier,
      score: avgScore,
      metrics,
    }
  }

  // Tier Progression
  static getTierBenefits(tier: "beginner" | "established" | "professional" | "elite"): Record<string, any> {
    const benefits = {
      beginner: {
        commissionRate: 5,
        monthlyFeaturedListings: 1,
        supportPriority: "standard",
        analyticsAccess: false,
      },
      established: {
        commissionRate: 3.5,
        monthlyFeaturedListings: 5,
        supportPriority: "priority",
        analyticsAccess: true,
      },
      professional: {
        commissionRate: 2.5,
        monthlyFeaturedListings: 15,
        supportPriority: "vip",
        analyticsAccess: true,
        bulkEditingTools: true,
      },
      elite: {
        commissionRate: 1.5,
        monthlyFeaturedListings: 50,
        supportPriority: "dedicated",
        analyticsAccess: true,
        bulkEditingTools: true,
        apiAccess: true,
        customBranding: true,
      },
    }
    return benefits[tier]
  }
}

// Default Achievements
export const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  {
    id: uid("ach"),
    code: "first-purchase",
    name: "First Purchase",
    description: "Complete your first purchase on the marketplace",
    icon: "ShoppingBag",
    requirement: { type: "purchases", value: 1 },
    rewardPoints: 100,
    tier: "bronze",
  },
  {
    id: uid("ach"),
    code: "power-buyer",
    name: "Power Buyer",
    description: "Complete 25 purchases",
    icon: "Zap",
    requirement: { type: "purchases", value: 25 },
    rewardPoints: 500,
    tier: "silver",
  },
  {
    id: uid("ach"),
    code: "reviewer",
    name: "Trusted Reviewer",
    description: "Leave 10 product reviews",
    icon: "MessageSquare",
    requirement: { type: "reviews", value: 10 },
    rewardPoints: 300,
    tier: "bronze",
  },
  {
    id: uid("ach"),
    code: "seller-pro",
    name: "Seller Pro",
    description: "Complete 50 sales as a seller",
    icon: "TrendingUp",
    requirement: { type: "sales", value: 50 },
    rewardPoints: 1000,
    tier: "gold",
  },
  {
    id: uid("ach"),
    code: "trusted-member",
    name: "Trusted Member",
    description: "Achieve verified status",
    icon: "Shield",
    requirement: { type: "verification", value: 1 },
    rewardPoints: 500,
    tier: "silver",
  },
  {
    id: uid("ach"),
    code: "perfect-rating",
    name: "Perfect Rating",
    description: "Maintain a 5-star rating on 10+ sales",
    icon: "Star",
    requirement: { type: "rating", value: 5 },
    rewardPoints: 2000,
    tier: "platinum",
  },
]
