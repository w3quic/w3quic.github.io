import type { Shipment, ShippingLabel, TrackingUpdate, TrackingStatus, DeliveryPreference, OrderItem, Order } from "./types"
import { uid } from "./helpers"

/**
 * SHIPPING LABEL & TRACKING SYSTEM
 * Generates shipping labels and tracks packages throughout transit
 */

export const CARRIERS = ["dhl", "fedex", "ups", "local"] as const

export function createShippingLabel(
  orderId: string,
  carrier: (typeof CARRIERS)[number] = "local",
  estimatedDeliveryDays: number = 5
): ShippingLabel {
  return {
    id: uid("label"),
    orderId,
    trackingNumber: generateTrackingNumber(carrier),
    carrier,
    shippingCost: calculateShippingCost(carrier),
    estimatedDelivery: formatEstimatedDelivery(estimatedDeliveryDays),
    createdAt: Date.now(),
  }
}

export function generateTrackingNumber(carrier: string): string {
  const timestamp = Date.now().toString(36).toUpperCase()
  const random = Math.random().toString(36).substring(2, 8).toUpperCase()
  const carrierPrefix = carrier.substring(0, 2).toUpperCase()
  return `${carrierPrefix}${timestamp}${random}`
}

export function calculateShippingCost(carrier: string): number {
  const costs: Record<string, number> = {
    dhl: 8.5,
    fedex: 10.0,
    ups: 9.5,
    local: 2.0,
  }
  return costs[carrier] || 5.0
}

export function formatEstimatedDelivery(days: number): string {
  const date = new Date()
  date.setDate(date.getDate() + days)
  return date.toISOString().split("T")[0]
}

/**
 * SHIPMENT TRACKING
 * Tracks package location and status throughout delivery
 */

export function createShipment(
  orderId: string,
  sellerId: string,
  buyerId: string,
  items: OrderItem[],
  shippingLabel: ShippingLabel
): Shipment {
  return {
    id: uid("shipment"),
    orderId,
    sellerId,
    buyerId,
    items,
    shippingLabel,
    trackingUpdates: [
      {
        status: "label-created",
        timestamp: Date.now(),
        message: `Shipping label created. Tracking: ${shippingLabel.trackingNumber}`,
      },
    ],
  }
}

export function addTrackingUpdate(
  shipment: Shipment,
  status: TrackingStatus,
  message: string,
  location?: string
): Shipment {
  const update: TrackingUpdate = {
    status,
    location,
    timestamp: Date.now(),
    message,
  }

  return {
    ...shipment,
    trackingUpdates: [...shipment.trackingUpdates, update],
  }
}

export function markAsPickedUp(shipment: Shipment, location: string): Shipment {
  return addTrackingUpdate(shipment, "picked-up", `Package picked up at ${location}`, location)
}

export function markAsInTransit(shipment: Shipment, location: string): Shipment {
  return addTrackingUpdate(shipment, "in-transit", `Package in transit through ${location}`, location)
}

export function markAsOutForDelivery(shipment: Shipment, location: string): Shipment {
  return addTrackingUpdate(shipment, "out-for-delivery", `Out for delivery in ${location}`, location)
}

export function markAsDelivered(
  shipment: Shipment,
  location: string,
  handledBy?: string,
  signature?: string
): Shipment {
  const updated = addTrackingUpdate(
    shipment,
    "delivered",
    `Delivered at ${location}${handledBy ? ` by ${handledBy}` : ""}`,
    location
  )

  return {
    ...updated,
    deliveryConfirmedAt: Date.now(),
    deliverySignature: signature,
    handledBy,
  }
}

export function reportException(shipment: Shipment, message: string, location?: string): Shipment {
  return addTrackingUpdate(shipment, "exception", `Exception: ${message}`, location)
}

export function getLatestTrackingStatus(shipment: Shipment): TrackingUpdate | null {
  return shipment.trackingUpdates.length > 0
    ? shipment.trackingUpdates[shipment.trackingUpdates.length - 1]
    : null
}

/**
 * DELIVERY PREFERENCES
 * User preferences for delivery methods and timing
 */

export function createDeliveryPreference(userId: string): DeliveryPreference {
  return {
    userId,
    preferredCarrier: "local",
    preferredDeliveryType: "standard",
    requireSignature: false,
    allowHoldAtLocation: false,
    preferredTimeSlots: [],
  }
}

export function updateDeliveryPreference(
  preference: DeliveryPreference,
  updates: Partial<DeliveryPreference>
): DeliveryPreference {
  return {
    ...preference,
    ...updates,
  }
}

export function setPreferredTimeSlots(preference: DeliveryPreference, slots: string[]): DeliveryPreference {
  return {
    ...preference,
    preferredTimeSlots: slots,
  }
}

/**
 * DELIVERY TRACKING NOTIFICATIONS
 */

export interface DeliveryNotification {
  type: "status-update" | "exception" | "delivery-reminder" | "delivered"
  message: string
  trackingNumber: string
  timestamp: number
  actionUrl?: string
}

export function generateDeliveryNotification(
  shipment: Shipment,
  lastStatus: TrackingStatus
): DeliveryNotification | null {
  const currentStatus = getLatestTrackingStatus(shipment)
  if (!currentStatus) return null

  const notifications: Record<TrackingStatus, string> = {
    "label-created": "Your order is being prepared for shipment",
    "picked-up": "Your package has been picked up by the carrier",
    "in-transit": `Your package is in transit: ${currentStatus.location || ""}`,
    "out-for-delivery": "Your package is out for delivery today",
    delivered: `Your package has been delivered${currentStatus.location ? ` at ${currentStatus.location}` : ""}`,
    exception: `Delivery exception: ${currentStatus.message}`,
    returned: "Your package has been returned",
  }

  return {
    type: currentStatus.status === "delivered" ? "delivered" : "status-update",
    message: notifications[currentStatus.status],
    trackingNumber: shipment.shippingLabel.trackingNumber,
    timestamp: currentStatus.timestamp,
  }
}

/**
 * ESTIMATED DELIVERY CALCULATION
 */

export function calculateEstimatedDelivery(
  carrier: string,
  shippingRegion: string,
  baseDeliveryDays: number = 5
): Date {
  const date = new Date()

  // Adjust based on carrier
  const carrierDays: Record<string, number> = {
    dhl: 3,
    fedex: 4,
    ups: 4,
    local: 1,
  }

  // Adjust based on region
  const regionDays: Record<string, number> = {
    domestic: 0,
    regional: 2,
    international: 7,
  }

  const totalDays = (carrierDays[carrier] || baseDeliveryDays) + (regionDays[shippingRegion] || 0)
  date.setDate(date.getDate() + totalDays)

  // Skip weekends
  const dayOfWeek = date.getDay()
  if (dayOfWeek === 6) date.setDate(date.getDate() + 2) // Saturday -> Monday
  if (dayOfWeek === 0) date.setDate(date.getDate() + 1) // Sunday -> Monday

  return date
}

/**
 * DELIVERY CONFIRMATION
 */

export function confirmDelivery(shipment: Shipment, buyerNotes?: string): Shipment {
  const updated = {
    ...shipment,
    deliveryConfirmedAt: Date.now(),
  }

  if (buyerNotes) {
    updated.notes = buyerNotes
  }

  return updated
}

export function hasDeliveryBeenConfirmed(shipment: Shipment): boolean {
  return shipment.deliveryConfirmedAt !== undefined
}

/**
 * RETURN & REFUND SHIPPING
 */

export function createReturnShippingLabel(
  originalOrderId: string,
  carrier: string = "local"
): ShippingLabel {
  return {
    id: uid("return-label"),
    orderId: originalOrderId,
    trackingNumber: generateTrackingNumber(`${carrier}-return`),
    carrier,
    shippingCost: 0, // Seller covers return shipping
    estimatedDelivery: formatEstimatedDelivery(5),
    createdAt: Date.now(),
  }
}

/**
 * SHIPPING ANALYTICS
 */

export interface ShippingMetrics {
  totalShipments: number
  averageDeliveryTime: number // days
  onTimeDeliveryRate: number // percentage
  exceptionRate: number // percentage
  carrierPerformance: Record<string, { onTime: number; exceptions: number }>
}

export function calculateShippingMetrics(shipments: Shipment[]): ShippingMetrics {
  if (shipments.length === 0) {
    return {
      totalShipments: 0,
      averageDeliveryTime: 0,
      onTimeDeliveryRate: 0,
      exceptionRate: 0,
      carrierPerformance: {},
    }
  }

  let totalDeliveryTime = 0
  let deliveredCount = 0
  let onTimeCount = 0
  let exceptionCount = 0
  const carrierStats: Record<string, { onTime: number; exceptions: number }> = {}

  shipments.forEach(shipment => {
    const carrier = shipment.shippingLabel.carrier
    if (!carrierStats[carrier]) {
      carrierStats[carrier] = { onTime: 0, exceptions: 0 }
    }

    const deliveryUpdate = shipment.trackingUpdates.find(u => u.status === "delivered")
    if (deliveryUpdate) {
      const estimatedDate = new Date(shipment.shippingLabel.estimatedDelivery)
      const actualDate = new Date(deliveryUpdate.timestamp)

      totalDeliveryTime += Math.round((actualDate.getTime() - shipment.shippingLabel.createdAt) / (24 * 60 * 60 * 1000))
      deliveredCount++

      if (actualDate <= estimatedDate) {
        onTimeCount++
        carrierStats[carrier].onTime++
      }
    }

    const hasException = shipment.trackingUpdates.some(u => u.status === "exception")
    if (hasException) {
      exceptionCount++
      carrierStats[carrier].exceptions++
    }
  })

  return {
    totalShipments: shipments.length,
    averageDeliveryTime: deliveredCount > 0 ? Math.round(totalDeliveryTime / deliveredCount) : 0,
    onTimeDeliveryRate: deliveredCount > 0 ? (onTimeCount / deliveredCount) * 100 : 0,
    exceptionRate: (exceptionCount / shipments.length) * 100,
    carrierPerformance: carrierStats,
  }
}
