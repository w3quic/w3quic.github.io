import type { Product, Category } from "./types"

/**
 * Modular adapter interfaces. Every external dependency is isolated here so the
 * backend can be swapped without touching UI code. Current implementations are
 * client-side simulations (localStorage / rule-based).
 */

// ---------------- AI Scam Detection adapter ----------------
export function computeScamScore(p: {
  price: number
  categoryAvg: number
  accountAgeDays: number
  reports: number
  priceChanges: number
  descriptionLength: number
}): number {
  let score = 0
  if (p.accountAgeDays < 7) score += 25
  else if (p.accountAgeDays < 30) score += 10
  if (p.categoryAvg > 0 && p.price < p.categoryAvg * 0.4) score += 30
  else if (p.categoryAvg > 0 && p.price < p.categoryAvg * 0.6) score += 15
  score += Math.min(p.reports * 12, 30)
  if (p.priceChanges > 3) score += 10
  if (p.descriptionLength < 30) score += 10
  return Math.min(100, score)
}

// ---------------- AI Price Suggestion adapter ----------------
export function suggestPrice(category: Category, products: Product[]): { min: number; max: number; avg: number } {
  const same = products.filter((p) => p.category === category)
  if (same.length === 0) return { min: 5, max: 50, avg: 20 }
  const avg = same.reduce((s, p) => s + p.price, 0) / same.length
  return { min: Math.max(1, Math.round(avg * 0.7)), max: Math.round(avg * 1.3), avg: Math.round(avg) }
}

// ---------------- AI Listing Assistant adapter ----------------
export function generateListing(keywords: string, category: Category): { title: string; description: string } {
  const kw = keywords.trim() || "item"
  const cap = kw.charAt(0).toUpperCase() + kw.slice(1)
  const title = `${cap} - Quality ${category} in Excellent Condition`
  const description =
    `${cap} available now on Pi Market Hub. This ${category} item offers great value and quality. ` +
    `Carefully maintained and ready to ship. Features include reliable performance and a trusted seller backing. ` +
    `Pay securely with Pi through buyer-protected escrow. Message us with any questions!`
  return { title, description }
}

// ---------------- AI Shopping Assistant adapter ----------------
export function parseShoppingQuery(
  query: string,
  products: Product[],
): { results: Product[]; reply: string } {
  const q = query.toLowerCase()
  let results = [...products]

  // price ceiling
  const underMatch = q.match(/under\s+(\d+)/) || q.match(/below\s+(\d+)/) || q.match(/less than\s+(\d+)/)
  let priceCeil: number | null = null
  if (underMatch) {
    priceCeil = Number.parseInt(underMatch[1], 10)
    results = results.filter((p) => p.price <= priceCeil!)
  }

  // category keywords
  const catMap: Record<string, Category> = {
    laptop: "electronics", phone: "electronics", electronic: "electronics", gadget: "electronics",
    shirt: "fashion", clothes: "fashion", fashion: "fashion", shoe: "fashion",
    home: "home", garden: "home", furniture: "home",
    car: "vehicles", vehicle: "vehicles", bike: "vehicles",
    food: "food", book: "books", toy: "toys", gamer: "toys", sport: "sports",
  }
  let matchedCat: Category | null = null
  for (const [k, c] of Object.entries(catMap)) {
    if (q.includes(k)) { matchedCat = c; break }
  }
  if (matchedCat) results = results.filter((p) => p.category === matchedCat)

  // text term match against title
  const stop = new Set(["find", "me", "a", "the", "for", "good", "cheap", "what", "are", "gifts", "to", "under", "below", "show", "i", "want", "need"])
  const terms = q.split(/\s+/).filter((t) => t.length > 2 && !stop.has(t) && !/^\d+$/.test(t))
  if (terms.length && results.length === products.length) {
    results = results.filter((p) =>
      terms.some((t) => p.title.toLowerCase().includes(t) || p.description.toLowerCase().includes(t)),
    )
  }

  if (q.includes("cheap")) results.sort((a, b) => a.price - b.price)

  results = results.slice(0, 8)
  let reply: string
  if (results.length === 0) {
    reply = "I couldn't find anything matching that. Try different keywords or a higher budget."
  } else {
    const parts: string[] = []
    if (matchedCat) parts.push(matchedCat)
    if (priceCeil) parts.push(`under ${priceCeil} Pi`)
    reply = `Found ${results.length} ${parts.length ? parts.join(" ") + " " : ""}item${results.length > 1 ? "s" : ""} for you:`
  }
  return { results, reply }
}

// ---------------- Recommendation adapter ----------------
export function getRecommendations(
  products: Product[],
  opts: { category?: Category; sellerId?: string; favoriteSellers?: string[]; excludeId?: string; count?: number },
): Product[] {
  const { category, sellerId, favoriteSellers = [], excludeId, count = 8 } = opts
  const scored = products
    .filter((p) => p.id !== excludeId)
    .map((p) => {
      let s = 0
      if (category && p.category === category) s += 3
      if (sellerId && p.sellerId === sellerId) s += 2
      if (favoriteSellers.includes(p.sellerId)) s += 2
      s += p.rating ?? 0
      s += Math.min(p.views / 50, 3)
      return { p, s }
    })
    .sort((a, b) => b.s - a.s)
  return scored.slice(0, count).map((x) => x.p)
}

// ---------------- Shipping adapter ----------------
export function getShippingRate(region: string): number {
  const r = region.trim().toLowerCase()
  if (!r) return 0
  // simulated tiered rates
  const map: Record<string, number> = { local: 1, domestic: 3, international: 8 }
  if (map[r] != null) return map[r]
  // hash-based deterministic rate 1-6 Pi
  let h = 0
  for (let i = 0; i < r.length; i++) h = (h * 31 + r.charCodeAt(i)) >>> 0
  return 1 + (h % 6)
}

// ---------------- Sales Tax adapter ----------------
export function calculateTax(_amount: number, _location: string, _category: string): number {
  return 0 // future: tax rate API
}

// ---------------- KYC adapter ----------------
export function getVerificationLevelMock(): "basic" {
  return "basic"
}

// ---------------- Reputation score ----------------
export function computeReputation(p: {
  rating: number
  totalTransactions: number
  responseTimeMins: number
  disputesResolved: number
}): number {
  const ratingScore = (p.rating / 5) * 50
  const txScore = Math.min(p.totalTransactions / 100, 1) * 25
  const responseScore = Math.max(0, 1 - p.responseTimeMins / 1440) * 15
  const disputeScore = Math.min(p.disputesResolved / 10, 1) * 10
  return Math.round(ratingScore + txScore + responseScore + disputeScore)
}
