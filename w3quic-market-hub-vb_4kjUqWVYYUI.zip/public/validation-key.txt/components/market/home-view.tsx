"use client"

import { useMemo } from "react"
import * as Icons from "lucide-react"
import { ChevronRight, Sparkles, Zap, TrendingUp, Clock, Megaphone } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { CATEGORIES } from "@/lib/market/types"
import { POPULAR_SEARCHES } from "@/lib/market/seed"
import { getRecommendations } from "@/lib/market/adapters"
import { effectivePrice, formatPi, countdown } from "@/lib/market/helpers"
import { ProductCard } from "./product-card"
import { RealEstateButton } from "./real-estate-button"
import { VehicleMarketplaceButton } from "./vehicle-marketplace-button"
import { ServicesMarketplaceButton } from "./services-marketplace-button"
import { MarketplaceListingsButton } from "./marketplace-listings-button"

function SectionHeader({ icon: Icon, title, onMore }: { icon: any; title: string; onMore?: () => void }) {
  return (
    <div className="flex items-center justify-between px-4">
      <h2 className="flex items-center gap-2 text-base font-bold text-foreground animate-fade-in">
        <Icon className="h-5 w-5 text-primary" />
        {title}
      </h2>
      {onMore && (
        <button onClick={onMore} className="group flex items-center gap-0.5 text-xs font-semibold text-primary transition-all hover:gap-1">
          See all <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </button>
      )}
    </div>
  )
}

function Row({ children }: { children: React.ReactNode }) {
  return <div className="no-scrollbar flex gap-3 overflow-x-auto px-4 pb-2">{children}</div>
}

export function HomeView({ onOpenAssistant }: { onOpenAssistant: () => void }) {
  const { products, me, recentlyViewed, followedStores, stores, getProduct } = useMarket()
  const { go } = useNav()

  const featured = useMemo(() => products.filter((p) => p.featured).slice(0, 5), [products])
  const flashDeals = useMemo(() => products.filter((p) => p.flashDeal && p.flashDeal.endsAt > Date.now()), [products])
  const trending = useMemo(() => [...products].sort((a, b) => b.views - a.views).slice(0, 10), [products])
  const recent = useMemo(() => recentlyViewed.map(getProduct).filter(Boolean).slice(0, 10) as typeof products, [recentlyViewed, getProduct])
  const recommended = useMemo(
    () => getRecommendations(products, { favoriteSellers: me.favoriteSellers, count: 10 }),
    [products, me.favoriteSellers],
  )
  const announcements = useMemo(
    () => stores
      .filter((s) => followedStores.includes(s.sellerId) && s.announcements && s.announcements.length > 0)
      .flatMap((s) => (s.announcements || []).map((a) => ({ ...a, store: s }))),
    [stores, followedStores],
  )

  return (
    <div className="space-y-6 pb-6">
      {/* Hero */}
      <section className="px-4 pt-4 space-y-3">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary to-primary/80 p-6 text-primary-foreground shadow-lg">
          <div className="relative z-10 max-w-[65%]">
            <p className="text-xs font-semibold opacity-90">π Pi Market Hub</p>
            <h1 className="text-pretty text-2xl font-bold leading-tight mt-1">Buy & sell with Pi, protected by escrow</h1>
            <div className="mt-4 flex flex-col gap-2">
              <button
                onClick={onOpenAssistant}
                className="inline-flex items-center gap-1.5 rounded-full bg-primary-foreground px-3.5 py-2 text-xs font-semibold text-primary transition-all hover:scale-105 active:scale-95 shadow-md w-fit"
              >
                <Sparkles className="h-4 w-4" /> Ask AI Assistant
              </button>
              <div className="text-xs opacity-75 leading-relaxed">Start creating listings or exploring products today</div>
            </div>
          </div>
          <Icons.ShoppingBag className="absolute -right-6 -bottom-6 h-32 w-32 opacity-10 animate-bounce-soft" />
        </div>

        {/* Marketplace Listings Quick Access */}
        <div className="rounded-2xl border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-primary/10 p-4">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-foreground">Start Selling or Shopping</h2>
              <p className="text-xs text-muted-foreground mt-1">Create listings, browse products & services</p>
            </div>
            <span className="text-xs font-semibold bg-primary text-primary-foreground px-2 py-1 rounded-full">0.5 π</span>
          </div>
          <MarketplaceListingsButton variant="default" fullWidth={true} />
        </div>
      </section>

      {announcements.length > 0 && (
        <section className="px-4">
          {announcements.map((a, i) => (
            <button
              key={`${a.store.sellerId}-${i}`}
              onClick={() => go({ name: "store", sellerId: a.store.sellerId })}
              className="flex w-full items-start gap-2 rounded-xl border border-primary/20 bg-accent p-3 text-left"
            >
              <Megaphone className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <div>
                <p className="text-xs font-semibold text-accent-foreground">{a.store.name}: {a.title}</p>
                <p className="text-xs text-muted-foreground">{a.text}</p>
              </div>
            </button>
          ))}
        </section>
      )}

      {/* Featured */}
      {featured.length > 0 && (
        <section className="space-y-3">
          <SectionHeader icon={Sparkles} title="Featured" />
          <Row>{featured.map((p) => <ProductCard key={p.id} product={p} compact />)}</Row>
        </section>
      )}

      {/* Flash Deals */}
      {flashDeals.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between px-4">
            <h2 className="flex items-center gap-2 text-base font-bold text-foreground">
              <Zap className="h-4 w-4 text-rose-500" /> Flash Deals
            </h2>
            <button onClick={() => go({ name: "flash" })} className="flex items-center gap-0.5 text-xs font-medium text-primary">
              See all <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <Row>{flashDeals.map((p) => <ProductCard key={p.id} product={p} compact />)}</Row>
        </section>
      )}

      {/* Real Estate Featured Section */}
      <section className="px-4">
        <div className="rounded-2xl border-2 border-blue-300 bg-gradient-to-br from-blue-50 to-blue-100 p-4">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-blue-900">Real Estate Hub</h2>
              <p className="text-xs text-blue-800 mt-1">Buy, sell & rent properties</p>
            </div>
            <span className="text-xs font-semibold bg-blue-600 text-white px-2 py-1 rounded-full">0.5 π</span>
          </div>
          <RealEstateButton variant="default" fullWidth={true} />
        </div>
      </section>

      {/* Vehicle Marketplace Featured Section */}
      <section className="px-4">
        <div className="rounded-2xl border-2 border-amber-300 bg-gradient-to-br from-amber-50 to-amber-100 p-4">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-amber-900">Vehicle Marketplace</h2>
              <p className="text-xs text-amber-800 mt-1">Buy, sell & trade vehicles</p>
            </div>
            <span className="text-xs font-semibold bg-amber-600 text-white px-2 py-1 rounded-full">0.5 π</span>
          </div>
          <VehicleMarketplaceButton variant="default" fullWidth={true} />
        </div>
      </section>

      {/* Services Marketplace Featured Section */}
      <section className="px-4">
        <div className="rounded-2xl border-2 border-purple-300 bg-gradient-to-br from-purple-50 to-purple-100 p-4">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-purple-900">Services Marketplace</h2>
              <p className="text-xs text-purple-800 mt-1">Find professional services & freelancers</p>
            </div>
            <span className="text-xs font-semibold bg-purple-600 text-white px-2 py-1 rounded-full">0.5 π</span>
          </div>
          <ServicesMarketplaceButton variant="default" fullWidth={true} />
        </div>
      </section>

      {/* Categories */}
      <section className="space-y-3">
        <SectionHeader icon={Icons.LayoutGrid} title="Categories" />
        <div className="grid grid-cols-5 gap-2 px-4">
          {CATEGORIES.map((c) => {
            const Icon = (Icons as any)[c.icon] ?? Icons.Package
            return (
              <button
                key={c.id}
                onClick={() => go({ name: "browse", category: c.id })}
                className="flex flex-col items-center gap-1.5 rounded-xl border border-border bg-card p-2 text-center transition-colors hover:bg-accent"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-accent">
                  <Icon className="h-5 w-5 text-primary" />
                </span>
                <span className="text-[10px] font-medium leading-tight text-card-foreground">{c.label}</span>
              </button>
            )
          })}
        </div>
      </section>

      {/* Popular searches */}
      <section className="space-y-2 px-4">
        <h2 className="text-sm font-semibold text-muted-foreground">Popular Searches</h2>
        <div className="flex flex-wrap gap-2">
          {POPULAR_SEARCHES.map((t) => (
            <button
              key={t}
              onClick={() => go({ name: "browse", query: t })}
              className="rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-card-foreground hover:bg-accent"
            >
              {t}
            </button>
          ))}
        </div>
      </section>

      {/* Trending */}
      <section className="space-y-3">
        <SectionHeader icon={TrendingUp} title="Trending Now" onMore={() => go({ name: "browse", filter: "trending" })} />
        <Row>{trending.map((p) => <ProductCard key={p.id} product={p} compact />)}</Row>
      </section>

      {/* Recently viewed */}
      {recent.length > 0 && (
        <section className="space-y-3">
          <SectionHeader icon={Clock} title="Recently Viewed" />
          <Row>{recent.map((p) => <ProductCard key={p.id} product={p} compact />)}</Row>
        </section>
      )}

      {/* Recommended / personalized feed */}
      <section className="space-y-3">
        <SectionHeader icon={Sparkles} title="Recommended For You" />
        <div className="grid grid-cols-2 gap-3 px-4">
          {recommended.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </div>
  )
}
