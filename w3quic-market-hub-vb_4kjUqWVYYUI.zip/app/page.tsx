import { MarketApp } from "@/components/market/market-app"

export default function HomePage() {
  return <MarketApp />
}
